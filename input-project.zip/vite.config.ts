import react from '@vitejs/plugin-react';
import legacy from '@vitejs/plugin-legacy';
import fs from 'fs';
import path from 'path';
import { transform } from 'esbuild';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    base: process.env.VITE_PAGES_BASE || '/',
    build: { target: 'chrome46', cssTarget: 'chrome46' },
    plugins: [
      react(),
      legacy({ targets: ['Chrome >= 46', 'Android >= 6'] }),
      {
        name: 'android-marshmallow-bigint-syntax-compat',
        apply: 'build',
        async closeBundle(): Promise<void> {
          const assetDir = path.resolve(__dirname, 'dist/assets');
          if (!fs.existsSync(assetDir)) return;
          for (const file of fs.readdirSync(assetDir)) {
            if (!file.includes('legacy') || !file.endsWith('.js')) continue;
            const filePath = path.join(assetDir, file);
            const source = fs.readFileSync(filePath, 'utf8');
            // Strip BigInt literal grammar if a transitive SDK reintroduces it.
            const compatible = source.replace(/\b(0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+|[0-9]+)n\b/g, 'BigInt("$1")');
            // Vite's SystemJS polyfill chunk is emitted after normal transforms and can
            // retain arrows. Downlevel every legacy artifact for Android 6 / Chrome 46.
            const downlevel = await transform(compatible, { target: 'chrome46', loader: 'js' });
            fs.writeFileSync(filePath, downlevel.code);
          }
        },
      },
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
