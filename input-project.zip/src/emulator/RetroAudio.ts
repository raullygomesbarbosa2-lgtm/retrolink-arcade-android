export class RetroAudioEngine {
  private ctx: AudioContext | null = null;
  private scriptNode: ScriptProcessorNode | null = null;
  private bufferL: Float32Array;
  private bufferR: Float32Array;
  private writeIdx = 0;
  private readIdx = 0;
  private readonly bufferSize = 8192;
  public muted = true;
  public sampleRate = 44100;

  constructor() {
    this.bufferL = new Float32Array(this.bufferSize);
    this.bufferR = new Float32Array(this.bufferSize);
  }

  public init(): void {
    if (this.muted) return;
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.sampleRate = this.ctx.sampleRate;
    this.scriptNode = this.ctx.createScriptProcessor(1024, 0, 2);
    this.scriptNode.onaudioprocess = (event) => {
      const outL = event.outputBuffer.getChannelData(0);
      const outR = event.outputBuffer.getChannelData(1);
      for (let i = 0; i < outL.length; i++) {
        if (this.readIdx !== this.writeIdx && !this.muted) {
          outL[i] = this.bufferL[this.readIdx] * 0.45;
          outR[i] = this.bufferR[this.readIdx] * 0.45;
          this.readIdx = (this.readIdx + 1) % this.bufferSize;
        } else {
          outL[i] = 0;
          outR[i] = 0;
        }
      }
    };
    this.scriptNode.connect(this.ctx.destination);
  }

  public pushNesSample(left: number, right: number): void {
    if (this.muted) return;
    const nextWrite = (this.writeIdx + 1) % this.bufferSize;
    if (nextWrite === this.readIdx) {
      return;
    }
    this.bufferL[this.writeIdx] = left;
    this.bufferR[this.writeIdx] = right;
    this.writeIdx = nextWrite;
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (!muted) {
      this.init();
    }
  }

  public dispose(): void {
    if (this.scriptNode) {
      this.scriptNode.disconnect();
      this.scriptNode = null;
    }
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
