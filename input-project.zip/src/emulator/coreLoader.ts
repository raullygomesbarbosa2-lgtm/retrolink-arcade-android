import { unzipSync } from 'fflate';
import { RetroCoreName } from '../types/retrolink';

interface ExtractedCore {
  jsBlob: Blob;
  wasmBlob: Blob;
}

const extractedCoreCache = new Map<string, Promise<ExtractedCore>>();

const CDN_BASE = 'https://cdn.jsdelivr.net/gh/arianrhodsandlot/retroarch-emscripten-build@v1.22.2/retroarch';

async function fetchAndExtractCore(coreName: string): Promise<ExtractedCore> {
  // Prefer same-origin cached proxy first; fall back to jsDelivr if needed
  let res = await fetch(`/api/cores/${encodeURIComponent(coreName)}`);
  if (!res.ok) {
    res = await fetch(`${CDN_BASE}/${encodeURIComponent(coreName)}_libretro.zip`);
  }
  if (!res.ok) {
    throw new Error(`Não foi possível carregar o núcleo ${coreName} (HTTP ${res.status}).`);
  }

  const buffer = new Uint8Array(await res.arrayBuffer());
  const files = unzipSync(buffer);

  let jsBytes: Uint8Array | null = null;
  let wasmBytes: Uint8Array | null = null;

  for (const [name, content] of Object.entries(files)) {
    if (name.endsWith('.js')) {
      jsBytes = content;
    } else if (name.endsWith('.wasm')) {
      wasmBytes = content;
    }
  }

  if (!jsBytes || !wasmBytes) {
    throw new Error(`Núcleo ${coreName} incompleto no pacote ZIP.`);
  }

  return {
    jsBlob: new Blob([new Uint8Array(jsBytes)], { type: 'application/javascript' }),
    wasmBlob: new Blob([new Uint8Array(wasmBytes)], { type: 'application/wasm' }),
  };
}

export async function getExtractedCore(core: RetroCoreName): Promise<ExtractedCore> {
  const key = String(core);
  const existing = extractedCoreCache.get(key);
  if (existing) return existing;

  const promise = fetchAndExtractCore(key).catch((err) => {
    extractedCoreCache.delete(key);
    throw err;
  });
  extractedCoreCache.set(key, promise);
  return promise;
}
