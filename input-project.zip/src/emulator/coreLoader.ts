import { unzipSync } from 'fflate';
import { RetroCoreName } from '../types/retrolink';

interface ExtractedCore {
  jsBlob: Blob;
  wasmBlob: Blob;
}

const extractedCoreCache = new Map<string, Promise<ExtractedCore>>();

const CDN_BASE = 'https://cdn.jsdelivr.net/gh/arianrhodsandlot/retroarch-emscripten-build@v1.22.2/retroarch';

function extractCoreZip(buffer: Uint8Array, coreName: string): ExtractedCore {
  // Capacitor's local origin (or a static host's SPA fallback) may answer
  // /api/cores/... with index.html and HTTP 200. Detect that before fflate
  // reports the misleading "Invalid ZIP data" error on Android 6 WebView.
  const hasZipSignature =
    buffer.length >= 4 &&
    buffer[0] === 0x50 &&
    buffer[1] === 0x4b &&
    ((buffer[2] === 0x03 && buffer[3] === 0x04) ||
      (buffer[2] === 0x05 && buffer[3] === 0x06) ||
      (buffer[2] === 0x07 && buffer[3] === 0x08));
  if (!hasZipSignature) {
    throw new Error('A resposta do servidor não é um arquivo ZIP.');
  }

  const files = unzipSync(buffer);
  let jsBytes: Uint8Array | null = null;
  let wasmBytes: Uint8Array | null = null;

  for (const [name, content] of Object.entries(files)) {
    if (name.endsWith('.js')) {
      jsBytes = content;
    } else if (name.endsWith('.wasm')) {
      wasmBytes = content;
    }
  }

  if (!jsBytes || !wasmBytes) {
    throw new Error(`Núcleo ${coreName} incompleto no pacote ZIP.`);
  }

  return {
    jsBlob: new Blob([new Uint8Array(jsBytes)], { type: 'application/javascript' }),
    wasmBlob: new Blob([new Uint8Array(wasmBytes)], { type: 'application/wasm' }),
  };
}

async function fetchAndExtractCore(coreName: string): Promise<ExtractedCore> {
  const localUrl = `/api/cores/${encodeURIComponent(coreName)}`;
  try {
    const localResponse = await fetch(localUrl);
    if (!localResponse.ok) {
      throw new Error(`HTTP ${localResponse.status}`);
    }
    return extractCoreZip(new Uint8Array(await localResponse.arrayBuffer()), coreName);
  } catch {
    // In the APK the local /api route is not a server endpoint. A successful
    // HTTP response can still be the app shell, so fall back unless it's a
    // real, readable core ZIP containing both the JS and WASM files.
  }

  const cdnUrl = `${CDN_BASE}/${encodeURIComponent(coreName)}_libretro.zip`;
  try {
    const cdnResponse = await fetch(cdnUrl);
    if (!cdnResponse.ok) {
      throw new Error(`HTTP ${cdnResponse.status}`);
    }
    return extractCoreZip(new Uint8Array(await cdnResponse.arrayBuffer()), coreName);
  } catch (err) {
    const reason = err instanceof Error ? err.message : 'resposta inválida';
    throw new Error(`Não foi possível carregar o núcleo ${coreName} (CDN: ${reason}).`);
  }
}

export async function getExtractedCore(core: RetroCoreName): Promise<ExtractedCore> {
  const key = String(core);
  const existing = extractedCoreCache.get(key);
  if (existing) return existing;

  const promise = fetchAndExtractCore(key).catch((err) => {
    extractedCoreCache.delete(key);
    throw err;
  });
  extractedCoreCache.set(key, promise);
  return promise;
}
