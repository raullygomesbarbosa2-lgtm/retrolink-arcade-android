import { unzipSync } from 'fflate';
import { RetroCoreName } from '../types/retrolink';

interface ExtractedCore {
  jsBlob: Blob;
  wasmBlob: Blob;
}

const extractedCoreCache = new Map<string, Promise<ExtractedCore>>();

const CDN_BASE = 'https://cdn.jsdelivr.net/gh/arianrhodsandlot/retroarch-emscripten-build@v1.22.2/retroarch';

async function fetchAndExtractCore(coreName: string): Promise<ExtractedCore> {
  const encodedName = encodeURIComponent(coreName);
  const candidates = [
    `/api/cores/${encodedName}`,
    `${CDN_BASE}/${encodedName}_libretro.zip`,
  ];
  let lastError: unknown;

  for (const url of candidates) {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const buffer = new Uint8Array(await response.arrayBuffer());
      // A missing local API route can return the app's HTML fallback with HTTP 200.
      // Check the ZIP signature and the expected payload before accepting either source.
      if (buffer.length < 4 || buffer[0] !== 0x50 || buffer[1] !== 0x4b) {
        throw new Error('a resposta não é um arquivo ZIP');
      }
      const files = unzipSync(buffer);
      let jsBytes: Uint8Array | null = null;
      let wasmBytes: Uint8Array | null = null;
      for (const [name, content] of Object.entries(files)) {
        if (name.endsWith('.js')) jsBytes = content;
        else if (name.endsWith('.wasm')) wasmBytes = content;
      }
      if (!jsBytes || !wasmBytes) {
        throw new Error('o ZIP não contém os arquivos JS e WASM do núcleo');
      }
      return {
        jsBlob: new Blob([new Uint8Array(jsBytes)], { type: 'application/javascript' }),
        wasmBlob: new Blob([new Uint8Array(wasmBytes)], { type: 'application/wasm' }),
      };
    } catch (error) {
      lastError = error;
    }
  }

  const detail = lastError instanceof Error ? lastError.message : 'falha de rede';
  throw new Error(`Não foi possível baixar o núcleo ${coreName}: ${detail}. Verifique a conexão e tente novamente.`);
}

export async function getExtractedCore(core: RetroCoreName): Promise<ExtractedCore> {
  const key = String(core);
  const existing = extractedCoreCache.get(key);
  if (existing) return existing;

  const promise = fetchAndExtractCore(key).catch((err) => {
    extractedCoreCache.delete(key);
    throw err;
  });
  extractedCoreCache.set(key, promise);
  return promise;
}
