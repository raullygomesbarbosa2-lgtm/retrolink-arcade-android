import { SystemId } from '../types/retrolink';

export interface ControllerLayoutProfile {
  profileName: string;
  showXY: boolean;
  showL1R1: boolean;
  showL2R2: boolean;
  labels: {
    a: string;
    b: string;
    x: string;
    y: string;
    l1: string;
    r1: string;
    l2: string;
    r2: string;
    select: string;
    start: string;
  };
}

const DEFAULT_LABELS = {
  a: 'A',
  b: 'B',
  x: 'X',
  y: 'Y',
  l1: 'L1',
  r1: 'R1',
  l2: 'L2',
  r2: 'R2',
  select: 'SELECT',
  start: 'START',
};

export function getControllerProfile(
  systemId: SystemId | undefined,
  gameTitle: string | undefined,
  forceFull: boolean
): ControllerLayoutProfile {
  const titleLower = (gameTitle || '').toLowerCase();
  const isFightingGame =
    /kof|fighter|street|capcom|marvel|samsho|garou|fatal|mortal|killer|tekken|snk|vs\./i.test(
      titleLower
    );

  if (forceFull) {
    return {
      profileName: 'Controle Completo (Todos os Botões)',
      showXY: true,
      showL1R1: true,
      showL2R2: true,
      labels: { ...DEFAULT_LABELS },
    };
  }

  switch (systemId) {
    case 'nes':
      return {
        profileName: 'NES (2 Botões)',
        showXY: false,
        showL1R1: false,
        showL2R2: false,
        labels: { ...DEFAULT_LABELS },
      };

    case 'gba':
      return {
        profileName: 'GBA / Game Boy (A/B + L1/R1)',
        showXY: false,
        showL1R1: true,
        showL2R2: false,
        labels: { ...DEFAULT_LABELS },
      };

    case 'snes':
      return {
        profileName: isFightingGame ? 'SNES Luta (6 Botões)' : 'SNES (A/B/X/Y + L1/R1)',
        showXY: true,
        showL1R1: true,
        showL2R2: isFightingGame,
        labels: { ...DEFAULT_LABELS },
      };

    case 'megadrive':
      return {
        profileName: isFightingGame ? 'Mega Drive Luta (6 Botões)' : 'Mega Drive (A/B/X/Y + L1/R1)',
        showXY: true,
        showL1R1: true,
        showL2R2: false,
        labels: {
          ...DEFAULT_LABELS,
          l1: 'L1 · Z',
          r1: 'R1 · C',
          select: 'MODE',
        },
      };

    case 'neogeo':
      return {
        profileName: 'Neo Geo MVS (A/B/C/D + Coin)',
        showXY: true,
        showL1R1: isFightingGame,
        showL2R2: false,
        labels: {
          ...DEFAULT_LABELS,
          x: 'X · C',
          y: 'Y · D',
          select: 'COIN',
        },
      };

    case 'cps2':
    case 'arcade':
      return {
        profileName: isFightingGame
          ? 'Arcade Luta (6 Botões + L1/L2/R1/R2)'
          : 'Arcade / FBNeo (A/B/X/Y + L/R)',
        showXY: true,
        showL1R1: true,
        showL2R2: isFightingGame,
        labels: {
          ...DEFAULT_LABELS,
          select: 'COIN',
        },
      };

    default:
      return {
        profileName: 'Controle Completo',
        showXY: true,
        showL1R1: true,
        showL2R2: true,
        labels: { ...DEFAULT_LABELS },
      };
  }
}
