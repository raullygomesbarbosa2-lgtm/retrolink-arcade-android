import React, { useEffect, useRef, useState } from 'react';
import { NES, Controller } from 'jsnes';
import { Nostalgist } from 'nostalgist';
import {
  BookmarkCheck,
  BookmarkPlus,
  Gamepad,
  Loader2,
  Lock,
  Maximize2,
  Pause,
  Play,
  RotateCcw,
  Share2,
  Upload,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { RetroAudioEngine } from '../emulator/RetroAudio';
import { getExtractedCore } from '../emulator/coreLoader';
import { getSystemById } from '../data/catalog';
import { GgpoCoordinator, GgpoInputPacket } from '../services/ggpoNetplay';
import {
  INPUT_BITS,
  MatchPhase,
  ParsedRomInfo,
  RetroCoreName,
} from '../types/retrolink';
import {
  uint8ToBase64,
  uint8ToBinaryString,
} from '../utils/crc32';
import { parseRomFile, parseRomFiles } from '../utils/romParser';
import { AndroidTouchPad } from './AndroidTouchPad';

export interface BiosArchiveFile {
  fileName: string;
  bytes: Uint8Array;
}

export interface IncomingStateSync {
  frame: number;
  engine: 'nes' | 'retro';
  bytes: Uint8Array;
  nonce: number;
}

interface EmulatorViewportProps {
  activeRom: ParsedRomInfo | null;
  activeRomBytes: Uint8Array | null;
  neogeoBiosBytes?: Uint8Array | null;
  arcadeBiosFiles?: BiosArchiveFile[];
  playerSlot: 'P1' | 'P2' | 'SPEC' | 'SOLO';
  isNetplayActive: boolean;
  peerConnected?: boolean;
  matchPhase?: MatchPhase;
  frameDelay: number;
  remoteInputRef: React.MutableRefObject<{ p1: number; p2: number }>;
  ggpoRef?: React.MutableRefObject<GgpoCoordinator | null>;
  captureStateRef?: React.MutableRefObject<
    (() => Promise<{ frame: number; engine: 'nes' | 'retro'; bytes: Uint8Array } | null>) | null
  >;
  incomingStateSync?: IncomingStateSync | null;
  onSendLocalInput?: (frame: number, mask: number, hist?: [number, number][]) => void;
  onGgpoStats?: (stats: { rollbackCount: number; frameAdvantage: number }) => void;
  onShareNesRom?: (fileName: string, base64: string) => void;
  onShareRomBytes?: (fileName: string, bytes: Uint8Array) => void;
  incomingSharedRom?: { fileName: string; base64: string } | null;
  incomingSharedRomBytes?: { fileName: string; bytes: Uint8Array } | null;
  onRomFileLoaded?: (info: ParsedRomInfo, bytes: Uint8Array) => void;
  onRomFilesSelected?: (files: FileList | File[]) => void;
  onHostPauseChange?: (paused: boolean) => void;
  onHostReset?: () => void;
}

const KEY_TO_BIT: Record<string, number> = {
  ArrowUp: INPUT_BITS.UP,
  KeyW: INPUT_BITS.UP,
  ArrowDown: INPUT_BITS.DOWN,
  KeyS: INPUT_BITS.DOWN,
  ArrowLeft: INPUT_BITS.LEFT,
  KeyA: INPUT_BITS.LEFT,
  ArrowRight: INPUT_BITS.RIGHT,
  KeyD: INPUT_BITS.RIGHT,
  KeyZ: INPUT_BITS.B,
  KeyK: INPUT_BITS.B,
  KeyX: INPUT_BITS.A,
  KeyJ: INPUT_BITS.A,
  KeyC: INPUT_BITS.X,
  KeyU: INPUT_BITS.X,
  KeyV: INPUT_BITS.Y,
  KeyI: INPUT_BITS.Y,
  KeyQ: INPUT_BITS.L1,
  KeyE: INPUT_BITS.R1,
  Digit1: INPUT_BITS.L2,
  Digit2: INPUT_BITS.R2,
  Enter: INPUT_BITS.START,
  ShiftLeft: INPUT_BITS.SELECT,
  ShiftRight: INPUT_BITS.SELECT,
};

function applyJsnesMask(nes: NES, player: 1 | 2, prevMask: number, nextMask: number) {
  const mappings: [number, number][] = [
    [INPUT_BITS.UP, Controller.BUTTON_UP],
    [INPUT_BITS.DOWN, Controller.BUTTON_DOWN],
    [INPUT_BITS.LEFT, Controller.BUTTON_LEFT],
    [INPUT_BITS.RIGHT, Controller.BUTTON_RIGHT],
    [INPUT_BITS.A, Controller.BUTTON_A],
    [INPUT_BITS.B, Controller.BUTTON_B],
    [INPUT_BITS.START, Controller.BUTTON_START],
    [INPUT_BITS.SELECT, Controller.BUTTON_SELECT],
  ];
  for (const [bit, btn] of mappings) {
    const wasOn = (prevMask & bit) !== 0;
    const isOn = (nextMask & bit) !== 0;
    if (!wasOn && isOn) nes.buttonDown(player, btn);
    else if (wasOn && !isOn) nes.buttonUp(player, btn);
  }
}

const RETRO_BUTTON_MAP: [number, string][] = [
  [INPUT_BITS.UP, 'up'],
  [INPUT_BITS.DOWN, 'down'],
  [INPUT_BITS.LEFT, 'left'],
  [INPUT_BITS.RIGHT, 'right'],
  [INPUT_BITS.A, 'a'],
  [INPUT_BITS.B, 'b'],
  [INPUT_BITS.X, 'x'],
  [INPUT_BITS.Y, 'y'],
  [INPUT_BITS.L1, 'l'],
  [INPUT_BITS.R1, 'r'],
  [INPUT_BITS.L2, 'l2'],
  [INPUT_BITS.R2, 'r2'],
  [INPUT_BITS.START, 'start'],
  [INPUT_BITS.SELECT, 'select'],
];

function applyRetroArchMask(
  instance: Nostalgist,
  player: 1 | 2,
  prevMask: number,
  nextMask: number
) {
  for (const [bit, button] of RETRO_BUTTON_MAP) {
    const wasOn = (prevMask & bit) !== 0;
    const isOn = (nextMask & bit) !== 0;
    if (!wasOn && isOn) {
      instance.pressDown({ button, player });
    } else if (wasOn && !isOn) {
      instance.pressUp({ button, player });
    }
  }
}

function base64ToUint8(base64: string): Uint8Array {
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) {
    out[i] = raw.charCodeAt(i);
  }
  return out;
}

export function EmulatorViewport({
  activeRom,
  activeRomBytes,
  neogeoBiosBytes,
  arcadeBiosFiles,
  playerSlot,
  isNetplayActive,
  peerConnected = false,
  matchPhase = 'playing',
  frameDelay,
  remoteInputRef,
  ggpoRef,
  captureStateRef,
  incomingStateSync,
  onSendLocalInput,
  onGgpoStats,
  onShareNesRom,
  onShareRomBytes,
  incomingSharedRom,
  incomingSharedRomBytes,
  onRomFileLoaded,
  onRomFilesSelected,
  onHostPauseChange,
  onHostReset,
}: EmulatorViewportProps) {
  const nesCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const retroCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const audioRef = useRef<RetroAudioEngine | null>(null);
  const nesRef = useRef<NES | null>(null);
  const nostalgistRef = useRef<Nostalgist | null>(null);
  const launchTokenRef = useRef<number>(0);
  const nesImageDataRef = useRef<ImageData | null>(null);

  const activeMaskRef = useRef<number>(0);
  const touchMaskRef = useRef<number>(0);
  const prevP1Ref = useRef<number>(0);
  const prevP2Ref = useRef<number>(0);
  const lastSentMaskRef = useRef<number>(-1);
  const frameCounterRef = useRef<number>(0);
  const inputBufferRef = useRef<number[]>([]);
  const savedStateBlobRef = useRef<Blob | null>(null);
  const localGgpoRef = useRef<GgpoCoordinator>(new GgpoCoordinator(playerSlot, frameDelay));

  const [engineMode, setEngineMode] = useState<'none' | 'nes' | 'retro'>('none');
  const [retroCanvasKey, setRetroCanvasKey] = useState(0);
  const [engineReady, setEngineReady] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState<string | null>(null);
  const [loadedFileLabel, setLoadedFileLabel] = useState<string | null>(null);
  const [lastShareBase64, setLastShareBase64] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [scanlines, setScanlines] = useState(false);
  const [muted, setMuted] = useState(false);
  const [showTouchPad, setShowTouchPad] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [romError, setRomError] = useState<string | null>(null);
  const [gamepadConnected, setGamepadConnected] = useState(false);
  const [hasSavedState, setHasSavedState] = useState(false);

  const isGuestLocked = isNetplayActive && playerSlot === 'P2';
  const effectivePaused = paused || (isNetplayActive && matchPhase === 'paused');

  useEffect(() => {
    const coordinator = ggpoRef?.current || localGgpoRef.current;
    coordinator.setSlotAndDelay(playerSlot, frameDelay);
  }, [playerSlot, frameDelay, ggpoRef]);

  useEffect(() => {
    if (!nostalgistRef.current || !isNetplayActive) return;
    if (matchPhase === 'paused') {
      nostalgistRef.current.pause();
    } else if (!paused) {
      nostalgistRef.current.resume();
    }
  }, [matchPhase, isNetplayActive, paused]);

  useEffect(() => {
    const audio = new RetroAudioEngine();
    audio.setMuted(false);
    audioRef.current = audio;
    return () => {
      audio.dispose();
    };
  }, []);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  useEffect(() => {
    if (!captureStateRef) return;
    captureStateRef.current = async () => {
      const coordinator = ggpoRef?.current || localGgpoRef.current;
      const frame = coordinator.currentFrame;
      if (nesRef.current) {
        const json = JSON.stringify(nesRef.current.toJSON());
        return {
          frame,
          engine: 'nes',
          bytes: new TextEncoder().encode(json),
        };
      }
      const instance = nostalgistRef.current;
      if (instance && engineReady) {
        try {
          if (instance.getStatus() === 'paused') {
            instance.resume();
            await new Promise((resolve) => window.setTimeout(resolve, 60));
          }
          if (instance.getStatus() !== 'running') {
            return null;
          }
          const result = await Promise.race([
            instance.saveState(),
            new Promise<null>((resolve) => window.setTimeout(() => resolve(null), 3500)),
          ]);
          if (!result) return null;
          const buf = await result.state.arrayBuffer();
          return {
            frame,
            engine: 'retro',
            bytes: new Uint8Array(buf),
          };
        } catch {
          // Non-fatal: some arcade/optical cores or boot frames cannot serialize immediately
          return null;
        }
      }
      return null;
    };
    return () => {
      if (captureStateRef) captureStateRef.current = null;
    };
  }, [captureStateRef, ggpoRef, engineReady]);

  useEffect(() => {
    if (!incomingStateSync) return;
    const coordinator = ggpoRef?.current || localGgpoRef.current;

    const applySync = async () => {
      if (incomingStateSync.engine === 'nes' && nesRef.current) {
        const jsonText = new TextDecoder().decode(incomingStateSync.bytes);
        const parsedState = JSON.parse(jsonText);
        nesRef.current.fromJSON(parsedState);
        prevP1Ref.current = 0;
        prevP2Ref.current = 0;
        coordinator.reset(incomingStateSync.frame);
        frameCounterRef.current = incomingStateSync.frame;
        return;
      }
      if (incomingStateSync.engine === 'retro' && nostalgistRef.current) {
        const blob = new Blob([new Uint8Array(incomingStateSync.bytes)], {
          type: 'application/octet-stream',
        });
        await nostalgistRef.current.loadState(blob);
        prevP1Ref.current = 0;
        prevP2Ref.current = 0;
        coordinator.reset(incomingStateSync.frame);
        frameCounterRef.current = incomingStateSync.frame;
      }
    };

    void applySync().catch(() => {
      // ignore invalid state snapshot during core boot
    });
  }, [incomingStateSync?.nonce, ggpoRef]);

  const stopAllEngines = () => {
    launchTokenRef.current += 1;
    nesRef.current = null;
    if (nostalgistRef.current) {
      try {
        nostalgistRef.current.exit({ removeCanvas: false });
      } catch {
        // ignore exit error
      }
      nostalgistRef.current = null;
    }
    prevP1Ref.current = 0;
    prevP2Ref.current = 0;
    lastSentMaskRef.current = -1;
    setEngineReady(false);
    setPaused(false);
  };

  useEffect(() => {
    return () => {
      stopAllEngines();
    };
  }, []);

  useEffect(() => {
    if (!activeRom || !activeRomBytes) {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(null);
      setLoadingLabel(null);
      return;
    }

    if (activeRom.isBios) {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(activeRom.fileName);
      setLoadingLabel(null);
      setRomError(
        `BIOS (${activeRom.fileName}) salva! Agora selecione o arquivo do jogo para iniciar.`
      );
      return;
    }

    if (!activeRom.playableInBrowser || activeRom.coreName === 'unsupported') {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(activeRom.fileName);
      setLoadingLabel(null);
      setRomError(
        `ROM identificada (${activeRom.title}). Este sistema (${activeRom.systemId.toUpperCase()}) ainda não possui núcleo WASM compatível no aparelho; use SNES, Mega Drive, NES, GBA/GBC, PlayStation 1, Neo Geo, CPS-2 ou Arcade.`
      );
      return;
    }

    const effectiveBytes = activeRom.effectiveBytes || activeRomBytes;
    const effectiveName = activeRom.effectiveFileName || activeRom.fileName;

    if (activeRomBytes.length <= 8_000_000) {
      setLastShareBase64(uint8ToBase64(activeRomBytes));
    } else {
      setLastShareBase64(null);
    }

    const coordinator = ggpoRef?.current || localGgpoRef.current;
    coordinator.reset(0);
    frameCounterRef.current = 0;

    if (activeRom.coreName === 'jsnes') {
      stopAllEngines();
      const nesToken = launchTokenRef.current;
      setEngineMode('nes');
      setLoadingLabel(null);
      try {
        const binaryStr = uint8ToBinaryString(effectiveBytes);
        bootJsnesFromBinary(binaryStr, activeRom.title);
      } catch {
        setEngineMode('retro');
        setRetroCanvasKey((k) => k + 1);
        setLoadingLabel(`Abrindo ${activeRom.title} no núcleo FCEUmm...`);
        const fallbackTimer = window.setTimeout(() => {
          void bootRetroCore(nesToken, activeRom, effectiveName, effectiveBytes, 'fceumm');
        }, 30);
        return () => {
          window.clearTimeout(fallbackTimer);
        };
      }
      return;
    }

    stopAllEngines();
    const token = launchTokenRef.current;
    setEngineMode('retro');
    setRetroCanvasKey((k) => k + 1);
    setRomError(null);
    setHasSavedState(false);
    savedStateBlobRef.current = null;
    setLoadingLabel(`Carregando ${activeRom.title}...`);

    const timer = window.setTimeout(() => {
      void bootRetroCore(token, activeRom, effectiveName, effectiveBytes);
    }, 30);

    return () => {
      window.clearTimeout(timer);
    };
  }, [activeRom?.romId, activeRomBytes]);

  useEffect(() => {
    if (!incomingSharedRom) return;
    try {
      const bytes = base64ToUint8(incomingSharedRom.base64);
      const parsed = parseRomFile(incomingSharedRom.fileName, bytes);
      onRomFileLoaded?.(parsed, parsed.effectiveBytes || bytes);
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Falha ao abrir ROM compartilhada.');
    }
  }, [incomingSharedRom]);

  useEffect(() => {
    if (!incomingSharedRomBytes) return;
    try {
      const parsed = parseRomFile(incomingSharedRomBytes.fileName, incomingSharedRomBytes.bytes);
      onRomFileLoaded?.(parsed, parsed.effectiveBytes || incomingSharedRomBytes.bytes);
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Falha ao abrir ROM recebida via P2P.');
    }
  }, [incomingSharedRomBytes]);

  const bootRetroCore = async (
    token: number,
    romInfo: ParsedRomInfo,
    effectiveName: string,
    effectiveBytes: Uint8Array,
    overrideCore?: RetroCoreName
  ) => {
    const canvas = retroCanvasRef.current;
    if (!canvas) return;

    const coreName = overrideCore || romInfo.coreName;
    try {
      const extracted = await getExtractedCore(coreName);
      if (launchTokenRef.current !== token) return;

      const romCopy = new Uint8Array(effectiveBytes);
      const biosEntries: Array<{ fileName: string; fileContent: Blob }> = [];
      if (arcadeBiosFiles && arcadeBiosFiles.length > 0) {
        for (const bios of arcadeBiosFiles) {
          biosEntries.push({
            fileName: bios.fileName,
            fileContent: new Blob([new Uint8Array(bios.bytes)]),
          });
        }
      } else if (neogeoBiosBytes) {
        biosEntries.push({
          fileName: 'neogeo.zip',
          fileContent: new Blob([new Uint8Array(neogeoBiosBytes)]),
        });
      }

      // CRITICAL INPUT ISOLATION FIX:
      // In Online Netplay, disable RetroArch's direct raw joypad polling (index 99 + autodetect false)
      // so Phone 2's Bluetooth gamepad/keyboard NEVER leaks into RetroArch Port 1 directly.
      // All inputs flow strictly through our deterministic P1/P2 port router below.
      const retroarchCoreConfig: Record<string, string> = {};
      if (romInfo.systemId === 'megadrive') {
        retroarchCoreConfig.genesis_plus_gx_pad_type = '6 button';
      }

      const instance = await Nostalgist.launch({
        element: canvas,
        core: {
          name: coreName,
          js: extracted.jsBlob,
          wasm: extracted.wasmBlob,
        },
        rom: {
          fileName: effectiveName,
          fileContent: new Blob([romCopy]),
        },
        bios: biosEntries.length > 0 ? biosEntries : undefined,
        size: 'auto',
        respondToGlobalEvents: false,
        retroarchCoreConfig,
        retroarchConfig: {
          audio_mute_enable: muted,
          video_smooth: false,
          savestate_auto_load: false,
          savestate_thumbnail_enable: false,
          savestate_auto_index: false,
          savestates_in_content_dir: false,
          suspend_screensaver_enable: false,
          input_autodetect_enable: !isNetplayActive,
          input_player1_joypad_index: isNetplayActive ? 99 : 0,
          input_player2_joypad_index: isNetplayActive ? 99 : 1,
          input_player3_joypad_index: 99,
          input_player4_joypad_index: 99,
          input_libretro_device_p1: 1,
          input_libretro_device_p2: 1,
          input_player1_up: 'up',
          input_player1_down: 'down',
          input_player1_left: 'left',
          input_player1_right: 'right',
          input_player1_a: 'x',
          input_player1_b: 'z',
          input_player1_x: 's',
          input_player1_y: 'a',
          input_player1_l: 'q',
          input_player1_r: 'w',
          input_player1_l2: 'e',
          input_player1_r2: 'r',
          input_player1_start: 'enter',
          input_player1_select: 'rshift',
          input_player2_up: 'i',
          input_player2_down: 'k',
          input_player2_left: 'j',
          input_player2_right: 'l',
          input_player2_a: 'o',
          input_player2_b: 'u',
          input_player2_x: 'p',
          input_player2_y: 'y',
          input_player2_l: 'n',
          input_player2_r: 'm',
          input_player2_l2: 'b',
          input_player2_r2: 'v',
          input_player2_start: 'space',
          input_player2_select: 'tab',
        },
      });

      if (launchTokenRef.current !== token) {
        instance.exit({ removeCanvas: false });
        return;
      }

      try {
        const fs = instance.getEmscriptenFS();
        const emu = instance.getEmulator() as unknown as { stateFileDirectory?: string };
        if (emu?.stateFileDirectory) {
          fs.mkdirTree(emu.stateFileDirectory);
        }
      } catch {
        // state directory creation optional
      }

      nostalgistRef.current = instance;
      setEngineReady(true);
      setLoadingLabel(null);
      setLoadedFileLabel(romInfo.title);
      setRomError(null);
    } catch (err) {
      if (launchTokenRef.current !== token) return;
      if (!overrideCore && romInfo.fallbackCoreName && romInfo.fallbackCoreName !== coreName) {
        setLoadingLabel(`Tentando núcleo alternativo (${romInfo.fallbackCoreName})...`);
        setRetroCanvasKey((k) => k + 1);
        window.setTimeout(() => {
          void bootRetroCore(token, romInfo, effectiveName, effectiveBytes, romInfo.fallbackCoreName);
        }, 40);
        return;
      }

      setLoadingLabel(null);
      setEngineReady(false);
      const rawMsg = err instanceof Error ? err.message : 'Falha ao iniciar o emulador.';
      const hasNeogeoBios =
        Boolean(neogeoBiosBytes) ||
        Boolean(arcadeBiosFiles?.some((b) => b.fileName.toLowerCase().includes('neogeo')));
      if (romInfo.systemId === 'neogeo' && !hasNeogeoBios) {
        setRomError(
          `Erro ao abrir Neo Geo (${rawMsg}). Dica: adicione também sua BIOS "neogeo.zip" em Seus Jogos para rodar jogos MVS/AES.`
        );
      } else if (romInfo.systemId === 'ps1') {
        setRomError(
          `Erro ao abrir PlayStation 1 (${rawMsg}). Dica: use imagens em .chd, .pbp ou .iso de arquivo único (opcionalmente adicione scph1001.bin / scph5501.bin em Seus Jogos).`
        );
      } else {
        setRomError(`Não foi possível iniciar "${romInfo.title}": ${rawMsg}`);
      }
    }
  };

  // Capture-phase keyboard blocker on canvas so raw trusted browser keystrokes on P2
  // NEVER bypass our slot router to trigger RetroArch Player 1 directly.
  useEffect(() => {
    const canvas = retroCanvasRef.current;
    if (!canvas || engineMode !== 'retro') return;

    const blockTrustedCanvasKey = (e: KeyboardEvent) => {
      if (!e.isTrusted) return;
      const bit = KEY_TO_BIT[e.code];
      if (bit) {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'keydown') {
          activeMaskRef.current |= bit;
        } else if (e.type === 'keyup') {
          activeMaskRef.current &= ~bit;
        }
      }
    };

    canvas.addEventListener('keydown', blockTrustedCanvasKey, true);
    canvas.addEventListener('keyup', blockTrustedCanvasKey, true);
    return () => {
      canvas.removeEventListener('keydown', blockTrustedCanvasKey, true);
      canvas.removeEventListener('keyup', blockTrustedCanvasKey, true);
    };
  }, [engineMode, retroCanvasKey]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      const bit = KEY_TO_BIT[e.code];
      if (bit) {
        e.preventDefault();
        activeMaskRef.current |= bit;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const bit = KEY_TO_BIT[e.code];
      if (bit) {
        activeMaskRef.current &= ~bit;
      }
    };
    const onGamepadConnected = () => setGamepadConnected(true);
    const onGamepadDisconnected = () => setGamepadConnected(false);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('gamepadconnected', onGamepadConnected);
    window.addEventListener('gamepaddisconnected', onGamepadDisconnected);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('gamepadconnected', onGamepadConnected);
      window.removeEventListener('gamepaddisconnected', onGamepadDisconnected);
    };
  }, []);

  const readGamepadMask = (): number => {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const pad = pads[0];
    if (!pad) return 0;
    let mask = 0;
    if (pad.axes[1] < -0.45 || pad.buttons[12]?.pressed) mask |= INPUT_BITS.UP;
    if (pad.axes[1] > 0.45 || pad.buttons[13]?.pressed) mask |= INPUT_BITS.DOWN;
    if (pad.axes[0] < -0.45 || pad.buttons[14]?.pressed) mask |= INPUT_BITS.LEFT;
    if (pad.axes[0] > 0.45 || pad.buttons[15]?.pressed) mask |= INPUT_BITS.RIGHT;
    if (pad.buttons[1]?.pressed) mask |= INPUT_BITS.A;
    if (pad.buttons[0]?.pressed) mask |= INPUT_BITS.B;
    if (pad.buttons[3]?.pressed) mask |= INPUT_BITS.X;
    if (pad.buttons[2]?.pressed) mask |= INPUT_BITS.Y;
    if (pad.buttons[4]?.pressed) mask |= INPUT_BITS.L1;
    if (pad.buttons[5]?.pressed) mask |= INPUT_BITS.R1;
    if (pad.buttons[6]?.pressed) mask |= INPUT_BITS.L2;
    if (pad.buttons[7]?.pressed) mask |= INPUT_BITS.R2;
    if (pad.buttons[8]?.pressed) mask |= INPUT_BITS.SELECT;
    if (pad.buttons[9]?.pressed) mask |= INPUT_BITS.START;
    return mask;
  };

  useEffect(() => {
    if (!engineReady) return;
    let rafId = 0;
    let lastTime = performance.now();
    let accumulator = 0;
    let statsCounter = 0;
    const STEP_MS = 1000 / 60;

    const tick = (now: number) => {
      const delta = Math.min(64, now - lastTime);
      lastTime = now;

      if (!effectivePaused && (nesRef.current || nostalgistRef.current)) {
        const coordinator = ggpoRef?.current || localGgpoRef.current;

        accumulator += delta;
        while (accumulator >= STEP_MS) {
          accumulator -= STEP_MS;

          // Drift protection: wait briefly if we are way ahead of peer's confirmed frame
          if (isNetplayActive && coordinator.shouldWaitForRemote(peerConnected)) {
            break;
          }

          // GGPO Rollback on JSNES if a mispredicted remote input just arrived
          if (isNetplayActive && nesRef.current) {
            const rollbackFrame = coordinator.consumeRollbackTarget();
            if (rollbackFrame !== null) {
              const snap = coordinator.getFrameSnapshot(rollbackFrame);
              if (snap) {
                nesRef.current.fromJSON(snap);
                let simPrevP1 = 0;
                let simPrevP2 = 0;
                for (let f = rollbackFrame; f <= coordinator.currentFrame; f++) {
                  const { p1Mask: rp1, p2Mask: rp2 } = coordinator.getFrameMasks(
                    f,
                    remoteInputRef.current
                  );
                  applyJsnesMask(nesRef.current, 1, simPrevP1, rp1);
                  applyJsnesMask(nesRef.current, 2, simPrevP2, rp2);
                  simPrevP1 = rp1;
                  simPrevP2 = rp2;
                  coordinator.saveFrameSnapshot(f, nesRef.current.toJSON());
                  nesRef.current.frame();
                }
                prevP1Ref.current = simPrevP1;
                prevP2Ref.current = simPrevP2;
                coordinator.incrementRollbackCount();
              }
            }
          }

          frameCounterRef.current += 1;
          const currentFrame = frameCounterRef.current;
          coordinator.currentFrame = currentFrame;

          // Enforce Host-only Main Menu rule:
          // While matchPhase === 'menu', Guest (P2) cannot inject commands into the main menu.
          const rawHardwareInput = activeMaskRef.current | touchMaskRef.current | readGamepadMask();
          const localInput =
            isNetplayActive && playerSlot === 'P2' && matchPhase === 'menu' ? 0 : rawHardwareInput;

          let packetToSend: GgpoInputPacket | null = null;
          if (isNetplayActive && (playerSlot === 'P1' || playerSlot === 'P2')) {
            const recorded = coordinator.recordLocalInput(localInput);
            const changed = localInput !== lastSentMaskRef.current;
            const heartbeat = currentFrame % 6 === 0;
            if (changed || heartbeat || localInput !== 0) {
              lastSentMaskRef.current = localInput;
              packetToSend = recorded.packet;
            }
            if (packetToSend) {
              onSendLocalInput?.(packetToSend.f, packetToSend.m, packetToSend.hist);
            }
          } else {
            inputBufferRef.current.push(localInput);
            while (inputBufferRef.current.length > 1) {
              inputBufferRef.current.shift();
            }
          }

          let p1Mask = 0;
          let p2Mask = 0;

          if (!isNetplayActive || playerSlot === 'SOLO') {
            p1Mask = localInput;
            p2Mask = 0;
          } else {
            const masks = coordinator.getFrameMasks(currentFrame, remoteInputRef.current);
            p1Mask = masks.p1Mask;
            p2Mask = masks.p2Mask;
          }

          if (nesRef.current) {
            if (isNetplayActive) {
              coordinator.saveFrameSnapshot(currentFrame, nesRef.current.toJSON());
            }
            applyJsnesMask(nesRef.current, 1, prevP1Ref.current, p1Mask);
            applyJsnesMask(nesRef.current, 2, prevP2Ref.current, p2Mask);
            prevP1Ref.current = p1Mask;
            prevP2Ref.current = p2Mask;
            nesRef.current.frame();
          } else if (nostalgistRef.current) {
            applyRetroArchMask(nostalgistRef.current, 1, prevP1Ref.current, p1Mask);
            applyRetroArchMask(nostalgistRef.current, 2, prevP2Ref.current, p2Mask);
            prevP1Ref.current = p1Mask;
            prevP2Ref.current = p2Mask;
          }

          statsCounter += 1;
          if (isNetplayActive && statsCounter % 30 === 0 && onGgpoStats) {
            const s = coordinator.getStats();
            onGgpoStats({ rollbackCount: s.rollbackCount, frameAdvantage: s.frameAdvantage });
          }
        }

        if (nesRef.current) {
          const canvas = nesCanvasRef.current;
          const ctx = canvas?.getContext('2d');
          if (canvas && ctx && nesImageDataRef.current) {
            if (canvas.width !== 256 || canvas.height !== 240) {
              canvas.width = 256;
              canvas.height = 240;
            }
            ctx.putImageData(nesImageDataRef.current, 0, 0);
          }
        }
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [
    engineReady,
    effectivePaused,
    isNetplayActive,
    peerConnected,
    matchPhase,
    playerSlot,
    frameDelay,
    ggpoRef,
  ]);

  const bootJsnesFromBinary = (binaryStr: string, displayTitle: string) => {
    const canvas = nesCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx) {
      nesImageDataRef.current = ctx.createImageData(256, 240);
    }

    const nes = new NES({
      emulateSound: true,
      sampleRate: audioRef.current?.sampleRate || 44100,
      onFrame: (frameBuffer) => {
        const imgData = nesImageDataRef.current;
        if (!imgData) return;
        const data32 = new Uint32Array(imgData.data.buffer);
        for (let i = 0; i < 256 * 240; i++) {
          data32[i] = 0xff000000 | frameBuffer[i];
        }
      },
      onAudioSample: (left, right) => {
        audioRef.current?.pushNesSample(left, right);
      },
    });
    nes.loadROM(binaryStr);
    nesRef.current = nes;
    prevP1Ref.current = 0;
    prevP2Ref.current = 0;
    setEngineReady(true);
    setLoadedFileLabel(displayTitle);
    setRomError(null);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setRomError(null);

    if (onRomFilesSelected) {
      onRomFilesSelected(files);
      e.target.value = '';
      return;
    }

    const file = files[0];
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const parsedList = parseRomFiles(file.name, bytes);
      for (const parsed of parsedList) {
        onRomFileLoaded?.(parsed, parsed.effectiveBytes || bytes);
      }
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Arquivo de ROM inválido.');
    }
    e.target.value = '';
  };

  const togglePause = () => {
    if (isGuestLocked) return;
    const next = !paused;
    setPaused(next);
    if (nostalgistRef.current) {
      if (next) nostalgistRef.current.pause();
      else nostalgistRef.current.resume();
    }
    if (isNetplayActive && playerSlot === 'P1') {
      onHostPauseChange?.(next);
    }
  };

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    audioRef.current?.setMuted(next);
    if (nostalgistRef.current) {
      nostalgistRef.current.sendCommand('MUTE');
    }
  };

  const handleReset = () => {
    if (isGuestLocked) return;
    const coordinator = ggpoRef?.current || localGgpoRef.current;
    coordinator.reset(0);
    frameCounterRef.current = 0;
    if (nesRef.current) {
      nesRef.current.reset();
    } else if (nostalgistRef.current) {
      nostalgistRef.current.restart();
    }
    setPaused(false);
    if (isNetplayActive && playerSlot === 'P1') {
      onHostReset?.();
    }
  };

  const handleSaveState = async () => {
    if (isGuestLocked || !nostalgistRef.current || !engineReady) return;
    try {
      const res = await Promise.race([
        nostalgistRef.current.saveState(),
        new Promise<null>((resolve) => window.setTimeout(() => resolve(null), 4000)),
      ]);
      if (!res) {
        setRomError('Este jogo/núcleo não concluiu o Save State a tempo.');
        return;
      }
      savedStateBlobRef.current = res.state;
      setHasSavedState(true);
    } catch {
      setRomError('Este núcleo ou ROM não suporta Save State neste momento.');
    }
  };

  const handleLoadState = async () => {
    if (isGuestLocked || !nostalgistRef.current || !savedStateBlobRef.current) return;
    try {
      await nostalgistRef.current.loadState(savedStateBlobRef.current);
    } catch {
      setRomError('Não foi possível restaurar o Save State neste núcleo.');
    }
  };

  const handleFullscreen = async () => {
    if (!containerRef.current) return;
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      return;
    }
    if (containerRef.current.requestFullscreen) {
      await containerRef.current.requestFullscreen();
      try {
        const orientation = screen.orientation as unknown as { lock?: (o: string) => Promise<void> };
        if (orientation?.lock) {
          await orientation.lock('landscape');
        }
      } catch {
        // orientation lock optional
      }
    }
  };

  const sysInfo = activeRom ? getSystemById(activeRom.systemId) : undefined;

  return (
    <div
      ref={containerRef}
      className={`flex flex-col border border-white/10 bg-[#15181E] rounded-2xl overflow-hidden ${
        isFullscreen ? 'h-screen w-screen rounded-none border-none justify-between bg-black' : ''
      }`}
    >
      {/* Top ROM Info & Open ROM Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-white/10 bg-[#111318]">
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-white truncate flex items-center gap-2">
            <span className="truncate">{loadedFileLabel || activeRom?.title || 'Nenhuma ROM selecionada'}</span>
            {isNetplayActive && (
              <span
                className={`px-2 py-0.5 rounded-md text-[10px] font-mono-tabular uppercase shrink-0 ${
                  playerSlot === 'P1'
                    ? 'bg-[#EA580C]/20 text-[#FB923C] border border-[#EA580C]/40'
                    : 'bg-[#0EA5E9]/20 text-[#38BDF8] border border-[#0EA5E9]/40'
                }`}
              >
                {playerSlot === 'P1' ? 'Você: P1 Host' : 'Você: P2 Convidado'}
              </span>
            )}
          </div>
          {activeRom && (
            <div className="text-[11px] text-[#9AA3B2] font-mono-tabular truncate">
              {sysInfo?.shortName || activeRom.systemId.toUpperCase()} · {activeRom.headerSummary} · CRC{' '}
              {activeRom.crc32}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={(e) => void handleFileChange(e)}
            className="hidden"
          />

          {!isGuestLocked ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3.5 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              Abrir ROM(s)
            </button>
          ) : (
            <span className="min-h-[38px] inline-flex items-center gap-1.5 px-3 text-[11px] font-medium bg-[#1C2028] text-[#9AA3B2] border border-white/10 rounded-xl whitespace-nowrap shrink-0">
              <Lock className="w-3.5 h-3.5 text-[#F59E0B]" />
              Host escolhe o jogo
            </span>
          )}

          {isNetplayActive &&
            playerSlot === 'P1' &&
            engineReady &&
            activeRomBytes &&
            (onShareRomBytes || (lastShareBase64 && onShareNesRom)) && (
              <button
                type="button"
                onClick={() => {
                  if (onShareRomBytes && activeRomBytes) {
                    onShareRomBytes(activeRom?.fileName || 'game.rom', activeRomBytes);
                  } else if (onShareNesRom && lastShareBase64) {
                    onShareNesRom(activeRom?.fileName || 'game.rom', lastShareBase64);
                  }
                }}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1E232D] hover:bg-[#272D39] text-white border border-white/15 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                Enviar P2
              </button>
            )}
        </div>
      </div>

      {/* Emulator Game Screen Area */}
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (isGuestLocked) return;
          if (e.dataTransfer.files && e.dataTransfer.files.length > 0 && onRomFilesSelected) {
            onRomFilesSelected(e.dataTransfer.files);
          }
        }}
        className={`relative bg-[#07080A] flex items-center justify-center w-full overflow-hidden ${
          isFullscreen ? 'flex-1 min-h-0' : 'aspect-[4/3] max-h-[440px]'
        }`}
      >
        <canvas
          ref={nesCanvasRef}
          width={256}
          height={240}
          className={`pixelated-canvas w-full h-full object-contain ${
            engineMode === 'nes' && engineReady ? 'block' : 'hidden'
          }`}
        />

        {engineMode === 'retro' && (
          <canvas
            key={retroCanvasKey}
            ref={retroCanvasRef}
            className={`pixelated-canvas w-full h-full object-contain ${engineReady ? 'block' : 'hidden'}`}
          />
        )}

        {engineReady && scanlines && <div className="crt-scanlines absolute inset-0" />}

        {loadingLabel && (
          <div className="absolute inset-0 bg-[#07080A]/90 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <Loader2 className="w-7 h-7 text-[#EA580C] animate-spin" />
            <div className="text-sm font-semibold text-white">{loadingLabel}</div>
            <div className="text-xs text-[#9AA3B2]">
              Lendo cabeçalho da ROM e iniciando núcleo {sysInfo?.nativeCore || 'RetroArch'}...
            </div>
          </div>
        )}

        {!engineReady && !loadingLabel && (
          <div className="p-6 max-w-md text-center space-y-4">
            <h3 className="text-base font-semibold text-white">
              {isGuestLocked
                ? 'Aguardando o Host (P1) carregar o jogo...'
                : activeRom
                ? activeRom.title
                : 'Escolha uma ou várias ROMs para jogar'}
            </h3>
            <p className="text-xs text-[#9AA3B2] leading-relaxed">
              {isGuestLocked ? (
                'O anfitrião (P1) escolhe o jogo e inicia a partida. Assim que ele enviar ou abrir a ROM, a tela aparecerá aqui automaticamente com seus controles exclusivos do Jogador 2.'
              ) : (
                <>
                  Aceita ROMs clássicas:{' '}
                  <span className="text-white">
                    Mega Drive (.md/.bin/.gen/.32x), SNES (.sfc/.smc), Arcade/MAME/Neo Geo (.zip/.fba),
                    PlayStation 1 (.chd/.pbp/.iso), NES (.nes), GBA/GBC e PC Engine
                  </span>
                  .
                </>
              )}
            </p>
            {!isGuestLocked && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                Selecionar ROMs do Aparelho
              </button>
            )}
          </div>
        )}

        {engineReady && effectivePaused && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center pointer-events-none">
            <span className="text-sm font-semibold text-white bg-[#15181E] border border-white/15 px-4 py-2 rounded-xl">
              {isGuestLocked ? 'Pausado pelo Host (P1)' : 'Pausado'}
            </span>
          </div>
        )}

        {engineReady && isNetplayActive && playerSlot === 'P2' && matchPhase === 'menu' && !effectivePaused && (
          <div className="absolute top-3 left-3 right-3 flex justify-center pointer-events-none">
            <div className="px-3.5 py-2 rounded-xl bg-[#0D0F12]/90 border border-[#F59E0B]/45 text-xs text-[#FCD34D] flex items-center gap-2 shadow-lg">
              <Lock className="w-3.5 h-3.5 shrink-0" />
              <span>Menu Principal: somente o Host (P1) navega e inicia a partida</span>
            </div>
          </div>
        )}
      </div>

      {romError && (
        <div className="px-4 py-2.5 bg-[#2A1C12] border-t border-[#F59E0B]/30 text-xs text-[#FCD34D]">
          {romError}
        </div>
      )}

      {/* Emulator Action Strip */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 border-t border-white/10 bg-[#111318] text-xs text-[#9AA3B2]">
        <div className="flex flex-wrap items-center gap-1.5">
          {!isGuestLocked && (
            <>
              <button
                type="button"
                disabled={!engineReady}
                onClick={togglePause}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
              >
                {paused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                <span>{paused ? 'Continuar' : 'Pausar'}</span>
              </button>

              <button
                type="button"
                disabled={!engineReady}
                onClick={handleReset}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reiniciar</span>
              </button>
            </>
          )}

          <button
            type="button"
            disabled={!engineReady}
            onClick={toggleMute}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span>{muted ? 'Mudo' : 'Som'}</span>
          </button>

          {engineMode === 'retro' && engineReady && !isGuestLocked && (
            <>
              <button
                type="button"
                onClick={() => void handleSaveState()}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] text-white transition-colors cursor-pointer"
              >
                <BookmarkPlus className="w-4 h-4 text-[#F59E0B]" />
                <span>Salvar</span>
              </button>
              <button
                type="button"
                disabled={!hasSavedState}
                onClick={() => void handleLoadState()}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4 text-[#4ADE80]" />
                <span>Carregar</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => setShowTouchPad((v) => !v)}
            className={`min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl transition-colors cursor-pointer ${
              showTouchPad
                ? 'bg-[#EA580C]/20 text-[#FB923C] border border-[#EA580C]/40'
                : 'bg-[#1C2028] text-[#9AA3B2]'
            }`}
          >
            <Gamepad className="w-4 h-4" />
            <span>Joystick</span>
          </button>

          <button
            type="button"
            onClick={() => setScanlines((s) => !s)}
            className={`min-h-[44px] px-3 rounded-xl transition-colors cursor-pointer ${
              scanlines ? 'bg-[#1C2028] text-white border border-white/15' : 'bg-[#1C2028] text-[#9AA3B2]'
            }`}
          >
            CRT
          </button>

          <button
            type="button"
            onClick={() => void handleFullscreen()}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] text-white transition-colors cursor-pointer"
          >
            <Maximize2 className="w-4 h-4" />
            <span>{isFullscreen ? 'Sair' : 'Tela Cheia'}</span>
          </button>
        </div>

        <span className="hidden lg:inline font-mono-tabular text-[11px] text-[#8E98A8]">
          {gamepadConnected
            ? `Bluetooth Ativo (${playerSlot})`
            : `Porta Exclusiva: ${playerSlot} · Joystick Touch / Bluetooth`}
        </span>
      </div>

      {/* Adaptive Multi-Touch Joystick + A/B/X/Y + L1/L2/R1/R2 + Select/Start */}
      {showTouchPad && (
        <AndroidTouchPad
          systemId={activeRom?.systemId}
          gameTitle={activeRom?.title}
          compactLandscape={isFullscreen}
          onMaskChange={(mask) => {
            touchMaskRef.current = mask;
          }}
        />
      )}
    </div>
  );
}
