import React, { useEffect, useRef, useState } from 'react';
import { NES, Controller } from 'jsnes';
import { Nostalgist } from 'nostalgist';
import {
  BookmarkCheck,
  BookmarkPlus,
  Gamepad,
  Loader2,
  Maximize2,
  Pause,
  Play,
  RotateCcw,
  Share2,
  Upload,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { RetroAudioEngine } from '../emulator/RetroAudio';
import { getExtractedCore } from '../emulator/coreLoader';
import { getSystemById } from '../data/catalog';
import {
  INPUT_BITS,
  ParsedRomInfo,
  RetroCoreName,
} from '../types/retrolink';
import {
  uint8ToBase64,
  uint8ToBinaryString,
} from '../utils/crc32';
import { parseRomFile, parseRomFiles } from '../utils/romParser';
import { AndroidTouchPad } from './AndroidTouchPad';

export interface BiosArchiveFile {
  fileName: string;
  bytes: Uint8Array;
}

interface EmulatorViewportProps {
  activeRom: ParsedRomInfo | null;
  activeRomBytes: Uint8Array | null;
  neogeoBiosBytes?: Uint8Array | null;
  arcadeBiosFiles?: BiosArchiveFile[];
  playerSlot: 'P1' | 'P2' | 'SPEC' | 'SOLO';
  isNetplayActive: boolean;
  frameDelay: number;
  remoteInputRef: React.MutableRefObject<{ p1: number; p2: number }>;
  onSendLocalInput?: (frame: number, mask: number) => void;
  onShareNesRom?: (fileName: string, base64: string) => void;
  onShareRomBytes?: (fileName: string, bytes: Uint8Array) => void;
  incomingSharedRom?: { fileName: string; base64: string } | null;
  incomingSharedRomBytes?: { fileName: string; bytes: Uint8Array } | null;
  onRomFileLoaded?: (info: ParsedRomInfo, bytes: Uint8Array) => void;
  onRomFilesSelected?: (files: FileList | File[]) => void;
}

const KEY_TO_BIT: Record<string, number> = {
  ArrowUp: INPUT_BITS.UP,
  KeyW: INPUT_BITS.UP,
  ArrowDown: INPUT_BITS.DOWN,
  KeyS: INPUT_BITS.DOWN,
  ArrowLeft: INPUT_BITS.LEFT,
  KeyA: INPUT_BITS.LEFT,
  ArrowRight: INPUT_BITS.RIGHT,
  KeyD: INPUT_BITS.RIGHT,
  KeyZ: INPUT_BITS.B,
  KeyK: INPUT_BITS.B,
  KeyX: INPUT_BITS.A,
  KeyJ: INPUT_BITS.A,
  KeyC: INPUT_BITS.X,
  KeyU: INPUT_BITS.X,
  KeyV: INPUT_BITS.Y,
  KeyI: INPUT_BITS.Y,
  KeyQ: INPUT_BITS.L1,
  KeyE: INPUT_BITS.R1,
  Digit1: INPUT_BITS.L2,
  Digit2: INPUT_BITS.R2,
  Enter: INPUT_BITS.START,
  ShiftLeft: INPUT_BITS.SELECT,
  ShiftRight: INPUT_BITS.SELECT,
};

function applyJsnesMask(nes: NES, player: 1 | 2, prevMask: number, nextMask: number) {
  const mappings: [number, number][] = [
    [INPUT_BITS.UP, Controller.BUTTON_UP],
    [INPUT_BITS.DOWN, Controller.BUTTON_DOWN],
    [INPUT_BITS.LEFT, Controller.BUTTON_LEFT],
    [INPUT_BITS.RIGHT, Controller.BUTTON_RIGHT],
    [INPUT_BITS.A, Controller.BUTTON_A],
    [INPUT_BITS.B, Controller.BUTTON_B],
    [INPUT_BITS.START, Controller.BUTTON_START],
    [INPUT_BITS.SELECT, Controller.BUTTON_SELECT],
  ];
  for (const [bit, btn] of mappings) {
    const wasOn = (prevMask & bit) !== 0;
    const isOn = (nextMask & bit) !== 0;
    if (!wasOn && isOn) nes.buttonDown(player, btn);
    else if (wasOn && !isOn) nes.buttonUp(player, btn);
  }
}

const RETRO_BUTTON_MAP: [number, string][] = [
  [INPUT_BITS.UP, 'up'],
  [INPUT_BITS.DOWN, 'down'],
  [INPUT_BITS.LEFT, 'left'],
  [INPUT_BITS.RIGHT, 'right'],
  [INPUT_BITS.A, 'a'],
  [INPUT_BITS.B, 'b'],
  [INPUT_BITS.X, 'x'],
  [INPUT_BITS.Y, 'y'],
  [INPUT_BITS.L1, 'l'],
  [INPUT_BITS.R1, 'r'],
  [INPUT_BITS.L2, 'l2'],
  [INPUT_BITS.R2, 'r2'],
  [INPUT_BITS.START, 'start'],
  [INPUT_BITS.SELECT, 'select'],
];

function applyRetroArchMask(
  instance: Nostalgist,
  player: 1 | 2,
  prevMask: number,
  nextMask: number
) {
  for (const [bit, button] of RETRO_BUTTON_MAP) {
    const wasOn = (prevMask & bit) !== 0;
    const isOn = (nextMask & bit) !== 0;
    if (!wasOn && isOn) {
      instance.pressDown({ button, player });
    } else if (wasOn && !isOn) {
      instance.pressUp({ button, player });
    }
  }
}

function base64ToUint8(base64: string): Uint8Array {
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) {
    out[i] = raw.charCodeAt(i);
  }
  return out;
}

export function EmulatorViewport({
  activeRom,
  activeRomBytes,
  neogeoBiosBytes,
  arcadeBiosFiles,
  playerSlot,
  isNetplayActive,
  frameDelay,
  remoteInputRef,
  onSendLocalInput,
  onShareNesRom,
  onShareRomBytes,
  incomingSharedRom,
  incomingSharedRomBytes,
  onRomFileLoaded,
  onRomFilesSelected,
}: EmulatorViewportProps) {
  const nesCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const retroCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const gameAreaRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const audioRef = useRef<RetroAudioEngine | null>(null);
  const nesRef = useRef<NES | null>(null);
  const nostalgistRef = useRef<Nostalgist | null>(null);
  const launchTokenRef = useRef<number>(0);
  const nesImageDataRef = useRef<ImageData | null>(null);

  const activeMaskRef = useRef<number>(0);
  const touchMaskRef = useRef<number>(0);
  const prevP1Ref = useRef<number>(0);
  const prevP2Ref = useRef<number>(0);
  const frameCounterRef = useRef<number>(0);
  const inputBufferRef = useRef<number[]>([]);
  const savedStateBlobRef = useRef<Blob | null>(null);

  const [engineMode, setEngineMode] = useState<'none' | 'nes' | 'retro'>('none');
  const [retroCanvasKey, setRetroCanvasKey] = useState(0);
  const [engineReady, setEngineReady] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState<string | null>(null);
  const [loadedFileLabel, setLoadedFileLabel] = useState<string | null>(null);
  const [lastShareBase64, setLastShareBase64] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [scanlines, setScanlines] = useState(false);
  const [muted, setMuted] = useState(false);
  const [showTouchPad, setShowTouchPad] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedArcadeCore, setSelectedArcadeCore] = useState<RetroCoreName>('fbneo');
  const [romError, setRomError] = useState<string | null>(null);
  const [gamepadConnected, setGamepadConnected] = useState(false);
  const [hasSavedState, setHasSavedState] = useState(false);

  useEffect(() => {
    const audio = new RetroAudioEngine();
    audio.setMuted(false);
    audioRef.current = audio;
    return () => {
      audio.dispose();
    };
  }, []);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const stopAllEngines = () => {
    launchTokenRef.current += 1;
    nesRef.current = null;
    if (nostalgistRef.current) {
      try {
        nostalgistRef.current.exit({ removeCanvas: false });
      } catch {
        // ignore exit error
      }
      nostalgistRef.current = null;
    }
    prevP1Ref.current = 0;
    prevP2Ref.current = 0;
    setEngineReady(false);
    setPaused(false);
  };

  useEffect(() => {
    return () => {
      stopAllEngines();
    };
  }, []);

  useEffect(() => {
    if (!activeRom || !activeRomBytes) {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(null);
      setLoadingLabel(null);
      return;
    }

    if (activeRom.isBios) {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(activeRom.fileName);
      setLoadingLabel(null);
      setRomError(
        'Arquivo BIOS Neo Geo (neogeo.zip) salvo! Agora selecione qualquer ROM de Neo Geo (.zip) para jogar.'
      );
      return;
    }

    if (!activeRom.playableInBrowser || activeRom.coreName === 'unsupported') {
      stopAllEngines();
      setEngineMode('none');
      setLoadedFileLabel(activeRom.fileName);
      setLoadingLabel(null);
      setRomError(
        `ROM identificada (${activeRom.title}). Este sistema (${activeRom.systemId.toUpperCase()}) ainda não possui núcleo WASM compatível no aparelho; use SNES, Mega Drive, NES, GBA/GBC, Neo Geo, CPS-2 ou Arcade.`
      );
      return;
    }

    const effectiveBytes = activeRom.effectiveBytes || activeRomBytes;
    const effectiveName = activeRom.effectiveFileName || activeRom.fileName;

    if (activeRomBytes.length <= 8_000_000) {
      setLastShareBase64(uint8ToBase64(activeRomBytes));
    } else {
      setLastShareBase64(null);
    }

    if (activeRom.coreName === 'jsnes') {
      stopAllEngines();
      const nesToken = launchTokenRef.current;
      setEngineMode('nes');
      setLoadingLabel(null);
      try {
        const binaryStr = uint8ToBinaryString(effectiveBytes);
        bootJsnesFromBinary(binaryStr, activeRom.title);
      } catch (err) {
        // Fallback to FCEUmm Libretro core if JSNES rejects mapper/header
        setEngineMode('retro');
        setRetroCanvasKey((k) => k + 1);
        setLoadingLabel(`Abrindo ${activeRom.title} no núcleo FCEUmm...`);
        const fallbackTimer = window.setTimeout(() => {
          void bootRetroCore(nesToken, activeRom, effectiveName, effectiveBytes, 'fceumm');
        }, 30);
        return () => {
          window.clearTimeout(fallbackTimer);
        };
      }
      return;
    }

    // Boot RetroArch WASM core via Nostalgist on a clean canvas
    stopAllEngines();
    const token = launchTokenRef.current;
    setEngineMode('retro');
    setRetroCanvasKey((k) => k + 1);
    setRomError(null);
    setHasSavedState(false);
    savedStateBlobRef.current = null;
    setLoadingLabel(`Carregando ${activeRom.title}...`);

    const timer = window.setTimeout(() => {
      const arcadeCore = activeRom.systemId === 'arcade' && activeRom.coreName === 'fbneo'
        ? selectedArcadeCore
        : undefined;
      void bootRetroCore(token, activeRom, effectiveName, effectiveBytes, arcadeCore);
    }, 30);

    return () => {
      window.clearTimeout(timer);
    };
  }, [activeRom?.romId, activeRomBytes, selectedArcadeCore]);

  useEffect(() => {
    if (!incomingSharedRom) return;
    try {
      const bytes = base64ToUint8(incomingSharedRom.base64);
      const parsed = parseRomFile(incomingSharedRom.fileName, bytes);
      onRomFileLoaded?.(parsed, parsed.effectiveBytes || bytes);
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Falha ao abrir ROM compartilhada.');
    }
  }, [incomingSharedRom]);

  useEffect(() => {
    if (!incomingSharedRomBytes) return;
    try {
      const parsed = parseRomFile(incomingSharedRomBytes.fileName, incomingSharedRomBytes.bytes);
      onRomFileLoaded?.(parsed, parsed.effectiveBytes || incomingSharedRomBytes.bytes);
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Falha ao abrir ROM recebida via P2P.');
    }
  }, [incomingSharedRomBytes]);

  const bootRetroCore = async (
    token: number,
    romInfo: ParsedRomInfo,
    effectiveName: string,
    effectiveBytes: Uint8Array,
    overrideCore?: RetroCoreName
  ) => {
    const canvas = retroCanvasRef.current;
    if (!canvas) return;

    const coreName = overrideCore || romInfo.coreName;
    try {
      const extracted = await getExtractedCore(coreName);
      if (launchTokenRef.current !== token) return;

      const romCopy = new Uint8Array(effectiveBytes);
      const biosEntries: Array<{ fileName: string; fileContent: Blob }> = [];
      if (arcadeBiosFiles && arcadeBiosFiles.length > 0) {
        for (const bios of arcadeBiosFiles) {
          biosEntries.push({
            fileName: bios.fileName,
            fileContent: new Blob([new Uint8Array(bios.bytes)]),
          });
        }
      } else if (neogeoBiosBytes) {
        biosEntries.push({
          fileName: 'neogeo.zip',
          fileContent: new Blob([new Uint8Array(neogeoBiosBytes)]),
        });
      }

      const instance = await Nostalgist.launch({
        element: canvas,
        core: {
          name: coreName,
          js: extracted.jsBlob,
          wasm: extracted.wasmBlob,
        },
        rom: {
          fileName: effectiveName,
          fileContent: new Blob([romCopy]),
        },
        bios: biosEntries.length > 0 ? biosEntries : undefined,
        size: 'auto',
        respondToGlobalEvents: false,
        retroarchConfig: {
          audio_mute_enable: muted,
          video_smooth: false,
          savestate_auto_load: false,
          suspend_screensaver_enable: false,
          input_player1_up: 'up',
          input_player1_down: 'down',
          input_player1_left: 'left',
          input_player1_right: 'right',
          input_player1_a: 'x',
          input_player1_b: 'z',
          input_player1_x: 's',
          input_player1_y: 'a',
          input_player1_l: 'q',
          input_player1_r: 'w',
          input_player1_l2: 'e',
          input_player1_r2: 'r',
          input_player1_start: 'enter',
          input_player1_select: 'rshift',
          input_player2_up: 'i',
          input_player2_down: 'k',
          input_player2_left: 'j',
          input_player2_right: 'l',
          input_player2_a: 'o',
          input_player2_b: 'u',
          input_player2_x: 'p',
          input_player2_y: 'y',
          input_player2_l: 'n',
          input_player2_r: 'm',
          input_player2_l2: 'b',
          input_player2_r2: 'v',
          input_player2_start: 'space',
          input_player2_select: 'tab',
        },
      });

      if (launchTokenRef.current !== token) {
        instance.exit({ removeCanvas: false });
        return;
      }

      nostalgistRef.current = instance;
      setEngineReady(true);
      setLoadingLabel(null);
      setLoadedFileLabel(romInfo.title);
      setRomError(null);
    } catch (err) {
      if (launchTokenRef.current !== token) return;
      if (!overrideCore && romInfo.fallbackCoreName && romInfo.fallbackCoreName !== coreName) {
        setLoadingLabel(`Tentando núcleo alternativo (${romInfo.fallbackCoreName})...`);
        setRetroCanvasKey((k) => k + 1);
        window.setTimeout(() => {
          void bootRetroCore(token, romInfo, effectiveName, effectiveBytes, romInfo.fallbackCoreName);
        }, 40);
        return;
      }

      setLoadingLabel(null);
      setEngineReady(false);
      const rawMsg = err instanceof Error ? err.message : 'Falha ao iniciar o emulador.';
      const hasNeogeoBios =
        Boolean(neogeoBiosBytes) ||
        Boolean(arcadeBiosFiles?.some((b) => b.fileName.toLowerCase().includes('neogeo')));
      if (romInfo.systemId === 'neogeo' && !hasNeogeoBios) {
        setRomError(
          `Erro ao abrir Neo Geo (${rawMsg}). Dica: adicione também sua BIOS "neogeo.zip" em Seus Jogos para rodar jogos MVS/AES.`
        );
      } else {
        setRomError(`Não foi possível iniciar "${romInfo.title}": ${rawMsg}`);
      }
    }
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      const bit = KEY_TO_BIT[e.code];
      if (bit) {
        e.preventDefault();
        activeMaskRef.current |= bit;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const bit = KEY_TO_BIT[e.code];
      if (bit) {
        activeMaskRef.current &= ~bit;
      }
    };
    const onGamepadConnected = () => setGamepadConnected(true);
    const onGamepadDisconnected = () => setGamepadConnected(false);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('gamepadconnected', onGamepadConnected);
    window.addEventListener('gamepaddisconnected', onGamepadDisconnected);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('gamepadconnected', onGamepadConnected);
      window.removeEventListener('gamepaddisconnected', onGamepadDisconnected);
    };
  }, []);

  const readGamepadMask = (): number => {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const pad = pads[0];
    if (!pad) return 0;
    let mask = 0;
    if (pad.axes[1] < -0.45 || pad.buttons[12]?.pressed) mask |= INPUT_BITS.UP;
    if (pad.axes[1] > 0.45 || pad.buttons[13]?.pressed) mask |= INPUT_BITS.DOWN;
    if (pad.axes[0] < -0.45 || pad.buttons[14]?.pressed) mask |= INPUT_BITS.LEFT;
    if (pad.axes[0] > 0.45 || pad.buttons[15]?.pressed) mask |= INPUT_BITS.RIGHT;
    if (pad.buttons[1]?.pressed) mask |= INPUT_BITS.A;
    if (pad.buttons[0]?.pressed) mask |= INPUT_BITS.B;
    if (pad.buttons[3]?.pressed) mask |= INPUT_BITS.X;
    if (pad.buttons[2]?.pressed) mask |= INPUT_BITS.Y;
    if (pad.buttons[4]?.pressed) mask |= INPUT_BITS.L1;
    if (pad.buttons[5]?.pressed) mask |= INPUT_BITS.R1;
    if (pad.buttons[6]?.pressed) mask |= INPUT_BITS.L2;
    if (pad.buttons[7]?.pressed) mask |= INPUT_BITS.R2;
    if (pad.buttons[8]?.pressed) mask |= INPUT_BITS.SELECT;
    if (pad.buttons[9]?.pressed) mask |= INPUT_BITS.START;
    return mask;
  };

  useEffect(() => {
    if (!engineReady) return;
    let rafId = 0;
    let lastTime = performance.now();
    let accumulator = 0;
    const STEP_MS = 1000 / 60;

    const tick = (now: number) => {
      const delta = Math.min(64, now - lastTime);
      lastTime = now;

      if (!paused && (nesRef.current || nostalgistRef.current)) {
        accumulator += delta;
        while (accumulator >= STEP_MS) {
          accumulator -= STEP_MS;
          frameCounterRef.current += 1;

          const localInput = activeMaskRef.current | touchMaskRef.current | readGamepadMask();
          if (isNetplayActive && (playerSlot === 'P1' || playerSlot === 'P2')) {
            onSendLocalInput?.(frameCounterRef.current, localInput);
          }

          inputBufferRef.current.push(localInput);
          while (inputBufferRef.current.length > Math.max(1, frameDelay + 1)) {
            inputBufferRef.current.shift();
          }
          const delayedLocal = inputBufferRef.current[0] ?? localInput;

          let p1Mask = 0;
          let p2Mask = 0;

          if (!isNetplayActive || playerSlot === 'SOLO') {
            p1Mask = localInput;
          } else if (playerSlot === 'P1') {
            p1Mask = delayedLocal;
            p2Mask = remoteInputRef.current.p2;
          } else if (playerSlot === 'P2') {
            p1Mask = remoteInputRef.current.p1;
            p2Mask = delayedLocal;
          } else {
            p1Mask = remoteInputRef.current.p1;
            p2Mask = remoteInputRef.current.p2;
          }

          if (nesRef.current) {
            applyJsnesMask(nesRef.current, 1, prevP1Ref.current, p1Mask);
            applyJsnesMask(nesRef.current, 2, prevP2Ref.current, p2Mask);
            prevP1Ref.current = p1Mask;
            prevP2Ref.current = p2Mask;
            nesRef.current.frame();
          } else if (nostalgistRef.current) {
            applyRetroArchMask(nostalgistRef.current, 1, prevP1Ref.current, p1Mask);
            applyRetroArchMask(nostalgistRef.current, 2, prevP2Ref.current, p2Mask);
            prevP1Ref.current = p1Mask;
            prevP2Ref.current = p2Mask;
          }
        }

        if (nesRef.current) {
          const canvas = nesCanvasRef.current;
          const ctx = canvas?.getContext('2d');
          if (canvas && ctx && nesImageDataRef.current) {
            if (canvas.width !== 256 || canvas.height !== 240) {
              canvas.width = 256;
              canvas.height = 240;
            }
            ctx.putImageData(nesImageDataRef.current, 0, 0);
          }
        }
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [engineReady, paused, isNetplayActive, playerSlot, frameDelay]);

  const bootJsnesFromBinary = (binaryStr: string, displayTitle: string) => {
    const canvas = nesCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx) {
      nesImageDataRef.current = ctx.createImageData(256, 240);
    }

    const nes = new NES({
      emulateSound: true,
      sampleRate: audioRef.current?.sampleRate || 44100,
      onFrame: (frameBuffer) => {
        const imgData = nesImageDataRef.current;
        if (!imgData) return;
        const data32 = new Uint32Array(imgData.data.buffer);
        for (let i = 0; i < 256 * 240; i++) {
          data32[i] = 0xff000000 | frameBuffer[i];
        }
      },
      onAudioSample: (left, right) => {
        audioRef.current?.pushNesSample(left, right);
      },
    });
    nes.loadROM(binaryStr);
    nesRef.current = nes;
    prevP1Ref.current = 0;
    prevP2Ref.current = 0;
    setEngineReady(true);
    setLoadedFileLabel(displayTitle);
    setRomError(null);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setRomError(null);

    if (onRomFilesSelected) {
      onRomFilesSelected(files);
      e.target.value = '';
      return;
    }

    const file = files[0];
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const parsedList = parseRomFiles(file.name, bytes);
      for (const parsed of parsedList) {
        onRomFileLoaded?.(parsed, parsed.effectiveBytes || bytes);
      }
    } catch (err) {
      setRomError(err instanceof Error ? err.message : 'Arquivo de ROM inválido.');
    }
    e.target.value = '';
  };

  const togglePause = () => {
    const next = !paused;
    setPaused(next);
    if (nostalgistRef.current) {
      if (next) nostalgistRef.current.pause();
      else nostalgistRef.current.resume();
    }
  };

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    audioRef.current?.setMuted(next);
    if (nostalgistRef.current) {
      nostalgistRef.current.sendCommand('MUTE');
    }
  };

  const handleReset = () => {
    if (nesRef.current) {
      nesRef.current.reset();
    } else if (nostalgistRef.current) {
      nostalgistRef.current.restart();
    }
    setPaused(false);
  };

  const handleSaveState = async () => {
    if (!nostalgistRef.current) return;
    const { state } = await nostalgistRef.current.saveState();
    savedStateBlobRef.current = state;
    setHasSavedState(true);
  };

  const handleLoadState = async () => {
    if (!nostalgistRef.current || !savedStateBlobRef.current) return;
    await nostalgistRef.current.loadState(savedStateBlobRef.current);
  };

  const handleFullscreen = async () => {
    if (!containerRef.current) return;
    if (document.fullscreenElement || isFullscreen) {
      if (document.fullscreenElement && document.exitFullscreen) {
        try {
          await document.exitFullscreen();
        } catch {
          setIsFullscreen(false);
        }
      } else {
        setIsFullscreen(false);
      }
      try {
        const orientation = screen.orientation as unknown as { unlock?: () => void };
        orientation?.unlock?.();
      } catch {
        // Orientation unlock is optional on older WebViews.
      }
      return;
    }

    // Android 6 WebView often has no Fullscreen API. Use a fixed-position
    // in-app fullscreen layout instead of silently leaving the game boxed.
    if (containerRef.current.requestFullscreen) {
      try {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } catch {
        setIsFullscreen(true);
      }
    } else {
      setIsFullscreen(true);
    }
    try {
      const orientation = screen.orientation as unknown as { lock?: (o: string) => Promise<void> };
      if (orientation?.lock) await orientation.lock('landscape');
    } catch {
      // Orientation lock is optional.
    }
  };

  const sysInfo = activeRom ? getSystemById(activeRom.systemId) : undefined;

  // Keep the RetroArch WebGL drawing buffer in sync with fullscreen/orientation
  // changes. Old Android WebViews can keep audio alive while the canvas buffer
  // remains at its pre-fullscreen size (or zero), producing a black game image.
  useEffect(() => {
    const resizeCore = () => {
      const area = gameAreaRef.current;
      const instance = nostalgistRef.current;
      if (!area || !instance || !engineReady || engineMode !== 'retro') return;
      const rect = area.getBoundingClientRect();
      const width = Math.max(1, Math.round(rect.width));
      const height = Math.max(1, Math.round(rect.height));
      try {
        instance.resize({ width, height });
      } catch {
        // Keep the running core alive if an older WebView rejects a resize.
      }
    };
    const first = window.setTimeout(resizeCore, 80);
    const second = window.setTimeout(resizeCore, 350);
    window.addEventListener('resize', resizeCore);
    window.addEventListener('orientationchange', resizeCore);
    document.addEventListener('fullscreenchange', resizeCore);
    return () => {
      window.clearTimeout(first);
      window.clearTimeout(second);
      window.removeEventListener('resize', resizeCore);
      window.removeEventListener('orientationchange', resizeCore);
      document.removeEventListener('fullscreenchange', resizeCore);
    };
  }, [isFullscreen, engineReady, engineMode]);

  return (
    <div
      ref={containerRef}
      className={`flex flex-col border border-white/10 bg-[#15181E] rounded-2xl overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-[9999] h-screen w-screen rounded-none border-none justify-between bg-black overflow-y-auto' : ''
      }`}
    >
      {/* Top ROM Info & Open ROM Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-white/10 bg-[#111318]">
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-white truncate">
            {loadedFileLabel || activeRom?.title || 'Nenhuma ROM selecionada'}
          </div>
          {activeRom && (
            <div className="text-[11px] text-[#9AA3B2] font-mono-tabular truncate">
              {sysInfo?.shortName || activeRom.systemId.toUpperCase()} · {activeRom.headerSummary} · CRC{' '}
              {activeRom.crc32}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={(e) => void handleFileChange(e)}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[44px] inline-flex items-center gap-1.5 px-3.5 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            Abrir ROM(s)
          </button>

          {isNetplayActive &&
            playerSlot === 'P1' &&
            engineReady &&
            activeRomBytes &&
            (onShareRomBytes || (lastShareBase64 && onShareNesRom)) && (
              <button
                type="button"
                onClick={() => {
                  if (onShareRomBytes && activeRomBytes) {
                    onShareRomBytes(activeRom?.fileName || 'game.rom', activeRomBytes);
                  } else if (onShareNesRom && lastShareBase64) {
                    onShareNesRom(activeRom?.fileName || 'game.rom', lastShareBase64);
                  }
                }}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1E232D] hover:bg-[#272D39] text-white border border-white/15 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                Enviar P2
              </button>
            )}
        </div>
      </div>

      {/* Emulator Game Screen Area */}
      <div
        ref={gameAreaRef}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer.files && e.dataTransfer.files.length > 0 && onRomFilesSelected) {
            onRomFilesSelected(e.dataTransfer.files);
          }
        }}
        className={`relative bg-[#07080A] flex items-center justify-center w-full overflow-hidden ${
          isFullscreen ? 'flex-1 min-h-0' : 'aspect-[4/3] max-h-[440px]'
        }`}
      >
        <canvas
          ref={nesCanvasRef}
          width={256}
          height={240}
          className={`pixelated-canvas w-full h-full object-contain ${
            engineMode === 'nes' && engineReady ? 'block' : 'hidden'
          }`}
        />

        {engineMode === 'retro' && (
          <canvas
            key={retroCanvasKey}
            ref={retroCanvasRef}
            className={`pixelated-canvas w-full h-full object-contain ${engineReady ? 'block' : 'hidden'}`}
          />
        )}

        {engineReady && scanlines && <div className="crt-scanlines absolute inset-0" />}

        {loadingLabel && (
          <div className="absolute inset-0 bg-[#07080A]/90 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <Loader2 className="w-7 h-7 text-[#EA580C] animate-spin" />
            <div className="text-sm font-semibold text-white">{loadingLabel}</div>
            <div className="text-xs text-[#9AA3B2]">
              Lendo cabeçalho da ROM e iniciando núcleo {sysInfo?.nativeCore || 'RetroArch'}...
            </div>
          </div>
        )}

        {!engineReady && !loadingLabel && (
          <div className="p-6 max-w-md text-center space-y-4">
            <h3 className="text-base font-semibold text-white">
              {activeRom ? activeRom.title : 'Escolha uma ou várias ROMs para jogar'}
            </h3>
            <p className="text-xs text-[#9AA3B2] leading-relaxed">
              Aceita todas as ROMs clássicas em geral:{' '}
              <span className="text-white">
                Arcade (.zip/.fba), SNES (.sfc/.smc/.fig), Mega Drive / 32X / SMS (.md/.bin/.gen/.32x/.sms),
                NES (.nes/.fds), GBA / GB / GBC, Neo Geo, CPS-1/2 e PC Engine
              </span>
              . Selecione 1 ou várias ROMs de uma vez.
            </p>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              Selecionar ROMs do Aparelho
            </button>
          </div>
        )}

        {engineReady && paused && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center pointer-events-none">
            <span className="text-sm font-semibold text-white bg-[#15181E] border border-white/15 px-4 py-2 rounded-xl">
              Pausado
            </span>
          </div>
        )}
      </div>

      {romError && (
        <div className="px-4 py-2.5 bg-[#2A1C12] border-t border-[#F59E0B]/30 text-xs text-[#FCD34D]">
          {romError}
        </div>
      )}

      {/* Emulator Action Strip */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 border-t border-white/10 bg-[#111318] text-xs text-[#9AA3B2]">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            disabled={!engineReady}
            onClick={togglePause}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
          >
            {paused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
            <span>{paused ? 'Continuar' : 'Pausar'}</span>
          </button>

          <button
            type="button"
            disabled={!engineReady}
            onClick={handleReset}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reiniciar</span>
          </button>

          <button
            type="button"
            disabled={!engineReady}
            onClick={toggleMute}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span>{muted ? 'Mudo' : 'Som'}</span>
          </button>

          {engineMode === 'retro' && engineReady && (
            <>
              <button
                type="button"
                onClick={() => void handleSaveState()}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] text-white transition-colors cursor-pointer"
              >
                <BookmarkPlus className="w-4 h-4 text-[#F59E0B]" />
                <span>Salvar</span>
              </button>
              <button
                type="button"
                disabled={!hasSavedState}
                onClick={() => void handleLoadState()}
                className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] disabled:opacity-40 text-white transition-colors cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4 text-[#4ADE80]" />
                <span>Carregar</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => setShowTouchPad((v) => !v)}
            className={`min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl transition-colors cursor-pointer ${
              showTouchPad
                ? 'bg-[#EA580C]/20 text-[#FB923C] border border-[#EA580C]/40'
                : 'bg-[#1C2028] text-[#9AA3B2]'
            }`}
          >
            <Gamepad className="w-4 h-4" />
            <span>Joystick</span>
          </button>

          <button
            type="button"
            onClick={() => setScanlines((s) => !s)}
            className={`min-h-[44px] px-3 rounded-xl transition-colors cursor-pointer ${
              scanlines ? 'bg-[#1C2028] text-white border border-white/15' : 'bg-[#1C2028] text-[#9AA3B2]'
            }`}
          >
            CRT
          </button>

          {activeRom?.systemId === 'arcade' && activeRom.coreName === 'fbneo' && (
            <label className="min-h-[44px] inline-flex items-center gap-1.5 px-2 text-xs text-white bg-[#1C2028] rounded-xl border border-white/10">
              <span>Arcade</span>
              <select
                aria-label="Núcleo Arcade"
                value={selectedArcadeCore}
                onChange={(event) => setSelectedArcadeCore(event.target.value as RetroCoreName)}
                className="max-w-[122px] bg-transparent text-white outline-none"
              >
                <option value="fbneo">FBNeo</option>
                <option value="mame2003_plus">MAME 2003+</option>
                <option value="mame2000">MAME 2000</option>
              </select>
            </label>
          )}

          <button
            type="button"
            onClick={() => void handleFullscreen()}
            className="min-h-[44px] inline-flex items-center gap-1 px-3 rounded-xl bg-[#1C2028] hover:bg-[#252A34] text-white transition-colors cursor-pointer"
          >
            <Maximize2 className="w-4 h-4" />
            <span>{isFullscreen ? 'Sair' : 'Tela Cheia'}</span>
          </button>
        </div>

        <span className="hidden lg:inline font-mono-tabular text-[11px] text-[#8E98A8]">
          {gamepadConnected ? 'Controle Bluetooth Ativo' : 'Joystick Touch · Bluetooth · Teclado'}
        </span>
      </div>

      {/* Adaptive Multi-Touch Joystick + A/B/X/Y + L1/L2/R1/R2 + Select/Start */}
      {showTouchPad && (
        <AndroidTouchPad
          systemId={activeRom?.systemId}
          gameTitle={activeRom?.title}
          compactLandscape={isFullscreen}
          onMaskChange={(mask) => {
            touchMaskRef.current = mask;
          }}
        />
      )}
    </div>
  );
}
