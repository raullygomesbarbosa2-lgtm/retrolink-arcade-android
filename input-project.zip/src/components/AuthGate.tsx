import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { Download, KeyRound, Mail, UserPlus } from 'lucide-react';
import { auth } from '../firebase';
import { loadOrCreateUserAccount, sanitizeGamertag } from '../services/firestoreService';
import { RegionId, UserPublicProfile } from '../types/retrolink';

interface AuthGateProps {
  pendingInviteCode?: string;
  canInstallApp?: boolean;
  onInstallApp?: () => void;
  onPrepareRegistration: (data: { gamertag: string; region: RegionId }) => void;
  onAuthenticated: (profile: UserPublicProfile) => void;
}

export function AuthGate({
  pendingInviteCode,
  canInstallApp,
  onInstallApp,
  onPrepareRegistration,
  onAuthenticated,
}: AuthGateProps) {
  const [mode, setMode] = useState<'register' | 'login'>('register');
  const [gamertag, setGamertag] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [region, setRegion] = useState<RegionId>('BR-SP');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const mapFirebaseAuthError = (err: unknown): string => {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('auth/operation-not-allowed')) {
      return 'O provedor E-mail/Senha precisa estar ativado no Firebase Console (Authentication > Sign-in method > E-mail/Senha > Ativar).';
    }
    if (msg.includes('auth/email-already-in-use')) {
      return 'Este e-mail já possui conta cadastrada. Troque para a aba Já Tenho Conta.';
    }
    if (msg.includes('auth/invalid-email')) {
      return 'Digite um endereço de e-mail válido.';
    }
    if (msg.includes('auth/weak-password')) {
      return 'A senha deve ter pelo menos 6 caracteres.';
    }
    if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password') || msg.includes('auth/user-not-found')) {
      return 'E-mail ou senha incorretos.';
    }
    return msg;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('Informe um e-mail válido.');
      return;
    }

    if (mode === 'register') {
      const cleanTag = sanitizeGamertag(gamertag, '');
      if (cleanTag.length < 2) {
        setError('Informe seu apelido/gamertag com pelo menos 2 caracteres.');
        return;
      }
      if (password.length < 6) {
        setError('Crie uma senha com pelo menos 6 caracteres.');
        return;
      }
      if (password !== confirmPassword) {
        setError('As senhas digitadas não conferem.');
        return;
      }

      setBusy(true);
      try {
        onPrepareRegistration({ gamertag: cleanTag, region });
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        await updateProfile(cred.user, { displayName: cleanTag });
        const profile = await loadOrCreateUserAccount(cred.user, {
          gamertag: cleanTag,
          region,
          favoriteSystem: 'nes',
        });
        onAuthenticated(profile);
      } catch (err) {
        setError(mapFirebaseAuthError(err));
      } finally {
        setBusy(false);
      }
    } else {
      if (!password) {
        setError('Digite sua senha para entrar.');
        return;
      }
      setBusy(true);
      try {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
        const profile = await loadOrCreateUserAccount(cred.user);
        onAuthenticated(profile);
      } catch (err) {
        setError(mapFirebaseAuthError(err));
      } finally {
        setBusy(false);
      }
    }
  };

  const handleResetPassword = async () => {
    setError(null);
    setInfo(null);
    if (!email.trim() || !email.includes('@')) {
      setError('Digite seu e-mail acima primeiro para receber a redefinição de senha.');
      return;
    }
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setInfo('E-mail de redefinição enviado. Verifique sua caixa de entrada.');
    } catch (err) {
      setError(mapFirebaseAuthError(err));
    }
  };

  return (
    <div className="min-h-[calc(100vh-140px)] flex items-center justify-center px-4 sm:px-6 py-8 sm:py-12">
      <div className="w-full max-w-4xl space-y-4">
        {pendingInviteCode && (
          <div className="px-4 py-3.5 rounded-xl border border-[#EA580C]/45 bg-[#1D140E] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-[#FB923C]">
                Convite para Sala Multiplayer Detectado: <span className="font-mono-tabular text-white">{pendingInviteCode}</span>
              </div>
              <p className="text-xs text-[#E5E7EB]">
                Crie sua conta por e-mail abaixo (ou entre se já tiver) para entrar direto na sala do seu amigo no outro celular.
              </p>
            </div>
            {canInstallApp && onInstallApp && (
              <button
                type="button"
                onClick={onInstallApp}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Instalar App
              </button>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 border border-white/10 bg-[#15181E] rounded-2xl overflow-hidden">
          <div className="lg:col-span-5 p-6 sm:p-8 bg-[#111318] border-b lg:border-b-0 lg:border-r border-white/10 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <p className="text-xs font-medium text-[#F59E0B]">Acesso Obrigatório por E-mail</p>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white leading-tight text-balance">
                Crie sua conta por e-mail para jogar Solo ou Online
              </h1>
              <p className="text-sm text-[#A1AAB8] leading-relaxed">
                Cada jogador cria seu próprio e-mail e senha. Depois de entrar, você pode jogar solo, criar sala com link de convite ou entrar direto no multiplayer de outro celular.
              </p>
            </div>

            <div className="space-y-2.5 text-xs text-[#9AA3B2] pt-4 border-t border-white/10">
              <div>1. Crie sua conta manual digitando seu e-mail e senha</div>
              <div>2. Adicione suas ROMs clássicas (SNES, Arcade, Mega Drive, NES, GBA)</div>
              <div>3. Compartilhe o link do app + código com seu amigo para jogar à distância</div>
            </div>
          </div>

        <div className="lg:col-span-7 p-8 space-y-6">
          <div className="grid grid-cols-2 gap-1 p-1 bg-[#0D0F12] border border-white/10 rounded-md">
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`py-2 px-3 text-xs font-semibold rounded transition-colors cursor-pointer ${
                mode === 'register' ? 'bg-[#EA580C] text-white' : 'text-[#9AA3B2] hover:text-white'
              }`}
            >
              Criar E-mail do Zero
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`py-2 px-3 text-xs font-semibold rounded transition-colors cursor-pointer ${
                mode === 'login' ? 'bg-[#EA580C] text-white' : 'text-[#9AA3B2] hover:text-white'
              }`}
            >
              Já Tenho Conta
            </button>
          </div>

          <form onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
            {mode === 'register' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="auth-tag" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                    Apelido / Gamertag
                  </label>
                  <input
                    id="auth-tag"
                    type="text"
                    value={gamertag}
                    onChange={(e) => setGamertag(e.target.value)}
                    maxLength={24}
                    required
                    placeholder="Ex: PlayerOneBR"
                    className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
                  />
                </div>
                <div>
                  <label htmlFor="auth-region" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                    Região
                  </label>
                  <select
                    id="auth-region"
                    value={region}
                    onChange={(e) => setRegion(e.target.value as RegionId)}
                    className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
                  >
                    <option value="BR-SP">Brasil (São Paulo)</option>
                    <option value="SA-EAST">América do Sul</option>
                    <option value="NA-EAST">América do Norte</option>
                    <option value="EU-WEST">Europa</option>
                    <option value="JP-TOKYO">Japão</option>
                  </select>
                </div>
              </div>
            )}

            <div>
              <label htmlFor="auth-email" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                E-mail
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#9AA3B2] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="seuemail@exemplo.com"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
                />
              </div>
            </div>

            <div>
              <label htmlFor="auth-pass" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Senha
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-[#9AA3B2] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-pass"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label htmlFor="auth-pass-confirm" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                  Confirmar Senha
                </label>
                <input
                  id="auth-pass-confirm"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={6}
                  placeholder="Repita sua senha"
                  className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
                />
              </div>
            )}

            {error && (
              <div className="p-3 bg-[#2A1618] border border-[#EF4444]/40 rounded-md text-xs text-[#FCA5A5]">
                {error}
              </div>
            )}

            {info && (
              <div className="p-3 bg-[#14261B] border border-[#22C55E]/35 rounded-md text-xs text-[#86EFAC]">
                {info}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold bg-[#EA580C] hover:bg-[#DC4E07] disabled:opacity-50 text-white rounded-md transition-colors cursor-pointer"
            >
              {mode === 'register' && <UserPlus className="w-4 h-4" />}
              {busy
                ? 'Processando...'
                : mode === 'register'
                ? 'Criar Conta por E-mail e Entrar'
                : 'Entrar com E-mail e Senha'}
            </button>

            {mode === 'login' && (
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => void handleResetPassword()}
                  className="text-xs text-[#9AA3B2] hover:text-white underline underline-offset-4 cursor-pointer"
                >
                  Esqueci minha senha
                </button>
              </div>
            )}
          </form>
        </div>
        </div>
      </div>
    </div>
  );
}
