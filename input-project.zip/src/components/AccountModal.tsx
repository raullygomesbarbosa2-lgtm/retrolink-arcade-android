import React, { useState } from 'react';
import { LogOut, X } from 'lucide-react';
import { CLASSIC_SYSTEMS } from '../data/catalog';
import { RegionId, UserPublicProfile } from '../types/retrolink';

interface AccountModalProps {
  isOpen: boolean;
  email: string;
  profile: UserPublicProfile | null;
  onSave: (data: { gamertag: string; region: RegionId; favoriteSystem: string }) => Promise<void>;
  onSignOut: () => Promise<void>;
  onClose: () => void;
}

const REGIONS: { id: RegionId; label: string }[] = [
  { id: 'BR-SP', label: 'Brasil (São Paulo)' },
  { id: 'SA-EAST', label: 'América do Sul (Leste)' },
  { id: 'NA-EAST', label: 'América do Norte (Leste)' },
  { id: 'EU-WEST', label: 'Europa (Oeste)' },
  { id: 'JP-TOKYO', label: 'Japão (Tóquio)' },
];

export function AccountModal({
  isOpen,
  email,
  profile,
  onSave,
  onSignOut,
  onClose,
}: AccountModalProps) {
  const [gamertag, setGamertag] = useState(profile?.gamertag || email.split('@')[0] || 'RetroPlayer');
  const [region, setRegion] = useState<RegionId>(profile?.region || 'BR-SP');
  const [favoriteSystem, setFavoriteSystem] = useState(profile?.favoriteSystem || 'neogeo');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const trimmed = gamertag.trim();
    if (trimmed.length < 2 || trimmed.length > 24) {
      setError('A gamertag deve ter entre 2 e 24 caracteres.');
      return;
    }
    setSaving(true);
    try {
      await onSave({ gamertag: trimmed, region, favoriteSystem });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao salvar perfil.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#15181E] border border-white/10 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">Conta do Jogador</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="p-1.5 text-[#9AA3B2] hover:text-white rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#9AA3B2] mb-1.5">
              E-mail da Conta
            </label>
            <input
              type="text"
              value={email}
              disabled
              className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/10 rounded-md text-[#9AA3B2] font-mono-tabular"
            />
          </div>

          <div>
            <label htmlFor="gamertag-input" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
              Gamertag no Lobby
            </label>
            <input
              id="gamertag-input"
              type="text"
              value={gamertag}
              onChange={(e) => setGamertag(e.target.value)}
              maxLength={24}
              required
              placeholder="Ex: Ryujin_BR"
              className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-md text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="region-select" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Região Netplay
              </label>
              <select
                id="region-select"
                value={region}
                onChange={(e) => setRegion(e.target.value as RegionId)}
                className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 rounded-md text-white focus:border-[#EA580C] focus:outline-none"
              >
                {REGIONS.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="fav-sys-select" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Sistema Favorito
              </label>
              <select
                id="fav-sys-select"
                value={favoriteSystem}
                onChange={(e) => setFavoriteSystem(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-[#0D0F12] border border-white/15 rounded-md text-white focus:border-[#EA580C] focus:outline-none"
              >
                {CLASSIC_SYSTEMS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.shortName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {error && <p className="text-xs text-[#FCA5A5]">{error}</p>}

          <div className="flex items-center justify-between pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={() => void onSignOut()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#FCA5A5] hover:bg-white/5 rounded-md transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sair da Conta
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-[#9AA3B2] hover:text-white rounded-md cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] disabled:opacity-50 text-white rounded-md transition-colors cursor-pointer"
              >
                {saving ? 'Salvando...' : 'Salvar Conta'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
