import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Link2,
  Lock,
  LogOut,
  Play,
  RefreshCw,
  Send,
  Share2,
  ShieldCheck,
  Users,
  Wifi,
} from 'lucide-react';
import { getSystemById } from '../data/catalog';
import {
  RoomChatDoc,
  sendRoomChatMessage,
  subscribeToRoomChatMessages,
  updateGuestCharacterSelection,
  updateServerSettings,
} from '../services/firestoreService';
import { GgpoCoordinator } from '../services/ggpoNetplay';
import { RtcNetplaySession, RtcStatus } from '../services/rtcNetplay';
import {
  GameServer,
  LiveRoomState,
  MatchPhase,
  ParsedRomInfo,
  UserLocalRom,
  UserPublicProfile,
} from '../types/retrolink';
import { uint8ToBase64 } from '../utils/crc32';
import { getOrCreateDeviceId } from '../utils/deviceIdentity';
import { buildAppShareUrl, shareAccessWithFriend } from '../utils/shareLink';
import {
  BiosArchiveFile,
  EmulatorViewport,
  IncomingStateSync,
} from './EmulatorViewport';

interface MultiplayerRoomPanelProps {
  server: GameServer;
  profile: UserPublicProfile;
  activeRom: ParsedRomInfo | null;
  activeRomBytes: Uint8Array | null;
  neogeoBiosBytes?: Uint8Array | null;
  arcadeBiosFiles?: BiosArchiveFile[];
  userLocalRoms?: UserLocalRom[];
  onHostSelectRom?: (rom: UserLocalRom) => Promise<void>;
  onRomFileLoaded: (info: ParsedRomInfo, bytes: Uint8Array) => void;
  onRomFilesSelected?: (files: FileList | File[]) => void;
  onLeaveOrClose: () => Promise<void>;
  onUpdateFrameDelay: (delay: number) => Promise<void>;
}

const CHARACTER_PRESETS = [
  'Lutador 1',
  'Lutador 2',
  'Lutador 3',
  'Lutador 4',
  'Rival Aleatório',
];

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

export function MultiplayerRoomPanel({
  server,
  profile,
  activeRom,
  activeRomBytes,
  neogeoBiosBytes,
  arcadeBiosFiles,
  userLocalRoms = [],
  onHostSelectRom,
  onRomFileLoaded,
  onRomFilesSelected,
  onLeaveOrClose,
  onUpdateFrameDelay,
}: MultiplayerRoomPanelProps) {
  const isHost = server.hostUid === profile.uid;
  const mySlot: 'P1' | 'P2' = isHost ? 'P1' : 'P2';
  const myDeviceId = useRef<string>(getOrCreateDeviceId()).current;

  const wsRef = useRef<WebSocket | null>(null);
  const rtcRef = useRef<RtcNetplaySession | null>(null);
  const remoteInputRef = useRef<{ p1: number; p2: number }>({ p1: 0, p2: 0 });
  const ggpoRef = useRef<GgpoCoordinator | null>(
    new GgpoCoordinator(mySlot, server.frameDelay)
  );
  const captureStateRef = useRef<
    (() => Promise<{ frame: number; engine: 'nes' | 'retro'; bytes: Uint8Array } | null>) | null
  >(null);

  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const autoSentRomForGuestRef = useRef<string | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [rtcStatus, setRtcStatus] = useState<RtcStatus>('waiting_peer');
  const [roomState, setRoomState] = useState<LiveRoomState | null>(null);
  const [firestoreChat, setFirestoreChat] = useState<RoomChatDoc[]>([]);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [myReady, setMyReady] = useState(false);
  const [peerReady, setPeerReady] = useState(false);

  const [realtimeMatchPhase, setRealtimeMatchPhase] = useState<MatchPhase | null>(null);
  const [livePeerChar, setLivePeerChar] = useState<string>('');
  const [myCharInput, setMyCharInput] = useState<string>(
    isHost ? server.hostCharacter || 'P1 Padrão' : server.guestCharacter || 'P2 Padrão'
  );
  const [charSaving, setCharSaving] = useState(false);
  const [stateSyncStatus, setStateSyncStatus] = useState<string | null>(null);
  const [ggpoStats, setGgpoStats] = useState({ rollbackCount: 0, frameAdvantage: 0 });
  const [incomingStateSync, setIncomingStateSync] = useState<IncomingStateSync | null>(null);

  const [chatText, setChatText] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  const [incomingSharedRom, setIncomingSharedRom] = useState<{
    fileName: string;
    base64: string;
  } | null>(null);
  const [incomingSharedRomBytes, setIncomingSharedRomBytes] = useState<{
    fileName: string;
    bytes: Uint8Array;
  } | null>(null);
  const [romTransfer, setRomTransfer] = useState<{
    direction: 'send' | 'receive';
    percent: number;
    fileName: string;
  } | null>(null);

  const peerUid = isHost ? server.guestUid : server.hostUid;
  const hasGuest = Boolean(server.guestUid && server.guestUid !== server.hostUid);
  const effectiveMatchPhase: MatchPhase = realtimeMatchPhase || server.matchPhase || 'menu';

  useEffect(() => {
    ggpoRef.current?.setSlotAndDelay(mySlot, roomState?.frameDelay ?? server.frameDelay);
  }, [mySlot, roomState?.frameDelay, server.frameDelay]);

  useEffect(() => {
    setRealtimeMatchPhase(server.matchPhase || 'menu');
  }, [server.matchPhase]);

  useEffect(() => {
    const remoteChar = isHost ? server.guestCharacter : server.hostCharacter;
    if (remoteChar) {
      setLivePeerChar(remoteChar);
    }
  }, [isHost, server.guestCharacter, server.hostCharacter]);

  // 1. Cross-device WebRTC P2P connection signaled via Firestore
  useEffect(() => {
    if (!hasGuest || !peerUid) {
      setRtcStatus('waiting_peer');
      setPeerReady(false);
      rtcRef.current?.dispose();
      rtcRef.current = null;
      return;
    }

    const session = new RtcNetplaySession({
      serverId: server.serverId,
      myUid: profile.uid,
      peerUid,
      hostUid: server.hostUid,
      guestUid: server.guestUid,
      isHost,
      onStatusChange: (status) => {
        setRtcStatus(status);
      },
      onRemoteInput: (frame, mask, hist) => {
        // Strict slot isolation: Host ONLY writes P2 remote input, Guest ONLY writes P1 remote input.
        ggpoRef.current?.ingestRemotePacket(frame, mask, hist);
        if (isHost) {
          remoteInputRef.current.p2 = mask;
        } else {
          remoteInputRef.current.p1 = mask;
        }
      },
      onPingMeasured: (rtt) => setPingMs(rtt),
      onPeerReady: (ready) => setPeerReady(ready),
      onPeerCharacter: (slot, character) => {
        if ((isHost && slot === 'P2') || (!isHost && slot === 'P1')) {
          setLivePeerChar(character);
        }
      },
      onMatchControl: (action, frame) => {
        if (isHost) return;
        if (action === 'start' || action === 'resume') {
          setRealtimeMatchPhase('playing');
          if (action === 'start') {
            ggpoRef.current?.reset(frame);
          }
        } else if (action === 'pause') {
          setRealtimeMatchPhase('paused');
        } else if (action === 'menu') {
          setRealtimeMatchPhase('menu');
        } else if (action === 'reset') {
          ggpoRef.current?.reset(0);
          remoteInputRef.current = { p1: 0, p2: 0 };
          setRealtimeMatchPhase('playing');
        }
      },
      onStateReceived: (payload) => {
        if (!isHost) {
          setIncomingStateSync({ ...payload, nonce: Date.now() });
          setStateSyncStatus(`Estado sincronizado no frame ${payload.frame}`);
          window.setTimeout(() => setStateSyncStatus(null), 2500);
        }
      },
      onRomTransferProgress: (info) => {
        setRomTransfer(info);
        if (info.percent >= 100) {
          window.setTimeout(() => setRomTransfer(null), 1800);
        }
      },
      onRomReceived: (fileName, bytes) => {
        setIncomingSharedRomBytes({ fileName, bytes });
        setRomTransfer(null);
      },
    });

    rtcRef.current = session;
    return () => {
      session.dispose();
      if (rtcRef.current === session) {
        rtcRef.current = null;
      }
    };
  }, [server.serverId, server.hostUid, server.guestUid, profile.uid, isHost, hasGuest, peerUid]);

  // 2. Persistent cross-device chat synced via Firestore
  useEffect(() => {
    const unsub = subscribeToRoomChatMessages(server.serverId, isHost, profile.uid, (msgs) => {
      setFirestoreChat(msgs);
    });
    return () => unsub();
  }, [server.serverId, isHost, profile.uid]);

  // 3. Auto-send loaded ROM from P1 to P2 once WebRTC P2P DataChannel opens
  useEffect(() => {
    if (
      isHost &&
      rtcStatus === 'connected' &&
      hasGuest &&
      activeRomBytes &&
      activeRom &&
      autoSentRomForGuestRef.current !== `${server.guestUid}_${activeRom.romId}`
    ) {
      autoSentRomForGuestRef.current = `${server.guestUid}_${activeRom.romId}`;
      void rtcRef.current?.sendRomBytes(activeRom.fileName, activeRomBytes);
    }
  }, [isHost, rtcStatus, hasGuest, server.guestUid, activeRom?.romId, activeRomBytes]);

  // 4. Same-origin WebSocket relay (strictly role-validated P1/P2 secondary transport)
  useEffect(() => {
    let closedByUser = false;
    let reconnectTimer: number | null = null;
    let pingInterval: number | null = null;

    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        ws.send(
          JSON.stringify({
            type: 'room:join',
            serverId: server.serverId,
            uid: profile.uid,
            deviceId: myDeviceId,
            gamertag: profile.gamertag,
            role: isHost ? 'host' : 'guest',
            character: myCharInput,
            romId: server.romId,
            romTitle: server.romTitle,
            systemId: server.systemId,
            frameDelay: server.frameDelay,
          })
        );

        pingInterval = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(
              JSON.stringify({
                type: 'netplay:ping',
                ts: performance.now(),
                lastRtt: pingMs ?? 12,
              })
            );
          }
        }, 2500);
      };

      ws.onmessage = (event) => {
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(event.data);
        } catch {
          return;
        }

        if (msg.type === 'netplay:pong' && typeof msg.ts === 'number') {
          if (rtcStatus !== 'connected') {
            const rtt = Math.max(1, Math.round(performance.now() - msg.ts));
            setPingMs(rtt);
          }
          return;
        }

        if (msg.type === 'room:state' && msg.room) {
          const live = msg.room as LiveRoomState;
          setRoomState(live);
          const peerSlot = isHost ? 'P2' : 'P1';
          const peerParticipant = live.participants.find((p) => p.slot === peerSlot);
          if (peerParticipant?.character) {
            setLivePeerChar(peerParticipant.character);
          }
          return;
        }

        if (msg.type === 'netplay:remote_input') {
          // Enforce strict slot ownership: never accept packets purporting to be our own slot or wrong peer UID
          const expectedPeerSlot = isHost ? 'P2' : 'P1';
          if (msg.slot !== expectedPeerSlot || msg.senderUid === profile.uid) {
            return;
          }
          const frame = typeof msg.frame === 'number' ? msg.frame : 0;
          const mask = typeof msg.mask === 'number' ? msg.mask : 0;
          const hist = Array.isArray(msg.hist)
            ? (msg.hist as [number, number][])
            : undefined;
          ggpoRef.current?.ingestRemotePacket(frame, mask, hist);
          if (isHost) remoteInputRef.current.p2 = mask;
          else remoteInputRef.current.p1 = mask;
          return;
        }

        if (!isHost && msg.type === 'netplay:state_snapshot' && typeof msg.stateJson === 'string') {
          const frame = typeof msg.frame === 'number' ? msg.frame : 0;
          const engine = msg.engine === 'nes' ? 'nes' : 'retro';
          try {
            const bytes = base64ToBytes(msg.stateJson);
            setIncomingStateSync({ frame, engine, bytes, nonce: Date.now() });
          } catch {
            // ignore corrupted base64 snapshot
          }
          return;
        }

        if (!isHost && msg.type === 'netplay:start') {
          setRealtimeMatchPhase('playing');
          return;
        }
        if (!isHost && msg.type === 'netplay:resume') {
          setRealtimeMatchPhase('playing');
          return;
        }
        if (!isHost && msg.type === 'netplay:pause') {
          setRealtimeMatchPhase('paused');
          return;
        }
        if (!isHost && msg.type === 'netplay:menu') {
          setRealtimeMatchPhase('menu');
          return;
        }
        if (!isHost && msg.type === 'netplay:reset') {
          ggpoRef.current?.reset(0);
          remoteInputRef.current = { p1: 0, p2: 0 };
          setRealtimeMatchPhase('playing');
          return;
        }

        if (msg.type === 'rom:shared' && typeof msg.base64 === 'string' && !isHost) {
          setIncomingSharedRom({
            fileName: typeof msg.fileName === 'string' ? msg.fileName : 'shared.rom',
            base64: msg.base64,
          });
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (pingInterval) window.clearInterval(pingInterval);
        if (!closedByUser) {
          reconnectTimer = window.setTimeout(connect, 2200);
        }
      };
    };

    connect();

    return () => {
      closedByUser = true;
      if (pingInterval) window.clearInterval(pingInterval);
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [server.serverId, profile.uid, profile.gamertag, isHost, myDeviceId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [firestoreChat.length]);

  const sendLocalInput = (frame: number, mask: number, hist?: [number, number][]) => {
    const sentP2P = rtcRef.current?.sendInput(frame, mask, hist);
    if (!sentP2P) {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'netplay:input', frame, mask, hist }));
      }
    }
  };

  const pushStateToPeer = async (): Promise<number> => {
    const fallbackFrame = ggpoRef.current?.currentFrame || 0;
    if (!isHost || !captureStateRef.current) return fallbackFrame;
    try {
      const snap = await captureStateRef.current();
      if (!snap) {
        setStateSyncStatus('Sincronização por comandos ativa (snapshot opcional indisponível)');
        window.setTimeout(() => setStateSyncStatus(null), 2500);
        return fallbackFrame;
      }

      let sent = false;
      if (rtcRef.current?.isP2PReady()) {
        sent = await rtcRef.current.sendStateBytes(snap.frame, snap.engine, snap.bytes);
      }
      if (!sent && snap.bytes.length <= 3_000_000) {
        const ws = wsRef.current;
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(
            JSON.stringify({
              type: 'netplay:sync_state',
              frame: snap.frame,
              engine: snap.engine,
              stateJson: uint8ToBase64(snap.bytes),
            })
          );
          sent = true;
        }
      }
      if (sent) {
        setStateSyncStatus(`Snapshot frame ${snap.frame} enviado para P2`);
        window.setTimeout(() => setStateSyncStatus(null), 2500);
      }
      return snap.frame;
    } catch {
      setStateSyncStatus('Partida sincronizada via inputs em tempo real');
      window.setTimeout(() => setStateSyncStatus(null), 2500);
      return fallbackFrame;
    }
  };

  const setHostMatchPhase = async (nextPhase: MatchPhase) => {
    if (!isHost) return;
    setRealtimeMatchPhase(nextPhase);

    const frame = ggpoRef.current?.currentFrame || 0;
    const action =
      nextPhase === 'playing' ? 'start' : nextPhase === 'paused' ? 'pause' : 'menu';
    const wsType =
      nextPhase === 'playing'
        ? 'netplay:start'
        : nextPhase === 'paused'
        ? 'netplay:pause'
        : 'netplay:menu';

    await updateServerSettings(server.serverId, { matchPhase: nextPhase });
    void rtcRef.current?.sendMatchControl(action, frame);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: wsType, frame }));
    }

    if (nextPhase === 'playing' && hasGuest) {
      window.setTimeout(() => {
        void pushStateToPeer();
      }, 120);
    }
  };

  const handleHostResetSignal = async () => {
    if (!isHost) return;
    remoteInputRef.current = { p1: 0, p2: 0 };
    void rtcRef.current?.sendMatchControl('reset', 0);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'netplay:reset', frame: 0 }));
    }
    await updateServerSettings(server.serverId, { matchPhase: 'playing' });
  };

  const handleSaveMyCharacter = async (rawName: string) => {
    const clean = rawName.trim().slice(0, 40) || (isHost ? 'P1 Padrão' : 'P2 Padrão');
    setMyCharInput(clean);
    setCharSaving(true);
    try {
      if (isHost) {
        await updateServerSettings(server.serverId, { hostCharacter: clean });
      } else {
        await updateGuestCharacterSelection(server.serverId, clean);
      }
      void rtcRef.current?.sendCharacterChoice(mySlot, clean);
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'room:character', character: clean }));
      }
    } finally {
      setCharSaving(false);
    }
  };

  const shareRomBytes = async (fileName: string, bytes: Uint8Array) => {
    if (rtcRef.current?.isP2PReady()) {
      await rtcRef.current.sendRomBytes(fileName, bytes);
      return;
    }
    if (bytes.length <= 8_000_000) {
      const bin = Array.from(bytes, (b) => String.fromCharCode(b)).join('');
      const base64 = btoa(bin);
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'rom:share', fileName, base64 }));
      }
    }
  };

  const shareNesRom = (fileName: string, base64: string) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'rom:share', fileName, base64 }));
    }
  };

  const toggleReady = () => {
    const next = !myReady;
    setMyReady(next);
    void rtcRef.current?.sendReady(next);
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'room:ready', ready: next }));
    }
  };

  const sendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = chatText.trim();
    if (!text) return;
    setChatText('');
    await sendRoomChatMessage({
      serverId: server.serverId,
      senderUid: profile.uid,
      senderGamertag: profile.gamertag,
      hostUid: server.hostUid,
      guestUid: server.guestUid || '',
      text,
    });
  };

  const inviteUrl = buildAppShareUrl(server.inviteCode);

  const copyCode = async () => {
    await navigator.clipboard.writeText(server.inviteCode);
    setCopiedCode(true);
    window.setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    window.setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleNativeShare = async () => {
    try {
      const result = await shareAccessWithFriend({
        title: `RetroLink · ${server.romTitle}`,
        text: `Entre comigo no emulador RetroLink!\n1) Abra o link no seu celular (dá para instalar como App)\n2) Crie sua conta por e-mail\n3) Código da sala: ${server.inviteCode}`,
        url: inviteUrl,
      });
      setShareFeedback(
        result === 'shared'
          ? 'Convite e link do app enviados!'
          : 'Link do app + código copiados! Cole no WhatsApp do seu amigo.'
      );
      window.setTimeout(() => setShareFeedback(null), 3500);
    } catch {
      // user canceled native share sheet
    }
  };

  const wsP1 = roomState?.participants.find((p) => p.slot === 'P1');
  const wsP2 = roomState?.participants.find((p) => p.slot === 'P2');
  const p1Ready = isHost ? myReady : peerReady || Boolean(wsP1?.ready);
  const p2Ready = isHost ? peerReady || Boolean(wsP2?.ready) : myReady;
  const sysInfo = getSystemById(server.systemId);
  const peerConnected =
    hasGuest && (rtcStatus === 'connected' || (wsConnected && Boolean(wsP1 && wsP2)));

  const p1Character = isHost
    ? myCharInput
    : livePeerChar || server.hostCharacter || 'P1 Padrão';
  const p2Character = !isHost
    ? myCharInput
    : hasGuest
    ? livePeerChar || server.guestCharacter || 'P2 Padrão'
    : 'Aguardando P2';

  const p1DeviceLabel = isHost
    ? myDeviceId
    : server.hostDeviceId || wsP1?.deviceId || 'Celular P1';
  const p2DeviceLabel = !isHost
    ? myDeviceId
    : server.guestDeviceId || wsP2?.deviceId || (hasGuest ? 'Celular P2' : '');

  const multiplayerSwitchableRoms = userLocalRoms.filter((r) => {
    const sys = getSystemById(r.systemId);
    const lower = r.fileName.toLowerCase();
    const isBios =
      lower.includes('neogeo.zip') ||
      lower.includes('scph') ||
      lower === 'qsound.zip' ||
      lower === 'pgm.zip';
    return !isBios && Boolean(sys?.supportsOnlineMultiplayer);
  });

  const fallbackInfo: ParsedRomInfo | null =
    activeRom ||
    (activeRomBytes
      ? {
          romId: server.romId,
          title: server.romTitle,
          fileName: server.romTitle,
          systemId: server.systemId,
          coreName: sysInfo?.libretroCore || 'snes9x',
          crc32: '00000000',
          sizeBytes: activeRomBytes.length,
          headerSummary: sysInfo?.nativeCore || 'RetroArch WASM',
          playableInBrowser: true,
        }
      : null);

  const connectionLabel =
    rtcStatus === 'connected'
      ? `P2P Direto Conectado (${pingMs ?? 14} ms)`
      : hasGuest
      ? wsConnected && wsP1 && wsP2
        ? `Relay Conectado (${pingMs ?? 18} ms)`
        : 'Conectando P2P entre celulares...'
      : 'Aguardando 2º celular';

  const phaseLabel =
    effectiveMatchPhase === 'playing'
      ? 'Partida Liberada (P1+P2)'
      : effectiveMatchPhase === 'paused'
      ? 'Pausado pelo Host'
      : 'Menu Principal (Somente Host P1)';

  return (
    <section className="space-y-5">
      <div className="border border-white/10 bg-[#15181E] rounded-2xl p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#9AA3B2]">
              <span>{sysInfo?.name || server.systemId}</span>
              <span aria-hidden="true">·</span>
              <span className="text-white font-medium">{server.romTitle}</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#F59E0B] font-mono-tabular">
                Máx {sysInfo?.maxPlayers ?? server.maxPlayers}P
              </span>
              <span aria-hidden="true">·</span>
              <span
                className={`inline-flex items-center gap-1 font-medium ${
                  peerConnected
                    ? 'text-[#4ADE80]'
                    : hasGuest
                    ? 'text-[#FBBF24]'
                    : 'text-[#9AA3B2]'
                }`}
              >
                <Wifi className="w-3.5 h-3.5" />
                {connectionLabel}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white">{server.name}</h2>
            <p className="text-xs text-[#A1AAB8]">
              {isHost
                ? 'Você é o Host (P1): somente este celular escolhe o jogo, navega no menu principal e inicia a partida.'
                : 'Você é o Convidado (P2): seus botões controlam exclusivamente o Jogador 2 quando o Host iniciar a partida.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center gap-2 px-3 py-2 bg-[#0D0F12] border border-white/15 rounded-xl">
              <span className="text-xs text-[#9AA3B2]">Código:</span>
              <span className="font-mono-tabular text-sm font-semibold text-[#F59E0B] tracking-wider">
                {server.inviteCode}
              </span>
              <button
                type="button"
                onClick={() => void copyCode()}
                className="p-1 text-[#9AA3B2] hover:text-white cursor-pointer"
                title="Copiar código do servidor"
              >
                {copiedCode ? (
                  <Check className="w-4 h-4 text-[#4ADE80]" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            <button
              type="button"
              onClick={() => void handleNativeShare()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3.5 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              Convidar Outro Celular
            </button>

            <button
              type="button"
              onClick={() => void copyLink()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252A34] text-white border border-white/10 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copiedLink ? (
                <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
              ) : (
                <Link2 className="w-3.5 h-3.5" />
              )}
              {copiedLink ? 'Link Copiado' : 'Copiar Link'}
            </button>

            {hasGuest && rtcStatus !== 'connected' && isHost && (
              <button
                type="button"
                onClick={() => void rtcRef.current?.restartOffer()}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252A34] text-white border border-white/10 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reconectar P2P
              </button>
            )}

            <button
              type="button"
              onClick={() => void onLeaveOrClose()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#2A1618] hover:bg-[#3A1D20] text-[#FCA5A5] border border-[#EF4444]/30 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              {isHost ? 'Encerrar Servidor' : 'Sair da Sala'}
            </button>
          </div>
        </div>

        {shareFeedback && (
          <div className="px-3.5 py-2 rounded-xl bg-[#14261B] border border-[#22C55E]/35 text-xs text-[#86EFAC]">
            {shareFeedback}
          </div>
        )}

        {stateSyncStatus && (
          <div className="px-3.5 py-2 rounded-xl bg-[#0F1B29] border border-[#38BDF8]/35 text-xs text-[#7DD3FC]">
            {stateSyncStatus}
          </div>
        )}

        {romTransfer && (
          <div className="px-3.5 py-2.5 rounded-xl bg-[#1B1410] border border-[#EA580C]/40 text-xs text-[#FDBA74] flex items-center justify-between gap-3">
            <span>
              {romTransfer.direction === 'send'
                ? `Enviando ROM "${romTransfer.fileName}" para o 2º celular...`
                : `Recebendo ROM "${romTransfer.fileName}" do Host...`}
            </span>
            <span className="font-mono-tabular font-semibold">{romTransfer.percent}%</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div className="xl:col-span-8">
          <EmulatorViewport
            activeRom={fallbackInfo}
            activeRomBytes={activeRomBytes}
            neogeoBiosBytes={neogeoBiosBytes}
            arcadeBiosFiles={arcadeBiosFiles}
            playerSlot={mySlot}
            isNetplayActive={true}
            peerConnected={peerConnected}
            matchPhase={effectiveMatchPhase}
            frameDelay={roomState?.frameDelay ?? server.frameDelay}
            remoteInputRef={remoteInputRef}
            ggpoRef={ggpoRef}
            captureStateRef={captureStateRef}
            incomingStateSync={incomingStateSync}
            onSendLocalInput={sendLocalInput}
            onGgpoStats={setGgpoStats}
            onShareNesRom={shareNesRom}
            onShareRomBytes={(name, bytes) => void shareRomBytes(name, bytes)}
            incomingSharedRom={incomingSharedRom}
            incomingSharedRomBytes={incomingSharedRomBytes}
            onRomFileLoaded={onRomFileLoaded}
            onRomFilesSelected={onRomFilesSelected}
            onHostPauseChange={(p) => void setHostMatchPhase(p ? 'paused' : 'playing')}
            onHostReset={() => void handleHostResetSignal()}
          />
        </div>

        <div className="xl:col-span-4 flex flex-col gap-4">
          {/* Host Menu & Match Authority Card */}
          <div className="border border-white/10 bg-[#15181E] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#EA580C]" />
                Controle do Menu e Partida
              </h3>
              <span
                className={`text-[11px] font-mono-tabular ${
                  effectiveMatchPhase === 'playing'
                    ? 'text-[#4ADE80]'
                    : effectiveMatchPhase === 'paused'
                    ? 'text-[#FBBF24]'
                    : 'text-[#FB923C]'
                }`}
              >
                {phaseLabel}
              </span>
            </div>

            {isHost ? (
              <div className="space-y-2.5">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => void setHostMatchPhase('playing')}
                    className={`min-h-[42px] inline-flex items-center justify-center gap-1.5 px-3 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                      effectiveMatchPhase === 'playing'
                        ? 'bg-[#16A34A] text-white'
                        : 'bg-[#EA580C] hover:bg-[#DC4E07] text-white'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5" />
                    Iniciar Partida
                  </button>

                  <button
                    type="button"
                    onClick={() => void setHostMatchPhase('menu')}
                    className={`min-h-[42px] inline-flex items-center justify-center gap-1.5 px-3 text-xs font-semibold rounded-xl border transition-colors cursor-pointer ${
                      effectiveMatchPhase === 'menu'
                        ? 'bg-[#272D39] border-[#EA580C] text-white'
                        : 'bg-[#0D0F12] border-white/15 hover:bg-[#1C2028] text-[#D1D5DB]'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" />
                    Menu (Travar P2)
                  </button>
                </div>

                {hasGuest && (
                  <button
                    type="button"
                    onClick={() => void pushStateToPeer()}
                    className="min-h-[40px] w-full inline-flex items-center justify-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252A34] text-white border border-white/10 rounded-xl transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-[#38BDF8]" />
                    Sincronizar Tela / Snapshot para P2
                  </button>
                )}

                {onHostSelectRom && multiplayerSwitchableRoms.length > 0 && (
                  <label className="block space-y-1 pt-1">
                    <span className="text-[11px] text-[#9AA3B2]">
                      Trocar jogo da sala (somente Host P1):
                    </span>
                    <select
                      value={server.romId}
                      onChange={(e) => {
                        const chosen = multiplayerSwitchableRoms.find(
                          (r) => r.romId === e.target.value
                        );
                        if (chosen) {
                          autoSentRomForGuestRef.current = null;
                          void onHostSelectRom(chosen);
                        }
                      }}
                      className="min-h-[40px] w-full px-3 text-xs bg-[#0D0F12] border border-white/15 rounded-xl text-white focus:border-[#EA580C] focus:outline-none"
                    >
                      {!multiplayerSwitchableRoms.some((r) => r.romId === server.romId) && (
                        <option value={server.romId}>{server.romTitle}</option>
                      )}
                      {multiplayerSwitchableRoms.map((r) => (
                        <option key={r.romId} value={r.romId}>
                          {r.title} ({getSystemById(r.systemId)?.shortName || r.systemId})
                        </option>
                      ))}
                    </select>
                  </label>
                )}
              </div>
            ) : (
              <div className="px-3 py-2.5 rounded-xl bg-[#0D0F12] border border-white/10 text-xs text-[#A1AAB8] leading-relaxed">
                {effectiveMatchPhase === 'menu'
                  ? 'O Host (P1) está no menu principal escolhendo o jogo/opções. Seu controle P2 será liberado assim que o Host iniciar a partida.'
                  : effectiveMatchPhase === 'paused'
                  ? 'Partida pausada pelo Host (P1). Aguarde o Host retomar.'
                  : 'Partida ativa: você controla exclusivamente o Jogador 2 (P2).'}
              </div>
            )}
          </div>

          {/* Independent P1 & P2 Character Selection Card */}
          <div className="border border-white/10 bg-[#15181E] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Seleção de Personagem</h3>
              <span className="text-[11px] text-[#9AA3B2]">Sincronizada P1 &amp; P2</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-1 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-[#0D0F12] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono-tabular text-[#F59E0B]">Personagem P1 (Host)</span>
                  <span className="text-white font-semibold truncate max-w-[140px]">
                    {p1Character}
                  </span>
                </div>
                {isHost && (
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap gap-1.5">
                      {CHARACTER_PRESETS.map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => void handleSaveMyCharacter(preset)}
                          className={`px-2.5 py-1 text-[11px] rounded-lg border transition-colors cursor-pointer ${
                            myCharInput === preset
                              ? 'bg-[#EA580C] border-[#EA580C] text-white'
                              : 'bg-[#15181E] border-white/10 text-[#9AA3B2] hover:text-white'
                          }`}
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        void handleSaveMyCharacter(myCharInput);
                      }}
                      className="flex gap-1.5"
                    >
                      <input
                        type="text"
                        value={myCharInput}
                        onChange={(e) => setMyCharInput(e.target.value)}
                        maxLength={32}
                        placeholder="Nome do seu personagem P1..."
                        className="flex-1 min-h-[36px] px-2.5 text-xs bg-[#15181E] border border-white/10 rounded-lg text-white focus:border-[#EA580C] focus:outline-none"
                      />
                      <button
                        type="submit"
                        disabled={charSaving}
                        className="px-3 min-h-[36px] text-[11px] font-semibold bg-[#EA580C] text-white rounded-lg cursor-pointer"
                      >
                        Salvar
                      </button>
                    </form>
                  </div>
                )}
              </div>

              <div className="p-3 rounded-xl bg-[#0D0F12] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono-tabular text-[#38BDF8]">Personagem P2 (Convidado)</span>
                  <span className="text-white font-semibold truncate max-w-[140px]">
                    {p2Character}
                  </span>
                </div>
                {!isHost && (
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap gap-1.5">
                      {CHARACTER_PRESETS.map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => void handleSaveMyCharacter(preset)}
                          className={`px-2.5 py-1 text-[11px] rounded-lg border transition-colors cursor-pointer ${
                            myCharInput === preset
                              ? 'bg-[#0284C7] border-[#0284C7] text-white'
                              : 'bg-[#15181E] border-white/10 text-[#9AA3B2] hover:text-white'
                          }`}
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        void handleSaveMyCharacter(myCharInput);
                      }}
                      className="flex gap-1.5"
                    >
                      <input
                        type="text"
                        value={myCharInput}
                        onChange={(e) => setMyCharInput(e.target.value)}
                        maxLength={32}
                        placeholder="Nome do seu personagem P2..."
                        className="flex-1 min-h-[36px] px-2.5 text-xs bg-[#15181E] border border-white/10 rounded-lg text-white focus:border-[#38BDF8] focus:outline-none"
                      />
                      <button
                        type="submit"
                        disabled={charSaving}
                        className="px-3 min-h-[36px] text-[11px] font-semibold bg-[#0284C7] text-white rounded-lg cursor-pointer"
                      >
                        Salvar
                      </button>
                    </form>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Players & GGPO Telemetry Card */}
          <div className="border border-white/10 bg-[#15181E] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-[#EA580C]" />
                Jogadores na Sala
              </h3>
              <span className="text-xs font-mono-tabular text-[#9AA3B2]">Você: {mySlot}</span>
            </div>

            <div className="space-y-2.5 text-sm">
              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-xl">
                <div className="min-w-0">
                  <div className="text-xs text-[#F59E0B] font-mono-tabular">P1 · Host</div>
                  <div className="text-sm font-medium text-white truncate">
                    {server.hostGamertag}
                  </div>
                  <div className="text-[10px] font-mono-tabular text-[#7E8796] truncate">
                    ID: {p1DeviceLabel}
                  </div>
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  <div>{isHost ? 'Este celular' : pingMs ? `${pingMs} ms` : 'Online'}</div>
                  <div className={p1Ready ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                    {p1Ready ? 'Pronto' : 'Na sala'}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-xl">
                <div className="min-w-0">
                  <div className="text-xs text-[#38BDF8] font-mono-tabular">P2 · Convidado</div>
                  <div className="text-sm font-medium text-white truncate">
                    {hasGuest ? server.guestGamertag : 'Aguardando 2º celular entrar...'}
                  </div>
                  {hasGuest && (
                    <div className="text-[10px] font-mono-tabular text-[#7E8796] truncate">
                      ID: {p2DeviceLabel}
                    </div>
                  )}
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  {hasGuest ? (
                    <>
                      <div>{!isHost ? 'Este celular' : pingMs ? `${pingMs} ms` : 'Online'}</div>
                      <div className={p2Ready ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                        {p2Ready ? 'Pronto' : 'Na sala'}
                      </div>
                    </>
                  ) : (
                    <span>Vaga livre</span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[#9AA3B2] px-1">
              <span>GGPO Rollbacks: {ggpoStats.rollbackCount}</span>
              <span>Drift: {ggpoStats.frameAdvantage}f</span>
              <span>Delay: {roomState?.frameDelay ?? server.frameDelay}f</span>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={toggleReady}
                className={`min-h-[44px] flex-1 py-2 px-3 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                  myReady
                    ? 'bg-[#16A34A] hover:bg-[#15803D] text-white'
                    : 'bg-[#EA580C] hover:bg-[#DC4E07] text-white'
                }`}
              >
                {myReady ? 'Confirmado (Pronto)' : 'Marcar Pronto'}
              </button>

              {isHost && (
                <div className="flex items-center gap-2 text-xs text-[#9AA3B2]">
                  <span>Delay:</span>
                  <select
                    value={server.frameDelay}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      void onUpdateFrameDelay(val);
                      wsRef.current?.send(JSON.stringify({ type: 'room:config', frameDelay: val }));
                    }}
                    className="px-2 py-2 bg-[#0D0F12] border border-white/15 rounded-xl text-white font-mono-tabular"
                  >
                    {[0, 1, 2, 3, 4, 5, 6].map((f) => (
                      <option key={f} value={f}>
                        {f}f
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Room Chat */}
          <div className="border border-white/10 bg-[#15181E] rounded-2xl flex flex-col h-[280px]">
            <div className="px-4 py-3 border-b border-white/10 text-xs font-semibold text-white">
              Chat da Sala
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2 text-xs">
              {firestoreChat.length === 0 && (
                <p className="text-[#8E98A8] py-4 text-center">
                  Converse com o outro jogador ou sincronize a ROM para P2 clicando em Enviar P2 acima da tela.
                </p>
              )}
              {firestoreChat.map((msg) => (
                <div key={msg.messageId} className="leading-relaxed">
                  <span className="font-semibold text-[#F59E0B]">{msg.senderGamertag}: </span>
                  <span className="text-[#E5E7EB] break-words">{msg.text}</span>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <form
              onSubmit={(e) => void sendChat(e)}
              className="p-2.5 border-t border-white/10 flex items-center gap-2"
            >
              <input
                type="text"
                value={chatText}
                onChange={(e) => setChatText(e.target.value)}
                maxLength={240}
                placeholder="Enviar mensagem na sala..."
                className="min-h-[40px] flex-1 px-3 py-1.5 text-xs bg-[#0D0F12] border border-white/10 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
              />
              <button
                type="submit"
                aria-label="Enviar mensagem"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
