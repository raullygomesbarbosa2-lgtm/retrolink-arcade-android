import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Link2,
  LogOut,
  RefreshCw,
  Send,
  Share2,
  Users,
  Wifi,
} from 'lucide-react';
import { getSystemById } from '../data/catalog';
import {
  RoomChatDoc,
  sendRoomChatMessage,
  subscribeToRoomChatMessages,
} from '../services/firestoreService';
import { RtcNetplaySession, RtcStatus } from '../services/rtcNetplay';
import {
  GameServer,
  LiveRoomState,
  ParsedRomInfo,
  UserPublicProfile,
} from '../types/retrolink';
import {
  buildAppShareUrl,
  shareAccessWithFriend,
} from '../utils/shareLink';
import { BiosArchiveFile, EmulatorViewport } from './EmulatorViewport';

// Capacitor runs the app on localhost, so multiplayer WebSockets must connect
// to the remote relay rather than window.location.host. VITE_NETPLAY_URL is
// supplied by the Android build workflow; keep the public relay as fallback.
const NETPLAY_RELAY_URL = (
  import.meta.env.VITE_NETPLAY_URL || 'https://retrolink-arcade-relay.onrender.com'
).trim();

function createNetplayWebSocket(): WebSocket {
  const relay = new URL(NETPLAY_RELAY_URL);
  const protocol = relay.protocol === 'https:' || relay.protocol === 'wss:' ? 'wss:' : 'ws:';
  const basePath = relay.pathname.replace(/\/+$/, '');
  const path = basePath.endsWith('/ws') ? basePath : `${basePath}/ws`;
  return new WebSocket(`${protocol}//${relay.host}${path}`);
}

interface MultiplayerRoomPanelProps {
  server: GameServer;
  profile: UserPublicProfile;
  activeRom: ParsedRomInfo | null;
  activeRomBytes: Uint8Array | null;
  neogeoBiosBytes?: Uint8Array | null;
  arcadeBiosFiles?: BiosArchiveFile[];
  onRomFileLoaded: (info: ParsedRomInfo, bytes: Uint8Array) => void;
  onRomFilesSelected?: (files: FileList | File[]) => void;
  onLeaveOrClose: () => Promise<void>;
  onUpdateFrameDelay: (delay: number) => Promise<void>;
}

export function MultiplayerRoomPanel({
  server,
  profile,
  activeRom,
  activeRomBytes,
  neogeoBiosBytes,
  arcadeBiosFiles,
  onRomFileLoaded,
  onRomFilesSelected,
  onLeaveOrClose,
  onUpdateFrameDelay,
}: MultiplayerRoomPanelProps) {
  const wsRef = useRef<WebSocket | null>(null);
  const rtcRef = useRef<RtcNetplaySession | null>(null);
  const remoteInputRef = useRef<{ p1: number; p2: number }>({ p1: 0, p2: 0 });
  const mySlotRef = useRef<'P1' | 'P2' | 'SPEC'>('SPEC');
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const autoSentRomForGuestRef = useRef<string | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [rtcStatus, setRtcStatus] = useState<RtcStatus>('waiting_peer');
  const [roomState, setRoomState] = useState<LiveRoomState | null>(null);
  const [firestoreChat, setFirestoreChat] = useState<RoomChatDoc[]>([]);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [myReady, setMyReady] = useState(false);
  const [peerReady, setPeerReady] = useState(false);

  const [chatText, setChatText] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  const [incomingSharedRom, setIncomingSharedRom] = useState<{ fileName: string; base64: string } | null>(null);
  const [incomingSharedRomBytes, setIncomingSharedRomBytes] = useState<{
    fileName: string;
    bytes: Uint8Array;
  } | null>(null);
  const [romTransfer, setRomTransfer] = useState<{
    direction: 'send' | 'receive';
    percent: number;
    fileName: string;
  } | null>(null);

  const isHost = server.hostUid === profile.uid;
  // Use the relay's assigned slot, not the invite/arrival order or the
  // client's host guess, to decide which controller this phone may send.
  const mySlot: 'P1' | 'P2' | 'SPEC' =
    roomState?.participants.find((participant) => participant.uid === profile.uid)?.slot || 'SPEC';
  mySlotRef.current = mySlot;
  const peerUid = isHost ? server.guestUid : server.hostUid;
  const hasGuest = Boolean(server.guestUid && server.guestUid !== server.hostUid);

  // 1. Cross-device WebRTC P2P connection signaled via Firestore (works between any 2 phones & across ais-dev/ais-pre)
  useEffect(() => {
    if (!hasGuest || !peerUid) {
      setRtcStatus('waiting_peer');
      setPeerReady(false);
      rtcRef.current?.dispose();
      rtcRef.current = null;
      return;
    }

    const session = new RtcNetplaySession({
      serverId: server.serverId,
      myUid: profile.uid,
      peerUid,
      hostUid: server.hostUid,
      guestUid: server.guestUid,
      isHost,
      playerSlot: mySlot,
      onStatusChange: (status) => {
        setRtcStatus(status);
      },
      onRemoteInput: (_frame, mask, senderSlot) => {
        const slot = mySlotRef.current;
        if (slot === 'P1' && senderSlot === 'P2') remoteInputRef.current.p2 = mask;
        else if (slot === 'P2' && senderSlot === 'P1') remoteInputRef.current.p1 = mask;
      },
      onPingMeasured: (rtt) => setPingMs(rtt),
      onPeerReady: (ready) => setPeerReady(ready),
      onRomTransferProgress: (info) => {
        setRomTransfer(info);
        if (info.percent >= 100) {
          window.setTimeout(() => setRomTransfer(null), 1800);
        }
      },
      onRomReceived: (fileName, bytes) => {
        setIncomingSharedRomBytes({ fileName, bytes });
        setRomTransfer(null);
      },
    });

    rtcRef.current = session;
    return () => {
      session.dispose();
      if (rtcRef.current === session) {
        rtcRef.current = null;
      }
    };
  }, [server.serverId, server.hostUid, server.guestUid, profile.uid, isHost, hasGuest, peerUid, mySlot]);

  // 2. Persistent cross-device chat synced via Firestore
  useEffect(() => {
    const unsub = subscribeToRoomChatMessages(server.serverId, isHost, profile.uid, (msgs) => {
      setFirestoreChat(msgs);
    });
    return () => unsub();
  }, [server.serverId, isHost, profile.uid]);

  // 3. Transfer the host ROM to P2 only after a channel accepts it. The
  // peer connection can report "connected" before the ordered control channel
  // opens, so retry and use the room relay for supported ROM sizes as fallback.
  useEffect(() => {
    if (!isHost || !hasGuest || !activeRomBytes || !activeRom) return;
    const transferKey = `${server.guestUid}_${activeRom.romId}`;
    if (autoSentRomForGuestRef.current === transferKey) return;

    let cancelled = false;
    let retryTimer: number | null = null;
    let attempts = 0;

    const sendAutomatically = async () => {
      if (cancelled || autoSentRomForGuestRef.current === transferKey) return;
      attempts += 1;
      let sent = false;

      if (rtcRef.current?.isP2PReady()) {
        sent = await rtcRef.current.sendRomBytes(activeRom.fileName, activeRomBytes);
      }

      if (!sent && activeRomBytes.length <= 8_000_000) {
        const ws = wsRef.current;
        if (ws && ws.readyState === WebSocket.OPEN) {
          const bin = Array.from(activeRomBytes, (b) => String.fromCharCode(b)).join('');
          ws.send(JSON.stringify({
            type: 'rom:share',
            fileName: activeRom.fileName,
            base64: btoa(bin),
          }));
          sent = true;
        }
      }

      if (sent) {
        autoSentRomForGuestRef.current = transferKey;
      } else if (attempts < 40 && !cancelled) {
        retryTimer = window.setTimeout(() => void sendAutomatically(), 1000);
      }
    };

    void sendAutomatically();
    return () => {
      cancelled = true;
      if (retryTimer !== null) window.clearTimeout(retryTimer);
    };
  }, [isHost, hasGuest, server.guestUid, activeRom?.romId, activeRom?.fileName, activeRomBytes]);

  // 4. Optional same-origin WebSocket relay (fast secondary fallback)
  useEffect(() => {
    let closedByUser = false;
    let reconnectTimer: number | null = null;
    let pingInterval: number | null = null;

    const connect = () => {
      let ws: WebSocket;
      try {
        ws = createNetplayWebSocket();
      } catch {
        setWsConnected(false);
        return;
      }
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        ws.send(
          JSON.stringify({
            type: 'room:join',
            serverId: server.serverId,
            uid: profile.uid,
            gamertag: profile.gamertag,
            role: isHost ? 'host' : 'guest',
            romId: server.romId,
            romTitle: server.romTitle,
            systemId: server.systemId,
            frameDelay: server.frameDelay,
          })
        );

        pingInterval = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'netplay:ping', ts: performance.now(), lastRtt: pingMs ?? 12 }));
          }
        }, 2500);
      };

      ws.onmessage = (event) => {
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(event.data);
        } catch {
          return;
        }

        if (msg.type === 'netplay:pong' && typeof msg.ts === 'number') {
          if (rtcStatus !== 'connected') {
            const rtt = Math.max(1, Math.round(performance.now() - msg.ts));
            setPingMs(rtt);
          }
          return;
        }

        if (msg.type === 'room:state' && msg.room) {
          setRoomState(msg.room as LiveRoomState);
          return;
        }

        if (msg.type === 'netplay:remote_input') {
          const slot = msg.slot;
          const mask = typeof msg.mask === 'number' ? msg.mask : 0;
          const mySlot = mySlotRef.current;
          if (slot === 'P1' && mySlot === 'P2') remoteInputRef.current.p1 = mask;
          else if (slot === 'P2' && mySlot === 'P1') remoteInputRef.current.p2 = mask;
          return;
        }

        if (msg.type === 'rom:shared' && typeof msg.base64 === 'string' && !isHost) {
          setIncomingSharedRom({
            fileName: typeof msg.fileName === 'string' ? msg.fileName : 'shared.rom',
            base64: msg.base64,
          });
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (pingInterval) window.clearInterval(pingInterval);
        if (!closedByUser) {
          reconnectTimer = window.setTimeout(connect, 2200);
        }
      };
    };

    connect();

    return () => {
      closedByUser = true;
      if (pingInterval) window.clearInterval(pingInterval);
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [server.serverId, profile.uid, profile.gamertag, isHost]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [firestoreChat.length]);

  const sendLocalInput = (frame: number, mask: number) => {
    // Ignore local pad packets until this uid owns a P1/P2 slot in the room.
    if (mySlotRef.current !== 'P1' && mySlotRef.current !== 'P2') return;
    const sentP2P = rtcRef.current?.sendInput(frame, mask);
    if (!sentP2P) {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'netplay:input', frame, mask }));
      }
    }
  };

  const shareRomBytes = async (fileName: string, bytes: Uint8Array) => {
    if (rtcRef.current?.isP2PReady()) {
      await rtcRef.current.sendRomBytes(fileName, bytes);
      return;
    }
    if (bytes.length <= 8_000_000) {
      const bin = Array.from(bytes, (b) => String.fromCharCode(b)).join('');
      const base64 = btoa(bin);
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'rom:share', fileName, base64 }));
      }
    }
  };

  const shareNesRom = (fileName: string, base64: string) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'rom:share', fileName, base64 }));
    }
  };

  const toggleReady = () => {
    const next = !myReady;
    setMyReady(next);
    void rtcRef.current?.sendReady(next);
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'room:ready', ready: next }));
    }
  };

  const sendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = chatText.trim();
    if (!text) return;
    setChatText('');
    await sendRoomChatMessage({
      serverId: server.serverId,
      senderUid: profile.uid,
      senderGamertag: profile.gamertag,
      hostUid: server.hostUid,
      guestUid: server.guestUid || '',
      text,
    });
  };

  const inviteUrl = buildAppShareUrl(server.inviteCode);

  const copyCode = async () => {
    await navigator.clipboard.writeText(server.inviteCode);
    setCopiedCode(true);
    window.setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    window.setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleNativeShare = async () => {
    try {
      const result = await shareAccessWithFriend({
        title: `RetroLink · ${server.romTitle}`,
        text: `Entre comigo no emulador RetroLink!\n1) Abra o link no seu celular (dá para instalar como App)\n2) Crie sua conta por e-mail\n3) Código da sala: ${server.inviteCode}`,
        url: inviteUrl,
      });
      setShareFeedback(
        result === 'shared'
          ? 'Convite e link do app enviados!'
          : 'Link do app + código copiados! Cole no WhatsApp do seu amigo.'
      );
      window.setTimeout(() => setShareFeedback(null), 3500);
    } catch {
      // user canceled native share sheet
    }
  };

  const wsP1 = roomState?.participants.find((p) => p.slot === 'P1');
  const wsP2 = roomState?.participants.find((p) => p.slot === 'P2');
  const p1Ready = isHost ? myReady : peerReady || Boolean(wsP1?.ready);
  const p2Ready = isHost ? peerReady || Boolean(wsP2?.ready) : myReady;
  const sysInfo = getSystemById(server.systemId);

  const fallbackInfo: ParsedRomInfo | null =
    activeRom ||
    (activeRomBytes
      ? {
          romId: server.romId,
          title: server.romTitle,
          fileName: server.romTitle,
          systemId: server.systemId,
          coreName: sysInfo?.libretroCore || 'snes9x',
          crc32: '00000000',
          sizeBytes: activeRomBytes.length,
          headerSummary: sysInfo?.nativeCore || 'RetroArch WASM',
          playableInBrowser: true,
        }
      : null);

  const connectionLabel =
    rtcStatus === 'connected'
      ? `P2P Direto Conectado (${pingMs ?? 14} ms)`
      : hasGuest
      ? wsConnected && wsP1 && wsP2
        ? `Relay Conectado (${pingMs ?? 18} ms)`
        : 'Conectando P2P entre celulares...'
      : 'Aguardando 2º celular';

  return (
    <section className="space-y-5">
      <div className="border border-white/10 bg-[#15181E] rounded-2xl p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#9AA3B2]">
              <span>{sysInfo?.name || server.systemId}</span>
              <span aria-hidden="true">·</span>
              <span className="text-white font-medium">{server.romTitle}</span>
              <span aria-hidden="true">·</span>
              <span
                className={`inline-flex items-center gap-1 font-medium ${
                  rtcStatus === 'connected' || (hasGuest && wsP1 && wsP2)
                    ? 'text-[#4ADE80]'
                    : hasGuest
                    ? 'text-[#FBBF24]'
                    : 'text-[#9AA3B2]'
                }`}
              >
                <Wifi className="w-3.5 h-3.5" />
                {connectionLabel}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white">{server.name}</h2>
            <p className="text-xs text-[#A1AAB8]">
              Envie o link abaixo para o outro celular abrir/instalar o app com entrada direta nesta sala:
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center gap-2 px-3 py-2 bg-[#0D0F12] border border-white/15 rounded-xl">
              <span className="text-xs text-[#9AA3B2]">Código:</span>
              <span className="font-mono-tabular text-sm font-semibold text-[#F59E0B] tracking-wider">
                {server.inviteCode}
              </span>
              <button
                type="button"
                onClick={() => void copyCode()}
                className="p-1 text-[#9AA3B2] hover:text-white cursor-pointer"
                title="Copiar código do servidor"
              >
                {copiedCode ? <Check className="w-4 h-4 text-[#4ADE80]" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <button
              type="button"
              onClick={() => void handleNativeShare()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3.5 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              Convidar Outro Celular
            </button>

            <button
              type="button"
              onClick={() => void copyLink()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252A34] text-white border border-white/10 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-[#4ADE80]" /> : <Link2 className="w-3.5 h-3.5" />}
              {copiedLink ? 'Link Copiado' : 'Copiar Link'}
            </button>

            {hasGuest && rtcStatus !== 'connected' && isHost && (
              <button
                type="button"
                onClick={() => void rtcRef.current?.restartOffer()}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252A34] text-white border border-white/10 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reconectar P2P
              </button>
            )}

            <button
              type="button"
              onClick={() => void onLeaveOrClose()}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#2A1618] hover:bg-[#3A1D20] text-[#FCA5A5] border border-[#EF4444]/30 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              {isHost ? 'Encerrar Servidor' : 'Sair da Sala'}
            </button>
          </div>
        </div>

        {shareFeedback && (
          <div className="px-3.5 py-2 rounded-xl bg-[#14261B] border border-[#22C55E]/35 text-xs text-[#86EFAC]">
            {shareFeedback}
          </div>
        )}

        {romTransfer && (
          <div className="px-3.5 py-2.5 rounded-xl bg-[#1B1410] border border-[#EA580C]/40 text-xs text-[#FDBA74] flex items-center justify-between gap-3">
            <span>
              {romTransfer.direction === 'send'
                ? `Enviando ROM "${romTransfer.fileName}" para o 2º celular...`
                : `Recebendo ROM "${romTransfer.fileName}" do Host...`}
            </span>
            <span className="font-mono-tabular font-semibold">{romTransfer.percent}%</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div className="xl:col-span-8">
          <EmulatorViewport
            activeRom={fallbackInfo}
            activeRomBytes={activeRomBytes}
            neogeoBiosBytes={neogeoBiosBytes}
            arcadeBiosFiles={arcadeBiosFiles}
            playerSlot={mySlot}
            isNetplayActive={true}
            frameDelay={roomState?.frameDelay ?? server.frameDelay}
            remoteInputRef={remoteInputRef}
            onSendLocalInput={sendLocalInput}
            onShareNesRom={shareNesRom}
            onShareRomBytes={(name, bytes) => void shareRomBytes(name, bytes)}
            incomingSharedRom={incomingSharedRom}
            incomingSharedRomBytes={incomingSharedRomBytes}
            onRomFileLoaded={onRomFileLoaded}
            onRomFilesSelected={onRomFilesSelected}
          />
        </div>

        <div className="xl:col-span-4 flex flex-col gap-4">
          <div className="border border-white/10 bg-[#15181E] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-[#EA580C]" />
                Jogadores na Sala
              </h3>
              <span className="text-xs font-mono-tabular text-[#9AA3B2]">Você: {mySlot}</span>
            </div>

            <div className="space-y-2.5 text-sm">
              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-xl">
                <div className="min-w-0">
                  <div className="text-xs text-[#F59E0B] font-mono-tabular">P1 · Host</div>
                  <div className="text-sm font-medium text-white truncate">{server.hostGamertag}</div>
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  <div>{isHost ? 'Este celular' : pingMs ? `${pingMs} ms` : 'Online'}</div>
                  <div className={p1Ready ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                    {p1Ready ? 'Pronto' : 'Na sala'}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-xl">
                <div className="min-w-0">
                  <div className="text-xs text-[#38BDF8] font-mono-tabular">P2 · Convidado</div>
                  <div className="text-sm font-medium text-white truncate">
                    {hasGuest ? server.guestGamertag : 'Aguardando 2º celular entrar...'}
                  </div>
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  {hasGuest ? (
                    <>
                      <div>{!isHost ? 'Este celular' : pingMs ? `${pingMs} ms` : 'Online'}</div>
                      <div className={p2Ready ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                        {p2Ready ? 'Pronto' : 'Na sala'}
                      </div>
                    </>
                  ) : (
                    <span>Vaga livre</span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={toggleReady}
                className={`min-h-[44px] flex-1 py-2 px-3 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                  myReady
                    ? 'bg-[#16A34A] hover:bg-[#15803D] text-white'
                    : 'bg-[#EA580C] hover:bg-[#DC4E07] text-white'
                }`}
              >
                {myReady ? 'Confirmado (Pronto)' : 'Marcar Pronto'}
              </button>

              {isHost && (
                <div className="flex items-center gap-2 text-xs text-[#9AA3B2]">
                  <span>Delay:</span>
                  <select
                    value={server.frameDelay}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      void onUpdateFrameDelay(val);
                      wsRef.current?.send(JSON.stringify({ type: 'room:config', frameDelay: val }));
                    }}
                    className="px-2 py-2 bg-[#0D0F12] border border-white/15 rounded-xl text-white font-mono-tabular"
                  >
                    {[0, 1, 2, 3, 4, 5, 6].map((f) => (
                      <option key={f} value={f}>
                        {f}f
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          <div className="border border-white/10 bg-[#15181E] rounded-2xl flex flex-col h-[310px]">
            <div className="px-4 py-3 border-b border-white/10 text-xs font-semibold text-white">
              Chat da Sala
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2 text-xs">
              {firestoreChat.length === 0 && (
                <p className="text-[#8E98A8] py-4 text-center">
                  Converse com o outro jogador ou envie sua ROM para P2 clicando em Enviar P2 acima da tela.
                </p>
              )}
              {firestoreChat.map((msg) => (
                <div key={msg.messageId} className="leading-relaxed">
                  <span className="font-semibold text-[#F59E0B]">{msg.senderGamertag}: </span>
                  <span className="text-[#E5E7EB] break-words">{msg.text}</span>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <form onSubmit={(e) => void sendChat(e)} className="p-2.5 border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                value={chatText}
                onChange={(e) => setChatText(e.target.value)}
                maxLength={240}
                placeholder="Enviar mensagem na sala..."
                className="min-h-[40px] flex-1 px-3 py-1.5 text-xs bg-[#0D0F12] border border-white/10 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
              />
              <button
                type="submit"
                aria-label="Enviar mensagem"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
