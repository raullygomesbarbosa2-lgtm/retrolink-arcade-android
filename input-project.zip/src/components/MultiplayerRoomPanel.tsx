import React, { useEffect, useRef, useState } from 'react';
import { LogOut, Send, Users } from 'lucide-react';
import { getSystemById } from '../data/catalog';
import { GameServer, LiveRoomState, ParsedRomInfo, UserLocalRom, UserPublicProfile } from '../types/retrolink';
import { EmulatorViewport } from './EmulatorViewport';

interface MultiplayerRoomPanelProps {
  server: GameServer;
  profile: UserPublicProfile;
  activeRom: ParsedRomInfo | null;
  activeRomBytes: Uint8Array | null;
  neogeoBiosBytes?: Uint8Array | null;
  arcadeBiosFiles?: Array<{ fileName: string; bytes: Uint8Array }>;
  onRomFileLoaded: (info: ParsedRomInfo, bytes: Uint8Array) => void;
  onRomFilesSelected?: (files: FileList | File[]) => void;
  savedRoms: UserLocalRom[];
  onChooseSavedRom: (rom: UserLocalRom) => Promise<boolean>;
  onLeaveOrClose: () => Promise<void>;
  onUpdateFrameDelay: (delay: number) => Promise<void>;
}

export function MultiplayerRoomPanel({
  server,
  profile,
  activeRom,
  activeRomBytes,
  neogeoBiosBytes,
  arcadeBiosFiles,
  onRomFileLoaded,
  onRomFilesSelected,
  savedRoms,
  onChooseSavedRom,
  onLeaveOrClose,
  onUpdateFrameDelay,
}: MultiplayerRoomPanelProps) {
  const wsRef = useRef<WebSocket | null>(null);
  const relayRetryCountRef = useRef(0);
  const remoteInputRef = useRef<{ p1: number; p2: number }>({ p1: 0, p2: 0 });
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [relayUnavailable, setRelayUnavailable] = useState(false);
  const [relayError, setRelayError] = useState<string | null>(null);
  const [roomState, setRoomState] = useState<LiveRoomState | null>(null);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [chatText, setChatText] = useState('');
  const [incomingSharedRom, setIncomingSharedRom] = useState<{ fileName: string; base64: string } | null>(null);
  const [showRomPicker, setShowRomPicker] = useState(false);
  const [choosingRomId, setChoosingRomId] = useState<string | null>(null);

  const isHost = server.hostUid === profile.uid;
  const configuredRelay = (import.meta.env.VITE_NETPLAY_URL as string | undefined)?.trim();
  // Production static hosting (GitHub Pages/APK) has no WebSocket server at its origin.
  // Only try a relay when an explicit public URL was configured; dev uses its local server.
  const relayAvailable = Boolean(configuredRelay || import.meta.env.DEV);

  useEffect(() => {
    let closedByUser = false;
    let reconnectTimer: number | null = null;
    let pingInterval: number | null = null;

    if (!relayAvailable) {
      setWsConnected(false);
      wsRef.current = null;
      return () => { closedByUser = true; };
    }

    const connect = () => {
      const relayUrl = new URL(configuredRelay || window.location.origin, window.location.href);
      const protocol = relayUrl.protocol === 'https:' || relayUrl.protocol === 'wss:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${relayUrl.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        relayRetryCountRef.current = 0;
        setRelayUnavailable(false);
        setWsConnected(true);
        ws.send(
          JSON.stringify({
            type: 'room:join',
            serverId: server.serverId,
            uid: profile.uid,
            gamertag: profile.gamertag,
            role: isHost ? 'host' : 'guest',
            romId: server.romId,
            romTitle: server.romTitle,
            systemId: server.systemId,
            frameDelay: server.frameDelay,
          })
        );

        pingInterval = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'netplay:ping', ts: performance.now(), lastRtt: pingMs ?? 12 }));
          }
        }, 2500);
      };

      ws.onmessage = (event) => {
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(event.data);
        } catch {
          return;
        }

        if (msg.type === 'netplay:pong' && typeof msg.ts === 'number') {
          const rtt = Math.max(1, Math.round(performance.now() - msg.ts));
          setPingMs(rtt);
          return;
        }

        if (msg.type === 'room:state' && msg.room) {
          setRelayError(null);
          setRoomState(msg.room as LiveRoomState);
          return;
        }

        if (msg.type === 'room:error') {
          setRelayError(typeof msg.message === 'string' ? msg.message : 'A sala do relay recusou a conexão.');
          setWsConnected(false);
          setRelayUnavailable(true);
          closedByUser = true; // A ROM/slot mismatch is not fixed by retrying the same join.
          ws.close(1008, 'room rejected');
          return;
        }

        if (msg.type === 'room:chat_msg' && msg.message) {
          setRoomState((prev) => {
            if (!prev) return prev;
            const nextMsg = msg.message as LiveRoomState['chat'][number];
            if (prev.chat.some((c) => c.id === nextMsg.id)) return prev;
            return { ...prev, chat: [...prev.chat, nextMsg].slice(-40) };
          });
          return;
        }

        if (msg.type === 'netplay:remote_input') {
          const slot = msg.slot;
          const mask = typeof msg.mask === 'number' ? msg.mask : 0;
          if (slot === 'P1') remoteInputRef.current.p1 = mask;
          else if (slot === 'P2') remoteInputRef.current.p2 = mask;
          return;
        }

        if (msg.type === 'rom:shared' && typeof msg.base64 === 'string') {
          setIncomingSharedRom({
            fileName: typeof msg.fileName === 'string' ? msg.fileName : 'shared.nes',
            base64: msg.base64,
          });
        }
      };

      ws.onerror = () => {
        setWsConnected(false);
        setRelayUnavailable(true);
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (pingInterval) window.clearInterval(pingInterval);
        if (!closedByUser) {
          relayRetryCountRef.current = Math.min(relayRetryCountRef.current + 1, 6);
          setRelayUnavailable(true);
          // Render free services can take about a minute to wake; don't give up
          // after three short retries while P1/P2 are entering the same room.
          const retryDelay = Math.min(1000 * (2 ** Math.min(relayRetryCountRef.current, 4)), 10000);
          reconnectTimer = window.setTimeout(connect, retryDelay);
        }
      };
    };

    connect();

    return () => {
      closedByUser = true;
      if (pingInterval) window.clearInterval(pingInterval);
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [server.serverId, profile.uid, profile.gamertag, isHost, relayAvailable, configuredRelay]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [roomState?.chat.length]);

  const liveMyParticipant = roomState?.participants.find((p) => p.uid === profile.uid);
  const myParticipant = liveMyParticipant || {
    uid: profile.uid,
    gamertag: profile.gamertag,
    slot: isHost ? 'P1' as const : 'P2' as const,
    ready: false,
    pingMs: 0,
    connected: wsConnected,
  };
  const mySlot: 'P1' | 'P2' | 'SPEC' = myParticipant.slot;

  const sendLocalInput = (frame: number, mask: number) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'netplay:input', frame, mask }));
    }
  };

  const shareNesRom = (fileName: string, base64: string) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'rom:share', fileName, base64 }));
    }
  };

  const sendChat = (e: React.FormEvent) => {
    e.preventDefault();
    const text = chatText.trim();
    if (!text) return;
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'room:chat', text }));
      setChatText('');
    }
  };

  const p1 = roomState?.participants.find((p) => p.slot === 'P1');
  const relayP1 = p1;
  const relayP2 = roomState?.participants.find((p) => p.slot === 'P2');
  const relayJoined = Boolean(wsConnected && liveMyParticipant);
  // Firestore membership is authoritative for the automatic pairing UI;
  // it keeps the wait indicator correct even while the game relay reconnects.
  const p2 = relayP2 || (server.guestUid ? {
    uid: server.guestUid,
    gamertag: server.guestGamertag || 'P2',
    slot: 'P2' as const,
    ready: false,
    pingMs: 0,
    connected: true,
  } : undefined);
  const sysInfo = getSystemById(server.systemId);

  const chooseSavedRom = async (rom: UserLocalRom) => {
    setChoosingRomId(rom.romId);
    try {
      if (await onChooseSavedRom(rom)) setShowRomPicker(false);
    } finally {
      setChoosingRomId(null);
    }
  };

  const fallbackInfo: ParsedRomInfo | null =
    activeRom ||
    (activeRomBytes
      ? {
          romId: server.romId,
          title: server.romTitle,
          fileName: server.romTitle,
          systemId: server.systemId,
          coreName: sysInfo?.libretroCore || 'snes9x',
          crc32: '00000000',
          sizeBytes: activeRomBytes.length,
          headerSummary: sysInfo?.nativeCore || 'RetroArch WASM',
          playableInBrowser: true,
        }
      : null);

  return (
    <section className="space-y-6">
      <div className="border border-white/10 bg-[#15181E] rounded-lg p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#9AA3B2]">
            <span>{sysInfo?.name || server.systemId}</span>
            <span aria-hidden="true">·</span>
            <span>{server.romTitle}</span>
            <span aria-hidden="true">·</span>
            <span className={relayJoined ? 'text-[#4ADE80]' : 'text-[#FBBF24]'}>
              {relayError
                ? 'Entrada no relay recusada'
                : !relayAvailable
                  ? 'Relay de jogo não configurado'
                  : relayJoined
                    ? `No relay da sala (${pingMs ?? 12} ms)`
                    : wsConnected
                      ? 'Relay online — entrando na sala…'
                      : relayUnavailable
                        ? 'Reconectando ao relay…'
                        : 'Conectando ao relay de jogo…'}
            </span>
          </div>
          <h2 className="text-xl font-bold text-white">{server.name}</h2>
          <p className="text-xs text-[#A1AAB8]" aria-live="polite">
            {relayError
              ? `Falha ao conectar os jogadores no relay: ${relayError}`
              : !relayAvailable
                ? 'Sala do lobby aberta, mas o relay de jogo não está configurado.'
                : relayP2 && p1
                  ? 'P1 e P2 estão conectados ao relay de jogo.'
                  : server.guestUid && !relayP2
                    ? `O lobby aceitou ${server.guestGamertag || 'o P2'}, mas o P2 ainda não conectou ao relay de jogo; tentando reconectar.`
                    : 'Sala pública aberta — aguardando o P2 entrar pela busca automática.'}
          </p>
          {!p2 && (
            <div className="mt-3 h-2 max-w-sm overflow-hidden rounded-full bg-[#0D0F12] border border-white/10" role="progressbar" aria-label="Aguardando segundo jogador">
              <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-[#EA580C] via-[#FDBA74] to-[#EA580C] animate-[matchscan_1.4s_ease-in-out_infinite]" />
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() => setShowRomPicker(true)}
          className="min-h-[44px] inline-flex items-center justify-center px-3 py-2 text-xs font-semibold bg-[#1C2028] text-white rounded-xl border border-white/10"
        >
          Escolher ROM salva
        </button>
        <button
          type="button"
          onClick={() => void onLeaveOrClose()}
          className="min-h-[44px] inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#2A1618] hover:bg-[#3A1D20] text-[#FCA5A5] border border-[#EF4444]/30 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          {isHost ? 'Encerrar partida' : 'Sair da partida'}
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div className="xl:col-span-8">
          <EmulatorViewport
            activeRom={fallbackInfo}
            activeRomBytes={activeRomBytes}
            neogeoBiosBytes={neogeoBiosBytes}
            arcadeBiosFiles={arcadeBiosFiles}
            playerSlot={mySlot}
            isNetplayActive={true}
            netplayRunning={Boolean(roomState?.matchRunning && roomState.participants.some((p) => p.slot === 'P1') && roomState.participants.some((p) => p.slot === 'P2'))}
            frameDelay={roomState?.frameDelay ?? server.frameDelay}
            remoteInputRef={remoteInputRef}
            onSendLocalInput={sendLocalInput}
            onShareNesRom={shareNesRom}
            incomingSharedRom={incomingSharedRom}
            onRomFileLoaded={onRomFileLoaded}
            onRomFilesSelected={onRomFilesSelected}
            onRequestRomLibrary={() => setShowRomPicker(true)}
            netplayChat={roomState?.chat || []}
            onSendChatMessage={(text) => { const ws = wsRef.current; if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'room:chat', text })); }}
            playerNames={{ p1: p1?.gamertag || server.hostGamertag, p2: p2?.gamertag || 'Aguardando...' }}
          />
        </div>

        <div className="xl:col-span-4 flex flex-col gap-4">
          <div className="border border-white/10 bg-[#15181E] rounded-lg p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-[#EA580C]" />
                Jogadores na Sala
              </h3>
              <span className="text-xs font-mono-tabular text-[#9AA3B2]">Você: {mySlot}</span>
            </div>

            <div className="space-y-2.5 text-sm">
              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-md">
                <div className="min-w-0">
                  <div className="text-xs text-[#F59E0B] font-mono-tabular">P1 · Host</div>
                  <div className="text-sm font-medium text-white truncate">
                    {p1?.gamertag || server.hostGamertag}
                  </div>
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  <div>{relayP1 ? `${relayP1.pingMs} ms` : '—'}</div>
                  <div className={!relayP1 ? 'text-[#FBBF24]' : roomState?.matchRunning ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                    {!relayP1 ? 'P1 entrando no relay' : !relayP2 ? 'P1 conectado · falta P2' : roomState?.matchRunning ? 'Partida ativa' : 'Sincronizando'}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between px-3 py-2.5 bg-[#0D0F12] border border-white/10 rounded-md">
                <div className="min-w-0">
                  <div className="text-xs text-[#38BDF8] font-mono-tabular">P2 · Convidado</div>
                  <div className="text-sm font-medium text-white truncate">
                    {p2?.gamertag || server.guestGamertag || 'Aguardando o P2 automático...'}
                  </div>
                </div>
                <div className="text-right text-xs font-mono-tabular text-[#9AA3B2] shrink-0">
                  {p2 ? (
                    <>
                      <div>{relayP2 ? `${relayP2.pingMs} ms` : '—'}</div>
                      <div className={!relayP2 ? 'text-[#FBBF24]' : relayP2.ready ? 'text-[#4ADE80]' : 'text-[#9AA3B2]'}>
                        {!relayP2 ? 'Lobby — sem relay' : relayP2.ready ? 'Conectado' : 'No relay'}
                      </div>
                    </>
                  ) : (
                    <span>Vaga livre</span>
                  )}
                </div>
              </div>
            </div>

            {roomState?.matchRunning && (
              <div className="rounded-lg border border-[#22C55E]/30 bg-[#102217] px-3 py-2 text-xs text-[#86EFAC]">
                P1 e P2 conectaram — partida iniciada automaticamente.
              </div>
            )}

            <div className="pt-2 border-t border-white/10">
              <div className={`w-full py-2.5 px-3 text-center text-xs font-semibold rounded-md ${
                !relayAvailable || relayUnavailable
                  ? 'bg-[#3A3F49] text-[#A1AAB8]'
                  : roomState?.matchRunning
                    ? 'bg-[#14532D] text-[#BBF7D0]'
                    : 'bg-[#33230D] text-[#FDE68A]'
              }`} aria-live="polite">
                {!relayAvailable
                  ? 'Relay de jogo não configurado'
                  : relayUnavailable
                    ? 'Relay indisponível — reconectando'
                    : roomState?.matchRunning
                      ? 'Partida conectada automaticamente'
                      : server.guestUid && !relayP2
                        ? 'P2 entrou no lobby; conectando ao relay…'
                        : !relayP2
                          ? 'P1 conectado; aguardando P2 na busca automática…'
                          : 'P1 e P2 no relay; sincronizando partida…'}
              </div>
              {isHost && (
                <div className="mt-3 flex items-center justify-end gap-2 text-xs text-[#9AA3B2]">
                  <span>Delay:</span>
                  <select
                    value={server.frameDelay}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      void onUpdateFrameDelay(val);
                      wsRef.current?.send(JSON.stringify({ type: 'room:config', frameDelay: val }));
                    }}
                    className="px-2 py-1.5 bg-[#0D0F12] border border-white/15 rounded text-white font-mono-tabular"
                  >
                    {[0, 1, 2, 3, 4, 5, 6].map((f) => (
                      <option key={f} value={f}>
                        {f}f
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          <div className="border border-white/10 bg-[#15181E] rounded-lg flex flex-col h-[310px]">
            <div className="px-4 py-3 border-b border-white/10 text-xs font-semibold text-white">
              Chat da Sala
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2 text-xs">
              {(!roomState?.chat || roomState.chat.length === 0) && (
                <p className="text-[#8E98A8] py-4 text-center">
                  Combine a partida ou envie sua ROM .nes para o P2.
                </p>
              )}
              {roomState?.chat.map((msg) => (
                <div key={msg.id} className="leading-relaxed">
                  <span className="font-semibold text-[#F59E0B]">{msg.gamertag}: </span>
                  <span className="text-[#E5E7EB] break-words">{msg.text}</span>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <form onSubmit={sendChat} className="p-2.5 border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                value={chatText}
                onChange={(e) => setChatText(e.target.value)}
                maxLength={240}
                disabled={!wsConnected}
                placeholder={wsConnected ? 'Enviar mensagem na sala...' : 'Chat indisponível sem relay de jogo'}
                className="flex-1 px-3 py-1.5 text-xs bg-[#0D0F12] border border-white/10 focus:border-[#EA580C] focus:outline-none rounded text-white disabled:opacity-50"
              />
              <button
                type="submit"
                aria-label="Enviar mensagem"
                disabled={!wsConnected}
                className="p-2 bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
      {showRomPicker && (
        <div className="fixed inset-0 z-[220] bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg max-h-[80vh] overflow-hidden rounded-2xl bg-[#15181E] border border-white/10 flex flex-col">
            <div className="p-4 border-b border-white/10 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-white">Escolher ROM salva</h2>
                <p className="text-xs text-[#9AA3B2] mt-1">Abre a ROM aqui sem chamar o seletor do Android nem sair da tela dividida.</p>
              </div>
              <button type="button" onClick={() => setShowRomPicker(false)} className="min-h-[40px] px-3 rounded-lg bg-[#242832] text-white">Fechar</button>
            </div>
            <div className="p-3 overflow-y-auto space-y-2">
              {savedRoms.length === 0 ? (
                <p className="p-4 text-sm text-[#CBD5E1]">Ainda não há ROMs salvas neste aparelho. Importe os jogos antes de entrar na tela dividida.</p>
              ) : savedRoms.map((rom) => (
                <button key={rom.romId} type="button" disabled={choosingRomId !== null} onClick={() => void chooseSavedRom(rom)} className="w-full min-h-[52px] px-3 py-2 text-left rounded-xl bg-[#0D0F12] border border-white/10 disabled:opacity-50">
                  <span className="block text-sm font-semibold text-white truncate">{rom.title}</span>
                  <span className="block text-xs text-[#9AA3B2] truncate">{rom.fileName} · {rom.systemId}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
