import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'Erro inesperado na aplicação.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0D0F12] text-[#F1F3F5] flex items-center justify-center p-6">
          <div className="max-w-lg w-full border border-white/10 bg-[#15181E] rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold text-white">Algo deu errado</h2>
            <p className="text-sm text-[#9AA3B2] break-words">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 text-sm font-medium bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-md transition-colors cursor-pointer"
            >
              Recarregar Aplicação
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
