import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Disc, SlidersHorizontal } from 'lucide-react';
import { getControllerProfile } from '../emulator/controllerProfiles';
import { INPUT_BITS, SystemId } from '../types/retrolink';

interface AndroidTouchPadProps {
  systemId?: SystemId;
  gameTitle?: string;
  onMaskChange: (touchMask: number) => void;
  compactLandscape?: boolean;
}

export function AndroidTouchPad({
  systemId,
  gameTitle,
  onMaskChange,
  compactLandscape = false,
}: AndroidTouchPadProps) {
  const buttonPointersRef = useRef<Map<number, number>>(new Map());
  const stickPointerIdRef = useRef<number | null>(null);
  const touchStickIdRef = useRef<number | null>(null);
  const stickMaskRef = useRef<number>(0);
  const stickBaseRef = useRef<HTMLDivElement | null>(null);
  const touchRootRef = useRef<HTMLDivElement | null>(null);
  const onMaskChangeRef = useRef(onMaskChange);
  onMaskChangeRef.current = onMaskChange;

  const [visualMask, setVisualMask] = useState(0);
  const [stickOffset, setStickOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [useDpadInstead, setUseDpadInstead] = useState(false);
  const [forceFullLayout, setForceFullLayout] = useState(false);

  const profile = useMemo(
    () => getControllerProfile(systemId, gameTitle, forceFullLayout),
    [systemId, gameTitle, forceFullLayout]
  );

  const syncMask = () => {
    let combined = stickMaskRef.current;
    for (const bit of buttonPointersRef.current.values()) {
      combined |= bit;
    }
    setVisualMask(combined);
    onMaskChangeRef.current(combined);
  };

  const handleBtnDown = (bit: number) => (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerType === 'touch') return; // Touch is handled by the non-passive native fallback below.
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore if capture unsupported
    }
    buttonPointersRef.current.set(e.pointerId, bit);
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(8);
    }
    syncMask();
  };

  const handleBtnUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerType === 'touch') return;
    e.preventDefault();
    buttonPointersRef.current.delete(e.pointerId);
    syncMask();
  };

  // Android 6's old System WebView may not implement Pointer Events. Keep a
  // real multi-touch path so buttons can be held, not merely clicked.
  // React pointer events are not consistently implemented by Android 6 WebView.
  // Touch is dispatched natively from the pad root (passive:false) so the old
  // Chromium engine cannot convert the gesture into page scroll/click instead.
  const touchButtonHandlers = (bit: number) => ({ 'data-touch-bit': String(bit) });

  const updateStickFromPointer = (clientX: number, clientY: number) => {
    const base = stickBaseRef.current;
    if (!base) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = rect.width * 0.34;

    const rawDx = clientX - cx;
    const rawDy = clientY - cy;
    const dist = Math.hypot(rawDx, rawDy);

    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(rawDy, rawDx);
    const dx = dist > 0 ? Math.cos(angle) * clampedDist : 0;
    const dy = dist > 0 ? Math.sin(angle) * clampedDist : 0;

    setStickOffset({ x: dx, y: dy });

    const deadzone = maxRadius * 0.22;
    let nextStickMask = 0;
    if (dist > deadzone) {
      // 8-way directional mapping with generous diagonal sectors
      const deg = (angle * 180) / Math.PI;
      if (deg > -67.5 && deg < 67.5) nextStickMask |= INPUT_BITS.RIGHT;
      if (deg > 112.5 || deg < -112.5) nextStickMask |= INPUT_BITS.LEFT;
      if (deg > 22.5 && deg < 157.5) nextStickMask |= INPUT_BITS.DOWN;
      if (deg < -22.5 && deg > -157.5) nextStickMask |= INPUT_BITS.UP;
    }

    if (nextStickMask !== stickMaskRef.current) {
      stickMaskRef.current = nextStickMask;
      syncMask();
    }
  };

  const handleStickDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    stickPointerIdRef.current = e.pointerId;
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(8);
    }
    updateStickFromPointer(e.clientX, e.clientY);
  };

  const handleStickMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch' || stickPointerIdRef.current !== e.pointerId) return;
    e.preventDefault();
    updateStickFromPointer(e.clientX, e.clientY);
  };

  const handleStickUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch' || stickPointerIdRef.current !== e.pointerId) return;
    e.preventDefault();
    stickPointerIdRef.current = null;
    stickMaskRef.current = 0;
    setStickOffset({ x: 0, y: 0 });
    syncMask();
  };

  useEffect(() => {
    const root = touchRootRef.current;
    if (!root) return;

    const getElement = (target: EventTarget | null): Element | null => {
      if (!target) return null;
      if (target instanceof Element) return target;
      return (target as Node).parentElement || null;
    };
    const findControl = (target: EventTarget | null, selector: string): Element | null => {
      const element = getElement(target);
      const match = element?.closest(selector) || null;
      return match && root.contains(match) ? match : null;
    };
    const touchStart = (raw: Event) => {
      const event = raw as TouchEvent;
      const stick = findControl(event.target, '[data-touch-stick="true"]');
      const button = stick ? null : findControl(event.target, '[data-touch-bit]');
      if (!stick && !button) return;
      event.preventDefault();
      if (stick && touchStickIdRef.current === null && event.changedTouches.length) {
        const touch = event.changedTouches[0];
        touchStickIdRef.current = touch.identifier;
        stickPointerIdRef.current = touch.identifier;
        if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(8);
        updateStickFromPointer(touch.clientX, touch.clientY);
        return;
      }
      if (button) {
        const bit = Number(button.getAttribute('data-touch-bit'));
        if (!Number.isFinite(bit) || bit <= 0) return;
        for (let i = 0; i < event.changedTouches.length; i += 1) {
          buttonPointersRef.current.set(-event.changedTouches[i].identifier - 1, bit);
        }
        if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(8);
        syncMask();
      }
    };
    const touchMove = (raw: Event) => {
      const event = raw as TouchEvent;
      if (touchStickIdRef.current === null) return;
      for (let i = 0; i < event.changedTouches.length; i += 1) {
        const touch = event.changedTouches[i];
        if (touch.identifier === touchStickIdRef.current) {
          event.preventDefault();
          updateStickFromPointer(touch.clientX, touch.clientY);
          return;
        }
      }
    };
    const finishTouches = (raw: Event) => {
      const event = raw as TouchEvent;
      let changed = false;
      for (let i = 0; i < event.changedTouches.length; i += 1) {
        const touch = event.changedTouches[i];
        const key = -touch.identifier - 1;
        if (buttonPointersRef.current.delete(key)) changed = true;
        if (touch.identifier === touchStickIdRef.current) {
          touchStickIdRef.current = null;
          stickPointerIdRef.current = null;
          stickMaskRef.current = 0;
          setStickOffset({ x: 0, y: 0 });
          changed = true;
        }
      }
      if (changed) {
        event.preventDefault();
        syncMask();
      }
    };

    // Deliberately use legacy listener signatures supported by Android 6's
    // System WebView, with preventDefault on controlled gestures.
    root.addEventListener('touchstart', touchStart, false);
    root.addEventListener('touchmove', touchMove, false);
    root.addEventListener('touchend', finishTouches, false);
    root.addEventListener('touchcancel', finishTouches, false);
    return () => {
      root.removeEventListener('touchstart', touchStart, false);
      root.removeEventListener('touchmove', touchMove, false);
      root.removeEventListener('touchend', finishTouches, false);
      root.removeEventListener('touchcancel', finishTouches, false);
      buttonPointersRef.current.clear();
      touchStickIdRef.current = null;
      stickPointerIdRef.current = null;
      stickMaskRef.current = 0;
      onMaskChangeRef.current(0);
    };
  }, []);

  const isPressed = (bit: number) => (visualMask & bit) !== 0;

  return (
    <div
      ref={touchRootRef}
      className={`select-none touch-none w-full ${compactLandscape ? 'retrolink-touchpad-transparent' : ''} ${
        compactLandscape
          ? 'px-3 py-2.5 bg-transparent border-0 space-y-2'
          : 'px-3 sm:px-4 py-3.5 bg-[#111318] border-t border-white/10 space-y-3'
      }`}
    >
      {/* Adaptive Controller Mode Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#9AA3B2]">
        <span className="font-mono-tabular truncate text-[#CBD5E1]">
          {profile.profileName}
        </span>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setUseDpadInstead((v) => !v)}
            className="min-h-[34px] inline-flex items-center gap-1 px-2.5 rounded-lg bg-[#1B2029] hover:bg-[#252B36] border border-white/10 text-[#E5E7EB] cursor-pointer"
          >
            <Disc className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span>{useDpadInstead ? 'Usar Joystick' : 'Joystick Ativo'}</span>
          </button>
          <button
            type="button"
            onClick={() => setForceFullLayout((v) => !v)}
            className={`min-h-[34px] inline-flex items-center gap-1 px-2.5 rounded-lg border cursor-pointer ${
              forceFullLayout
                ? 'bg-[#EA580C]/20 border-[#EA580C]/45 text-[#FDBA74]'
                : 'bg-[#1B2029] hover:bg-[#252B36] border-white/10 text-[#E5E7EB]'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{forceFullLayout ? 'Todos: Ligado' : 'Auto / Todos'}</span>
          </button>
        </div>
      </div>

      {/* Shoulder Triggers Row: L2 / L1 (Left)  &  R1 / R2 (Right) */}
      {(profile.showL1R1 || profile.showL2R2) && (
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {profile.showL2R2 && (
              <button
                type="button"
                aria-label="Botão L2"
                onPointerDown={handleBtnDown(INPUT_BITS.L2)}
                {...touchButtonHandlers(INPUT_BITS.L2)}
                onPointerUp={handleBtnUp}
                onPointerCancel={handleBtnUp}
                className={`min-h-[44px] min-w-[62px] px-3 rounded-xl border text-xs font-mono-tabular font-bold transition-transform active:scale-95 touch-none ${
                  isPressed(INPUT_BITS.L2)
                    ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                    : 'bg-[#1A1F28] border-white/15 text-[#E5E7EB]'
                }`}
              >
                {profile.labels.l2}
              </button>
            )}
            {profile.showL1R1 && (
              <button
                type="button"
                aria-label="Botão L1"
                onPointerDown={handleBtnDown(INPUT_BITS.L1)}
                {...touchButtonHandlers(INPUT_BITS.L1)}
                onPointerUp={handleBtnUp}
                onPointerCancel={handleBtnUp}
                className={`min-h-[44px] min-w-[68px] px-3 rounded-xl border text-xs font-mono-tabular font-bold transition-transform active:scale-95 touch-none ${
                  isPressed(INPUT_BITS.L1)
                    ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                    : 'bg-[#1F2530] border-white/20 text-white'
                }`}
              >
                {profile.labels.l1}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {profile.showL1R1 && (
              <button
                type="button"
                aria-label="Botão R1"
                onPointerDown={handleBtnDown(INPUT_BITS.R1)}
                {...touchButtonHandlers(INPUT_BITS.R1)}
                onPointerUp={handleBtnUp}
                onPointerCancel={handleBtnUp}
                className={`min-h-[44px] min-w-[68px] px-3 rounded-xl border text-xs font-mono-tabular font-bold transition-transform active:scale-95 touch-none ${
                  isPressed(INPUT_BITS.R1)
                    ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                    : 'bg-[#1F2530] border-white/20 text-white'
                }`}
              >
                {profile.labels.r1}
              </button>
            )}
            {profile.showL2R2 && (
              <button
                type="button"
                aria-label="Botão R2"
                onPointerDown={handleBtnDown(INPUT_BITS.R2)}
                {...touchButtonHandlers(INPUT_BITS.R2)}
                onPointerUp={handleBtnUp}
                onPointerCancel={handleBtnUp}
                className={`min-h-[44px] min-w-[62px] px-3 rounded-xl border text-xs font-mono-tabular font-bold transition-transform active:scale-95 touch-none ${
                  isPressed(INPUT_BITS.R2)
                    ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                    : 'bg-[#1A1F28] border-white/15 text-[#E5E7EB]'
                }`}
              >
                {profile.labels.r2}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Thumb Area: Left Analog Joystick + Center Select/Start (Landscape) + Right A/B/X/Y */}
      <div className="w-full flex items-center justify-between gap-2">
        {/* Left: Virtual Joystick (Default) OR D-Pad */}
        {!useDpadInstead ? (
          <div className="flex items-center justify-center shrink-0 pl-1">
            <div
              ref={stickBaseRef}
              role="application"
              aria-label="Joystick Analógico"
              onPointerDown={handleStickDown}
              onPointerMove={handleStickMove}
              onPointerUp={handleStickUp}
              onPointerCancel={handleStickUp}
              data-touch-stick="true"
              className="relative w-[136px] h-[136px] rounded-full bg-[#171B23] border-2 border-white/15 flex items-center justify-center touch-none shadow-inner"
            >
              {/* Cardinal direction markers */}
              <span
                className={`absolute top-2 text-[10px] font-bold ${
                  isPressed(INPUT_BITS.UP) ? 'text-[#EA580C]' : 'text-white/25'
                }`}
              >
                ▲
              </span>
              <span
                className={`absolute bottom-2 text-[10px] font-bold ${
                  isPressed(INPUT_BITS.DOWN) ? 'text-[#EA580C]' : 'text-white/25'
                }`}
              >
                ▼
              </span>
              <span
                className={`absolute left-2.5 text-[10px] font-bold ${
                  isPressed(INPUT_BITS.LEFT) ? 'text-[#EA580C]' : 'text-white/25'
                }`}
              >
                ◀
              </span>
              <span
                className={`absolute right-2.5 text-[10px] font-bold ${
                  isPressed(INPUT_BITS.RIGHT) ? 'text-[#EA580C]' : 'text-white/25'
                }`}
              >
                ▶
              </span>

              {/* Inner Gimbal Ring */}
              <div className="w-[74px] h-[74px] rounded-full border border-white/10 pointer-events-none" />

              {/* Movable Thumbstick Knob */}
              <div
                style={{
                  transform: `translate3d(${stickOffset.x}px, ${stickOffset.y}px, 0)`,
                }}
                className={`absolute w-[58px] h-[58px] rounded-full border-2 pointer-events-none flex items-center justify-center shadow-lg transition-[background-color,border-color] duration-75 ${
                  visualMask & (INPUT_BITS.UP | INPUT_BITS.DOWN | INPUT_BITS.LEFT | INPUT_BITS.RIGHT)
                    ? 'bg-[#EA580C] border-[#FDBA74]'
                    : 'bg-[#262C38] border-white/30'
                }`}
              >
                <div className="w-6 h-6 rounded-full border border-white/25 bg-black/20" />
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-3 grid-rows-3 gap-1 w-[136px] h-[136px] shrink-0">
            <div />
            <button
              type="button"
              aria-label="Cima"
              onPointerDown={handleBtnDown(INPUT_BITS.UP)}
                {...touchButtonHandlers(INPUT_BITS.UP)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[44px] min-w-[44px] rounded-lg border flex items-center justify-center touch-none ${
                isPressed(INPUT_BITS.UP)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#1B2029] border-white/15 text-[#E5E7EB]'
              }`}
            >
              <ArrowUp className="w-5 h-5" />
            </button>
            <div />

            <button
              type="button"
              aria-label="Esquerda"
              onPointerDown={handleBtnDown(INPUT_BITS.LEFT)}
                {...touchButtonHandlers(INPUT_BITS.LEFT)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[44px] min-w-[44px] rounded-lg border flex items-center justify-center touch-none ${
                isPressed(INPUT_BITS.LEFT)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#1B2029] border-white/15 text-[#E5E7EB]'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="rounded-lg bg-[#15181E] border border-white/5" />
            <button
              type="button"
              aria-label="Direita"
              onPointerDown={handleBtnDown(INPUT_BITS.RIGHT)}
                {...touchButtonHandlers(INPUT_BITS.RIGHT)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[44px] min-w-[44px] rounded-lg border flex items-center justify-center touch-none ${
                isPressed(INPUT_BITS.RIGHT)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#1B2029] border-white/15 text-[#E5E7EB]'
              }`}
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            <div />
            <button
              type="button"
              aria-label="Baixo"
              onPointerDown={handleBtnDown(INPUT_BITS.DOWN)}
                {...touchButtonHandlers(INPUT_BITS.DOWN)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[44px] min-w-[44px] rounded-lg border flex items-center justify-center touch-none ${
                isPressed(INPUT_BITS.DOWN)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#1B2029] border-white/15 text-[#E5E7EB]'
              }`}
            >
              <ArrowDown className="w-5 h-5" />
            </button>
            <div />
          </div>
        )}

        {/* Center Select / Start on wider screens / landscape */}
        <div className="hidden sm:flex items-center gap-2.5 self-end pb-2">
          <button
            type="button"
            onPointerDown={handleBtnDown(INPUT_BITS.SELECT)}
                {...touchButtonHandlers(INPUT_BITS.SELECT)}
            onPointerUp={handleBtnUp}
            onPointerCancel={handleBtnUp}
            className={`min-h-[44px] px-4 rounded-lg border text-[11px] font-mono-tabular font-semibold tracking-wider touch-none ${
              isPressed(INPUT_BITS.SELECT)
                ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                : 'bg-[#1B2029] border-white/15 text-[#CBD5E1]'
            }`}
          >
            {profile.labels.select}
          </button>
          <button
            type="button"
            onPointerDown={handleBtnDown(INPUT_BITS.START)}
                {...touchButtonHandlers(INPUT_BITS.START)}
            onPointerUp={handleBtnUp}
            onPointerCancel={handleBtnUp}
            className={`min-h-[44px] px-4 rounded-lg border text-[11px] font-mono-tabular font-semibold tracking-wider touch-none ${
              isPressed(INPUT_BITS.START)
                ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                : 'bg-[#1B2029] border-white/15 text-[#CBD5E1]'
            }`}
          >
            {profile.labels.start}
          </button>
        </div>

        {/* Right: Adaptive A / B / X / Y Diamond Cluster OR 2-button NES */}
        {profile.showXY ? (
          <div className="grid grid-cols-3 grid-rows-3 gap-1 w-[156px] h-[156px] shrink-0">
            <div />
            <button
              type="button"
              aria-label="Botão X"
              onPointerDown={handleBtnDown(INPUT_BITS.X)}
                {...touchButtonHandlers(INPUT_BITS.X)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[48px] min-w-[48px] rounded-full border-2 font-display text-sm font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.X)
                  ? 'bg-[#3B82F6] border-[#93C5FD] text-white'
                  : 'bg-[#1D283A] border-[#60A5FA]/50 text-[#DBEAFE]'
              }`}
            >
              {profile.labels.x}
            </button>
            <div />

            <button
              type="button"
              aria-label="Botão Y"
              onPointerDown={handleBtnDown(INPUT_BITS.Y)}
                {...touchButtonHandlers(INPUT_BITS.Y)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[48px] min-w-[48px] rounded-full border-2 font-display text-sm font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.Y)
                  ? 'bg-[#16A34A] border-[#86EFAC] text-white'
                  : 'bg-[#182B22] border-[#4ADE80]/50 text-[#DCFCE7]'
              }`}
            >
              {profile.labels.y}
            </button>
            <div />
            <button
              type="button"
              aria-label="Botão A"
              onPointerDown={handleBtnDown(INPUT_BITS.A)}
                {...touchButtonHandlers(INPUT_BITS.A)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[48px] min-w-[48px] rounded-full border-2 font-display text-sm font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.A)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#3B1E13] border-[#FB923C]/60 text-[#FFEDD5]'
              }`}
            >
              {profile.labels.a}
            </button>

            <div />
            <button
              type="button"
              aria-label="Botão B"
              onPointerDown={handleBtnDown(INPUT_BITS.B)}
                {...touchButtonHandlers(INPUT_BITS.B)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`min-h-[48px] min-w-[48px] rounded-full border-2 font-display text-sm font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.B)
                  ? 'bg-[#CA8A04] border-[#FDE047] text-white'
                  : 'bg-[#2E2614] border-[#FACC15]/55 text-[#FEF9C3]'
              }`}
            >
              {profile.labels.b}
            </button>
            <div />
          </div>
        ) : (
          <div className="flex items-center gap-3.5 shrink-0 pr-1">
            <button
              type="button"
              aria-label="Botão B"
              onPointerDown={handleBtnDown(INPUT_BITS.B)}
                {...touchButtonHandlers(INPUT_BITS.B)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`w-[60px] h-[60px] mt-5 rounded-full border-2 font-display text-lg font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.B)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#1E232D] border-white/25 text-white'
              }`}
            >
              {profile.labels.b}
            </button>

            <button
              type="button"
              aria-label="Botão A"
              onPointerDown={handleBtnDown(INPUT_BITS.A)}
                {...touchButtonHandlers(INPUT_BITS.A)}
              onPointerUp={handleBtnUp}
              onPointerCancel={handleBtnUp}
              className={`w-[60px] h-[60px] -mt-5 rounded-full border-2 font-display text-lg font-bold flex items-center justify-center transition-transform active:scale-95 touch-none ${
                isPressed(INPUT_BITS.A)
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white'
                  : 'bg-[#9A3412]/80 border-[#FB923C]/55 text-white'
              }`}
            >
              {profile.labels.a}
            </button>
          </div>
        )}
      </div>

      {/* Portrait Mobile Select / Start Row */}
      <div className="flex sm:hidden items-center justify-center gap-3 pt-0.5">
        <button
          type="button"
          onPointerDown={handleBtnDown(INPUT_BITS.SELECT)}
                {...touchButtonHandlers(INPUT_BITS.SELECT)}
          onPointerUp={handleBtnUp}
          onPointerCancel={handleBtnUp}
          className={`min-h-[44px] flex-1 max-w-[140px] rounded-lg border text-xs font-mono-tabular font-semibold tracking-wider touch-none ${
            isPressed(INPUT_BITS.SELECT)
              ? 'bg-[#EA580C] border-[#FDBA74] text-white'
              : 'bg-[#1B2029] border-white/15 text-[#CBD5E1]'
          }`}
        >
          {profile.labels.select}
        </button>
        <button
          type="button"
          onPointerDown={handleBtnDown(INPUT_BITS.START)}
                {...touchButtonHandlers(INPUT_BITS.START)}
          onPointerUp={handleBtnUp}
          onPointerCancel={handleBtnUp}
          className={`min-h-[44px] flex-1 max-w-[140px] rounded-lg border text-xs font-mono-tabular font-semibold tracking-wider touch-none ${
            isPressed(INPUT_BITS.START)
              ? 'bg-[#EA580C] border-[#FDBA74] text-white'
              : 'bg-[#1B2029] border-white/15 text-[#CBD5E1]'
          }`}
        >
          {profile.labels.start}
        </button>
      </div>
    </div>
  );
}
