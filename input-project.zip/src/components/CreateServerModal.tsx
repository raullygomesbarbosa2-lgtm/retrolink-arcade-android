import React, { useState } from 'react';
import { X } from 'lucide-react';
import { CLASSIC_SYSTEMS, getSystemById } from '../data/catalog';
import { RegionId, SystemId, UserLocalRom } from '../types/retrolink';

interface CreateServerModalProps {
  isOpen: boolean;
  userRoms: UserLocalRom[];
  defaultRom?: UserLocalRom | null;
  defaultRegion: RegionId;
  hostGamertag: string;
  onCreate: (params: {
    name: string;
    romId: string;
    romTitle: string;
    systemId: SystemId;
    region: RegionId;
    visibility: 'public' | 'private';
    frameDelay: number;
    maxPlayers: number;
    runtimeMode: 'native_bridge' | 'web_engine';
  }) => Promise<void>;
  onClose: () => void;
}

export function CreateServerModal({
  isOpen,
  userRoms,
  defaultRom,
  defaultRegion,
  hostGamertag,
  onCreate,
  onClose,
}: CreateServerModalProps) {
  const [selectedRomId, setSelectedRomId] = useState(defaultRom?.romId || userRoms[0]?.romId || 'custom');
  const [customTitle, setCustomTitle] = useState(defaultRom?.title || '');
  const [systemId, setSystemId] = useState<SystemId>(defaultRom?.systemId || 'nes');
  const [name, setName] = useState(`Sala de ${hostGamertag}`);
  const [visibility, setVisibility] = useState<'public' | 'private'>('private');
  const [region, setRegion] = useState<RegionId>(defaultRegion);
  const [frameDelay, setFrameDelay] = useState(2);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const pickedUserRom = userRoms.find((r) => r.romId === selectedRomId);
  const effectiveSystem = pickedUserRom ? pickedUserRom.systemId : systemId;
  const effectiveTitle = pickedUserRom ? pickedUserRom.title : customTitle.trim();
  const effectiveRomId = pickedUserRom
    ? pickedUserRom.romId
    : `rom_${effectiveTitle.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 32) || 'custom'}`;

  const sysInfo = getSystemById(effectiveSystem);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (name.trim().length < 3) {
      setError('Informe um nome de servidor com pelo menos 3 caracteres.');
      return;
    }
    if (effectiveTitle.length < 2) {
      setError('Selecione uma das suas ROMs ou informe o nome do arquivo da ROM.');
      return;
    }
    setSubmitting(true);
    try {
      await onCreate({
        name: name.trim(),
        romId: effectiveRomId,
        romTitle: effectiveTitle,
        systemId: effectiveSystem,
        region,
        visibility,
        frameDelay,
        maxPlayers: 2,
        runtimeMode: 'web_engine',
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Falha ao criar servidor.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#15181E] border border-white/10 rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">Criar Servidor Multiplayer</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-[#9AA3B2] hover:text-white rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label htmlFor="srv-name" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
              Nome do Servidor
            </label>
            <input
              id="srv-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={60}
              required
              placeholder="Ex: Sala Multiplayer 01"
              className="w-full px-3 py-2.5 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
            />
          </div>

          {userRoms.length > 0 && (
            <div>
              <label htmlFor="srv-user-rom" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Escolher ROM Adicionada
              </label>
              <select
                id="srv-user-rom"
                value={selectedRomId}
                onChange={(e) => setSelectedRomId(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
              >
                {userRoms.map((r) => (
                  <option key={r.romId} value={r.romId}>
                    {r.title} ({getSystemById(r.systemId)?.shortName} · {r.fileName})
                  </option>
                ))}
                <option value="custom">Informar outra ROM manualmente...</option>
              </select>
            </div>
          )}

          {(!pickedUserRom || selectedRomId === 'custom') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="srv-custom-rom" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                  Nome da ROM / Jogo
                </label>
                <input
                  id="srv-custom-rom"
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  maxLength={80}
                  required
                  placeholder="Ex: Super Mario World ou kof98.zip"
                  className="w-full px-3 py-2.5 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
                />
              </div>
              <div>
                <label htmlFor="srv-sys" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                  Sistema (Sem PlayStation)
                </label>
                <select
                  id="srv-sys"
                  value={systemId}
                  onChange={(e) => setSystemId(e.target.value as SystemId)}
                  className="w-full px-3 py-2.5 text-sm bg-[#0D0F12] border border-white/15 focus:border-[#EA580C] focus:outline-none rounded-xl text-white"
                >
                  {CLASSIC_SYSTEMS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <p className="text-xs text-[#9AA3B2] font-mono-tabular">
            Núcleo: {sysInfo?.nativeCore} · Extensões: {sysInfo?.extensions.join(', ')}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Acesso do Servidor
              </label>
              <div className="grid grid-cols-2 gap-1 p-1 bg-[#0D0F12] border border-white/10 rounded-xl">
                <button
                  type="button"
                  onClick={() => setVisibility('private')}
                  className={`min-h-[40px] px-2 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    visibility === 'private' ? 'bg-[#EA580C] text-white' : 'text-[#9AA3B2] hover:text-white'
                  }`}
                >
                  Por Código
                </button>
                <button
                  type="button"
                  onClick={() => setVisibility('public')}
                  className={`min-h-[40px] px-2 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    visibility === 'public' ? 'bg-[#EA580C] text-white' : 'text-[#9AA3B2] hover:text-white'
                  }`}
                >
                  Público
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="srv-region" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
                Região
              </label>
              <select
                id="srv-region"
                value={region}
                onChange={(e) => setRegion(e.target.value as RegionId)}
                className="w-full px-3 py-2.5 text-sm bg-[#0D0F12] border border-white/15 rounded-xl text-white focus:border-[#EA580C] focus:outline-none"
              >
                <option value="BR-SP">Brasil (São Paulo)</option>
                <option value="SA-EAST">América do Sul</option>
                <option value="NA-EAST">América do Norte</option>
                <option value="EU-WEST">Europa</option>
                <option value="JP-TOKYO">Japão</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="srv-delay" className="block text-xs font-medium text-[#E5E7EB] mb-1.5">
              Buffer Netplay (Frames: {frameDelay}f)
            </label>
            <input
              id="srv-delay"
              type="range"
              min={0}
              max={6}
              value={frameDelay}
              onChange={(e) => setFrameDelay(Number(e.target.value))}
              className="w-full accent-[#EA580C]"
            />
          </div>

          {error && <p className="text-xs text-[#FCA5A5]">{error}</p>}

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#9AA3B2] hover:text-white rounded-md cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] disabled:opacity-50 text-white rounded-md transition-colors cursor-pointer"
            >
              {submitting ? 'Gerando Código...' : 'Criar Servidor e Gerar Acesso'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
