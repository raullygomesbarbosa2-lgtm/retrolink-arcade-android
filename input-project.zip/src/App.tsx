import React, { useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import {
  Download,
  FolderOpen,
  FolderPlus,
  Gamepad2,
  Play,
  Plus,
  Search,
  Server,
  Trash2,
  Upload,
  User as UserIcon,
} from 'lucide-react';
import { auth } from './firebase';
import { CLASSIC_SYSTEMS, getSystemById } from './data/catalog';
import {
  createGameServer,
  deleteUserLocalRomMetadata,
  joinServerById,
  leaveOrCloseServer,
  loadOrCreateUserAccount,
  saveUserLocalRomMetadata,
  subscribeToAccessibleServers,
  subscribeToServerDoc,
  subscribeToUserLocalRoms,
  updateServerSettings,
  updateUserPublicProfile,
} from './services/firestoreService';
import {
  GameServer,
  ParsedRomInfo,
  RegionId,
  SystemId,
  UserLocalRom,
  UserPublicProfile,
} from './types/retrolink';
import {
  hasPlayStationExtension,
  isIgnorableHelperFile,
  parseRomFile,
  parseRomFiles,
} from './utils/romParser';
import { deleteRomBinary, loadRomBinary, saveRomBinary } from './utils/romStorage';
import { usePWAInstall } from './hooks/usePWAInstall';
import { AccountModal } from './components/AccountModal';
import { AuthGate } from './components/AuthGate';
import { BiosArchiveFile, EmulatorViewport } from './components/EmulatorViewport';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MultiplayerRoomPanel } from './components/MultiplayerRoomPanel';

type MobileTab = 'roms' | 'play' | 'servers';

function RetroLinkApp() {
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserPublicProfile | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const [servers, setServers] = useState<GameServer[]>([]);
  const [activeServerId, setActiveServerId] = useState<string | null>(null);
  const [activeServer, setActiveServer] = useState<GameServer | null>(null);
  const [userLocalRoms, setUserLocalRoms] = useState<UserLocalRom[]>([]);

  const [activeRom, setActiveRom] = useState<ParsedRomInfo | null>(null);
  const [activeRomBytes, setActiveRomBytes] = useState<Uint8Array | null>(null);
  const [neogeoBiosBytes, setNeogeoBiosBytes] = useState<Uint8Array | null>(null);
  const [arcadeBiosFiles, setArcadeBiosFiles] = useState<BiosArchiveFile[]>([]);
  const [mobileTab, setMobileTab] = useState<MobileTab>('play');

  const [romFilterSystem, setRomFilterSystem] = useState<'all' | SystemId>('all');
  const [romSearch, setRomSearch] = useState('');
  const [importProgress, setImportProgress] = useState<{ processed: number; total: number } | null>(null);

  const [autoMatchmaking, setAutoMatchmaking] = useState(false);
  const autoMatchBusyRef = useRef(false);
  const autoMatchTriedRef = useRef(new Set<string>());
  const autoRoomCreatingRef = useRef(false);
  const [autoMatchRoomId, setAutoMatchRoomId] = useState<string | null>(null);
  const [autoMatchRetryTick, setAutoMatchRetryTick] = useState(0);
  const [feedbackMsg, setFeedbackMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [showIOSInstallTip, setShowIOSInstallTip] = useState(false);

  const [accountModalOpen, setAccountModalOpen] = useState(false);

  const soloRemoteRef = useRef<{ p1: number; p2: number }>({ p1: 0, p2: 0 });
  const romInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const pendingRegistrationRef = useRef<{ gamertag: string; region: RegionId } | null>(null);

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          const pending = pendingRegistrationRef.current;
          pendingRegistrationRef.current = null;
          const loaded = await loadOrCreateUserAccount(user, pending || undefined);
          setProfile(loaded);
        } catch (err) {
          setAuthError(err instanceof Error ? err.message : 'Erro ao carregar perfil.');
        }
      } else {
        setProfile(null);
        setServers([]);
        setActiveServerId(null);
        setActiveServer(null);
        setUserLocalRoms([]);
        setActiveRom(null);
        setActiveRomBytes(null);
        setNeogeoBiosBytes(null);
        setArcadeBiosFiles([]);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!firebaseUser) return;
    const BIOS_FILES = new Set([
      'neogeo.zip',
      'pgm.zip',
      'skns.zip',
      'isgsm.zip',
      'qsound.zip',
      'decocass.zip',
      'playch10.zip',
      'megatech.zip',
      'neocdz.zip',
    ]);
    const unsubServers = subscribeToAccessibleServers(firebaseUser.uid, (list) => {
      setServers(list);
    });
    const unsubRoms = subscribeToUserLocalRoms(firebaseUser.uid, (roms) => {
      setUserLocalRoms(roms);
      const biosList = roms.filter((r) => BIOS_FILES.has(r.fileName.toLowerCase()));
      if (biosList.length > 0) {
        void Promise.all(
          biosList.map(async (b) => {
            const bytes = await loadRomBinary(firebaseUser.uid, b.romId);
            return bytes ? { fileName: b.fileName, bytes } : null;
          })
        ).then((loaded) => {
          const valid = loaded.filter((item): item is BiosArchiveFile => item !== null);
          setArcadeBiosFiles(valid);
          const neo = valid.find((v) => v.fileName.toLowerCase() === 'neogeo.zip');
          if (neo) setNeogeoBiosBytes(neo.bytes);
        });
      } else {
        setArcadeBiosFiles([]);
        setNeogeoBiosBytes(null);
      }
    });
    return () => {
      unsubServers();
      unsubRoms();
    };
  }, [firebaseUser?.uid]);

  useEffect(() => {
    if (!firebaseUser || !activeServerId) {
      setActiveServer(null);
      return;
    }
    const unsub = subscribeToServerDoc(activeServerId, (srv) => {
      setActiveServer(srv);
      if (!srv) {
        setActiveServerId(null);
      }
    });
    return () => unsub();
  }, [firebaseUser?.uid, activeServerId]);

  const handleSignOut = async () => {
    if (activeServer && firebaseUser) {
      try {
        await leaveOrCloseServer(activeServer, firebaseUser.uid);
      } catch {
        // ignore cleanup
      }
    }
    await signOut(auth);
    setAccountModalOpen(false);
  };

  const handleSaveAccount = async (data: {
    gamertag: string;
    region: RegionId;
    favoriteSystem: string;
  }) => {
    if (!firebaseUser) return;
    await updateUserPublicProfile(firebaseUser.uid, {
      ...data,
      photoURL: '',
    });
    setProfile((prev) => (prev ? { ...prev, ...data } : prev));
    setFeedbackMsg({ kind: 'ok', text: 'Conta e região atualizadas.' });
  };

  const saveSingleParsedRom = async (info: ParsedRomInfo, rawBytes: Uint8Array) => {
    if (!firebaseUser) return;
    const bytesToStore = info.effectiveBytes || rawBytes;
    if (info.isBios) {
      if (info.fileName.toLowerCase() === 'neogeo.zip') {
        setNeogeoBiosBytes(bytesToStore);
      }
      setArcadeBiosFiles((prev) => {
        const filtered = prev.filter((b) => b.fileName.toLowerCase() !== info.fileName.toLowerCase());
        return [...filtered, { fileName: info.fileName, bytes: bytesToStore }];
      });
    }

    await saveRomBinary(firebaseUser.uid, info.romId, bytesToStore);
    await saveUserLocalRomMetadata(firebaseUser.uid, {
      romId: info.romId,
      title: info.title,
      fileName: info.fileName,
      systemId: info.systemId,
      crc32: info.crc32,
      sizeBytes: info.sizeBytes,
    });
  };

  const handleRomLoaded = async (info: ParsedRomInfo, bytes: Uint8Array) => {
    if (!firebaseUser) return;

    if (!info.isBios) {
      setActiveRom(info);
      setActiveRomBytes(bytes);
    }

    try {
      await saveSingleParsedRom(info, bytes);
      setFeedbackMsg({
        kind: 'ok',
        text: info.isBios
          ? `BIOS Arcade (${info.fileName}) salva!`
          : `Jogo identificado: ${info.title} (${getSystemById(info.systemId)?.shortName || info.systemId}).`,
      });
      if (!activeServer && !info.isBios) {
        setMobileTab('play');
        scrollToSection('emulador');
      }
    } catch (err) {
      setFeedbackMsg({
        kind: 'err',
        text: err instanceof Error ? err.message : 'Erro ao salvar ROM na conta.',
      });
    }
  };

  const processSelectedFiles = async (files: FileList | File[]) => {
    if (!firebaseUser || files.length === 0) return;
    setFeedbackMsg(null);

    const fileArray = Array.from(files);
    const total = fileArray.length;
    const isBatch = total > 1;
    if (isBatch) {
      setImportProgress({ processed: 0, total });
    }

    let addedPlayableCount = 0;
    let addedBiosCount = 0;
    let skippedHelpersCount = 0;
    let rejectedPsCount = 0;
    const failedNames: string[] = [];
    const systemBreakdown = new Map<string, number>();
    let firstPlayable: { info: ParsedRomInfo; bytes: Uint8Array } | null = null;
    let singleParsedCount = 0;

    for (let i = 0; i < fileArray.length; i++) {
      const file = fileArray[i];
      if (isBatch) {
        setImportProgress({ processed: i + 1, total });
      }

      if (hasPlayStationExtension(file.name)) {
        rejectedPsCount += 1;
        continue;
      }

      if (isBatch && isIgnorableHelperFile(file.name)) {
        skippedHelpersCount += 1;
        continue;
      }

      try {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        const parsedList = parseRomFiles(file.name, bytes);
        singleParsedCount += parsedList.length;

        for (const parsed of parsedList) {
          const romBytes = parsed.effectiveBytes || bytes;
          await saveSingleParsedRom(parsed, romBytes);
          if (parsed.isBios) {
            addedBiosCount += 1;
          } else {
            addedPlayableCount += 1;
            const sysShort = getSystemById(parsed.systemId)?.shortName || parsed.systemId.toUpperCase();
            systemBreakdown.set(sysShort, (systemBreakdown.get(sysShort) || 0) + 1);
            if (!firstPlayable) {
              firstPlayable = { info: parsed, bytes: romBytes };
            }
          }
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : '';
        if (msg.includes('PlayStation')) {
          rejectedPsCount += 1;
        } else if (!isBatch) {
          setImportProgress(null);
          setFeedbackMsg({
            kind: 'err',
            text: msg || `Falha ao ler ${file.name}.`,
          });
          return;
        } else {
          failedNames.push(file.name);
        }
      }
    }

    setImportProgress(null);

    if (!isBatch && singleParsedCount === 1 && firstPlayable) {
      setActiveRom(firstPlayable.info);
      setActiveRomBytes(firstPlayable.bytes);
      setFeedbackMsg({
        kind: 'ok',
        text: `Jogo carregado: ${firstPlayable.info.title} (${
          getSystemById(firstPlayable.info.systemId)?.shortName || firstPlayable.info.systemId
        }).`,
      });
      if (!activeServer) {
        setMobileTab('play');
        scrollToSection('emulador');
      }
      return;
    }

    if (!isBatch && singleParsedCount === 1 && addedBiosCount === 1) {
      setFeedbackMsg({
        kind: 'ok',
        text: 'BIOS salva e pronta para uso! Agora selecione um jogo para rodar.',
      });
      return;
    }

    if (firstPlayable && !activeRom) {
      setActiveRom(firstPlayable.info);
      setActiveRomBytes(firstPlayable.bytes);
    }

    const totalAdded = addedPlayableCount + addedBiosCount;
    if (totalAdded > 0) {
      const breakdownText = Array.from(systemBreakdown.entries())
        .map(([sys, count]) => `${sys}: ${count}`)
        .join(', ');
      const extras: string[] = [];
      if (addedBiosCount > 0) extras.push(`${addedBiosCount} BIOS`);
      if (rejectedPsCount > 0) extras.push(`${rejectedPsCount} PlayStation ignorado(s)`);
      if (skippedHelpersCount > 0) extras.push(`${skippedHelpersCount} arquivo(s) auxiliar(es)`);
      if (failedNames.length > 0) extras.push(`${failedNames.length} não reconhecido(s)`);

      setFeedbackMsg({
        kind: 'ok',
        text: `${addedPlayableCount} jogo(s) adicionado(s)${breakdownText ? ` (${breakdownText})` : ''}.${
          extras.length > 0 ? ` [${extras.join(' · ')}]` : ''
        }`,
      });
      if (!activeServer && mobileTab !== 'roms') {
        setMobileTab('roms');
        scrollToSection('roms');
      }
    } else if (rejectedPsCount > 0) {
      setFeedbackMsg({
        kind: 'err',
        text: 'Arquivos de PlayStation (.iso/.cue/.pbp/.chd) não são suportados.',
      });
    } else {
      setFeedbackMsg({
        kind: 'err',
        text: 'Nenhuma ROM clássica reconhecida nos arquivos selecionados.',
      });
    }
  };

  const handleUploadInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    await processSelectedFiles(files);
    e.target.value = '';
  };

  const handleSelectSavedRom = async (saved: UserLocalRom): Promise<boolean> => {
    if (!firebaseUser) return false;
    const bytes = await loadRomBinary(firebaseUser.uid, saved.romId);
    if (!bytes) {
      setFeedbackMsg({
        kind: 'err',
        text: `O arquivo "${saved.fileName}" não está salvo neste aparelho. Toque em Selecionar ROMs para carregá-lo novamente.`,
      });
      return false;
    }
    try {
      const parsed = parseRomFile(saved.fileName, bytes);
      if (parsed.isBios) {
        if (saved.fileName.toLowerCase() === 'neogeo.zip') {
          setNeogeoBiosBytes(bytes);
        }
        setArcadeBiosFiles((prev) => {
          const filtered = prev.filter((b) => b.fileName.toLowerCase() !== saved.fileName.toLowerCase());
          return [...filtered, { fileName: saved.fileName, bytes }];
        });
        setFeedbackMsg({
          kind: 'ok',
          text: `BIOS ${saved.fileName} pronta. Selecione um jogo de Arcade/Neo Geo para iniciar.`,
        });
        return false;
      }
      setActiveRom(parsed);
      setActiveRomBytes(bytes);
      setMobileTab(activeServer ? 'servers' : 'play');
      scrollToSection(activeServer ? 'servidores' : 'emulador');
      return true;
    } catch (err) {
      setFeedbackMsg({
        kind: 'err',
        text: err instanceof Error ? err.message : `Não foi possível abrir "${saved.fileName}".`,
      });
      return false;
    }
  };

  const handleSearchWithRom = async (rom: UserLocalRom) => {
    const loaded = await handleSelectSavedRom(rom);
    if (!loaded) return;
    autoMatchTriedRef.current.clear();
    setAutoMatchRoomId(null);
    setAutoMatchmaking(true);
    setMobileTab('servers');
    setFeedbackMsg({ kind: 'ok', text: `Buscando automaticamente outro jogador com a mesma ROM: ${rom.title}.` });
  };

  const handleRemoveSavedRom = async (saved: UserLocalRom) => {
    if (!firebaseUser) return;
    await deleteRomBinary(firebaseUser.uid, saved.romId);
    await deleteUserLocalRomMetadata(firebaseUser.uid, saved.romId);
    if (activeRom?.romId === saved.romId) {
      setActiveRom(null);
      setActiveRomBytes(null);
    }
  };

  useEffect(() => {
    if (!autoMatchmaking) return;
    const timer = window.setInterval(() => setAutoMatchRetryTick((tick) => tick + 1), 3500);
    return () => window.clearInterval(timer);
  }, [autoMatchmaking]);

  // Both players stay in the matchmaking screen until Firestore confirms a pair.
  // A waiting room is only a queue entry; it does not enter the game alone.
  useEffect(() => {
    if (!autoMatchmaking || !firebaseUser || !profile || activeServerId || autoMatchBusyRef.current || autoRoomCreatingRef.current) return;
    const matchTitle = activeRom?.title || userLocalRoms[0]?.title;
    const matchSystem = activeRom?.systemId || userLocalRoms[0]?.systemId;
    const matchRomId = activeRom?.romId || userLocalRoms[0]?.romId;
    if (!matchTitle || !matchSystem || !matchRomId) return;

    const ownQueueRoom = autoMatchRoomId ? servers.find((srv) => srv.serverId === autoMatchRoomId) : null;
    if (autoMatchRoomId && !ownQueueRoom) return; // Wait for Firestore's queue snapshot before creating/retrying.
    if (ownQueueRoom?.guestUid) {
      setActiveServerId(ownQueueRoom.serverId);
      setAutoMatchmaking(false);
      setMobileTab('servers');
      setFeedbackMsg({ kind: 'ok', text: 'P1 e P2 encontrados. Entrando juntos no multiplayer…' });
      return;
    }

    const candidates = servers.filter((srv) =>
      srv.visibility === 'public' && srv.status !== 'closed' && !srv.guestUid &&
      srv.hostUid !== firebaseUser.uid &&
      srv.systemId === matchSystem && srv.romId === matchRomId
    ).sort((a, b) => a.serverId.localeCompare(b.serverId));

    autoMatchBusyRef.current = true;
    void (async () => {
      try {
        for (const candidate of candidates) {
          autoMatchTriedRef.current.add(candidate.serverId);
          try {
            // Claim the candidate first. Never delete our own P1 queue before a successful join,
            // or a transient Firestore/network failure can strand the player outside the queue.
            await joinServerById(candidate.serverId, firebaseUser.uid, profile.gamertag);
            if (autoMatchRoomId) {
              const currentQueue = servers.find((srv) => srv.serverId === autoMatchRoomId);
              if (currentQueue?.hostUid === firebaseUser.uid) {
                void leaveOrCloseServer(currentQueue, firebaseUser.uid).catch(() => undefined);
              }
            }
            setAutoMatchRoomId(candidate.serverId);
            return; // Wait until listener confirms P1+P2, then transition both together.
          } catch {
            // Keep the P1 queue intact if another player claimed the candidate or network failed.
          }
        }

        if (autoMatchRoomId) return; // Already queued as P1; stay here and wait for a P2.

        const equivalentOpenRoom = servers.some((srv) =>
          srv.visibility === 'public' && srv.status !== 'closed' && !srv.guestUid && srv.hostUid !== firebaseUser.uid &&
          srv.systemId === matchSystem && srv.romId === matchRomId
        );
        if (equivalentOpenRoom) return; // Snapshot is about to update; do not create duplicate rooms.

        autoRoomCreatingRef.current = true;
        const queueRoom = await createGameServer({
          name: `Busca ${profile.gamertag}`,
          hostUid: firebaseUser.uid,
          hostGamertag: profile.gamertag,
          romId: activeRom?.romId || userLocalRoms[0]?.romId || 'auto_match',
          romTitle: matchTitle,
          systemId: matchSystem,
          region: profile.region,
          visibility: 'public',
          frameDelay: 2,
          maxPlayers: 2,
          runtimeMode: 'web_engine',
        });
        setAutoMatchRoomId(queueRoom.serverId);
        // Stay on the common searching screen as P1; do not enter multiplayer alone.
      } catch (err) {
        setFeedbackMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Não foi possível iniciar a busca automática.' });
        setAutoMatchmaking(false);
      } finally {
        autoRoomCreatingRef.current = false;
        autoMatchBusyRef.current = false;
      }
    })();
  }, [autoMatchmaking, autoMatchRetryTick, autoMatchRoomId, servers, firebaseUser?.uid, profile?.uid, activeServerId, activeRom?.romId, activeRom?.systemId, activeRom?.title, userLocalRoms]);

  const handleLeaveOrClose = async () => {
    if (!activeServer || !firebaseUser) return;
    await leaveOrCloseServer(activeServer, firebaseUser.uid);
    setActiveServerId(null);
    setActiveServer(null);
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const showSection = (tab: MobileTab) => (mobileTab === tab ? 'block' : 'hidden md:block');

  return (
    <div className="min-h-screen bg-[#0D0F12] text-[#F1F3F5] flex flex-col">
      {/* Compact Sticky Mobile/Desktop Header (56px height) */}
      <header className="sticky top-0 z-40 h-14 bg-[#0D0F12]/95 backdrop-blur-md border-b border-white/10">
        <div className="max-w-[1380px] h-full mx-auto px-4 sm:px-6 flex items-center justify-between gap-4 sm:gap-8">
          <a
            href="#topo"
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            RetroLink
          </a>

          {firebaseUser && (
            <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#A1AAB8]">
              <button
                type="button"
                onClick={() => scrollToSection('emulador')}
                className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Jogar Solo
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('roms')}
                className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Minhas ROMs
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('servidores')}
                className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Servidores
              </button>
            </nav>
          )}

          <div className="flex items-center gap-2 shrink-0">
            {!isInstalled && isInstallable && (
              <button
                type="button"
                onClick={() => void install()}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Instalar App</span>
              </button>
            )}

            {!isInstalled && !isInstallable && isIOS && (
              <button
                type="button"
                onClick={() => setShowIOSInstallTip(true)}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3 text-xs font-medium bg-[#1C2028] text-white border border-white/15 rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
              >
                Instalar App
              </button>
            )}

            {!authReady ? (
              <span className="text-xs text-[#9AA3B2] whitespace-nowrap">Carregando...</span>
            ) : firebaseUser && profile ? (
              <button
                type="button"
                onClick={() => setAccountModalOpen(true)}
                className="min-h-[44px] inline-flex items-center gap-2 px-3.5 text-xs font-semibold bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <UserIcon className="w-4 h-4 text-[#F59E0B]" />
                <span className="max-w-[110px] truncate">{profile.gamertag}</span>
              </button>
            ) : (
              <span className="text-xs font-medium text-[#F59E0B] whitespace-nowrap">
                Conta Obrigatória
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Mandatory Auth Gate */}
      {!authReady ? (
        <main className="flex-1 flex items-center justify-center p-12 text-sm text-[#9AA3B2]">
          Verificando sessão...
        </main>
      ) : !firebaseUser ? (
        <main className="flex-1">
          <AuthGate
            onPrepareRegistration={(data) => {
              pendingRegistrationRef.current = data;
            }}
            onAuthenticated={(loadedProfile) => setProfile(loadedProfile)}
          />
        </main>
      ) : (
        <main id="topo" className="flex-1 max-w-[1380px] w-full mx-auto px-4 sm:px-6 pt-5 pb-24 md:py-10 space-y-8 md:space-y-12">
          <input
            ref={romInputRef}
            type="file"
            multiple
            onChange={(e) => void handleUploadInputChange(e)}
            className="hidden"
          />
          <input
            ref={folderInputRef}
            type="file"
            multiple
            {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
            onChange={(e) => void handleUploadInputChange(e)}
            className="hidden"
          />

          {(authError || feedbackMsg) && (
            <div
              className={`px-4 py-3 rounded-xl border text-xs flex items-center justify-between gap-4 ${
                authError || feedbackMsg?.kind === 'err'
                  ? 'bg-[#2A1618] border-[#EF4444]/40 text-[#FCA5A5]'
                  : 'bg-[#14261B] border-[#22C55E]/35 text-[#86EFAC]'
              }`}
            >
              <span>{authError || feedbackMsg?.text}</span>
              <button
                type="button"
                onClick={() => {
                  setAuthError(null);
                  setFeedbackMsg(null);
                }}
                className="min-h-[40px] px-2 text-white/70 hover:text-white shrink-0 cursor-pointer"
              >
                Fechar
              </button>
            </div>
          )}

          {importProgress && (
            <div className="px-4 py-3 rounded-xl border border-[#EA580C]/40 bg-[#1B1410] text-xs text-[#FDBA74] flex items-center justify-between gap-4">
              <span>
                Importando e lendo ROMs: {importProgress.processed} de {importProgress.total} arquivo(s)...
              </span>
              <span className="font-mono-tabular">
                {Math.round((importProgress.processed / Math.max(1, importProgress.total)) * 100)}%
              </span>
            </div>
          )}

          {/* Tab 1 / Section: Direct Emulator Player */}
          {!activeServer && (
            <section id="emulador" className={`${showSection('play')} space-y-4`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold text-white">Emulador Android — Modo Solo</h1>
                  <p className="text-xs text-[#9AA3B2] mt-0.5">
                    Selecione 1 ou todas as suas ROMs (Arcade, Super Nintendo, Mega Drive, NES, GBA e outros) para jogar direto na tela.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => romInputRef.current?.click()}
                    className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    Abrir ROM(s)
                  </button>
                  <button
                    type="button"
                    onClick={() => setMobileTab('servers')}
                    className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-medium bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    Buscar partida
                  </button>
                </div>
              </div>

              <EmulatorViewport
                activeRom={activeRom}
                activeRomBytes={activeRomBytes}
                neogeoBiosBytes={neogeoBiosBytes}
                arcadeBiosFiles={arcadeBiosFiles}
                playerSlot="SOLO"
                isNetplayActive={false}
                frameDelay={0}
                remoteInputRef={soloRemoteRef}
                onRomFileLoaded={(info, bytes) => void handleRomLoaded(info, bytes)}
                onRomFilesSelected={(files) => void processSelectedFiles(files)}
              />
            </section>
          )}

          {/* Tab 2 / Section: User ROMs Library (Auto-Detected Games) */}
          <section
            id="roms"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                void processSelectedFiles(e.dataTransfer.files);
              }
            }}
            className={`${showSection('roms')} border border-white/10 bg-[#15181E] rounded-2xl p-5 sm:p-6 space-y-5`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <FolderOpen className="w-5 h-5 text-[#EA580C]" />
                  Seus Jogos (ROMs Lidas) · {userLocalRoms.length}
                </h2>
                <p className="text-xs text-[#9AA3B2] mt-1">
                  Sistemas clássicos compatíveis: {CLASSIC_SYSTEMS.map((s) => s.shortName).join(' · ')} (sem PlayStation).
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => romInputRef.current?.click()}
                  className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  Selecionar ROMs (Várias)
                </button>
                <button
                  type="button"
                  onClick={() => folderInputRef.current?.click()}
                  className="min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 text-xs font-medium bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderPlus className="w-4 h-4 text-[#F59E0B]" />
                  Importar Pasta Inteira
                </button>
              </div>
            </div>

            {userLocalRoms.length > 0 && (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-[#9AA3B2] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={romSearch}
                    onChange={(e) => setRomSearch(e.target.value)}
                    placeholder="Buscar jogo ou arquivo pelo nome..."
                    className="min-h-[44px] w-full pl-10 pr-4 text-xs bg-[#0D0F12] border border-white/10 focus:border-[#EA580C] focus:outline-none rounded-xl text-white placeholder:text-[#7E8796]"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRomFilterSystem('all')}
                    className={`min-h-[36px] px-3 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      romFilterSystem === 'all'
                        ? 'bg-[#EA580C] text-white'
                        : 'bg-[#0D0F12] text-[#A1AAB8] border border-white/10 hover:text-white'
                    }`}
                  >
                    Todas ({userLocalRoms.length})
                  </button>
                  {CLASSIC_SYSTEMS.map((sys) => {
                    const count = userLocalRoms.filter((r) => r.systemId === sys.id).length;
                    if (count === 0) return null;
                    return (
                      <button
                        key={sys.id}
                        type="button"
                        onClick={() => setRomFilterSystem(sys.id)}
                        className={`min-h-[36px] px-3 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                          romFilterSystem === sys.id
                            ? 'bg-[#EA580C] text-white'
                            : 'bg-[#0D0F12] text-[#A1AAB8] border border-white/10 hover:text-white'
                        }`}
                      >
                        {sys.shortName} ({count})
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {userLocalRoms.length === 0 ? (
              <div className="py-10 px-4 text-center space-y-3 border border-dashed border-white/15 rounded-xl bg-[#0D0F12]/50">
                <p className="text-sm text-[#A1AAB8]">
                  Nenhum jogo adicionado ainda. Selecione uma ou várias ROMs (ou importe sua pasta inteira de Arcade, SNES, Mega Drive, NES, GBA) para todos aparecerem aqui.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => romInputRef.current?.click()}
                    className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-semibold bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    Selecionar ROMs em Geral
                  </button>
                  <button
                    type="button"
                    onClick={() => folderInputRef.current?.click()}
                    className="min-h-[44px] inline-flex items-center gap-1.5 px-4 text-xs font-medium bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl cursor-pointer"
                  >
                    <FolderPlus className="w-4 h-4 text-[#F59E0B]" />
                    Selecionar Pasta Completa
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userLocalRoms
                  .filter((rom) => {
                    if (romFilterSystem !== 'all' && rom.systemId !== romFilterSystem) return false;
                    const q = romSearch.trim().toLowerCase();
                    if (!q) return true;
                    return (
                      rom.title.toLowerCase().includes(q) || rom.fileName.toLowerCase().includes(q)
                    );
                  })
                  .sort((a, b) => a.title.localeCompare(b.title))
                  .map((rom) => {
                    const sys = getSystemById(rom.systemId);
                    const isActive = activeRom?.romId === rom.romId;
                    const isBios = rom.fileName.toLowerCase() === 'neogeo.zip';
                    return (
                      <div
                        key={rom.romId}
                        className={`p-4 rounded-xl border bg-[#0D0F12] flex flex-col justify-between gap-4 ${
                          isActive ? 'border-[#EA580C]' : 'border-white/10'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="text-xs text-[#F59E0B] font-medium">
                            {isBios ? 'BIOS Neo Geo' : sys?.name || rom.systemId} ·{' '}
                            {(rom.sizeBytes / 1024).toFixed(0)} KB
                          </div>
                          <div className="text-base font-bold text-white truncate">{rom.title}</div>
                          <div className="text-xs font-mono-tabular text-[#8E98A8] truncate">
                            {rom.fileName} · CRC {rom.crc32}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                          <button
                            type="button"
                            onClick={() => void handleSelectSavedRom(rom)}
                            className="min-h-[44px] flex-1 inline-flex items-center justify-center gap-1.5 px-3 text-xs font-semibold bg-[#EA580C] hover:bg-[#DC4E07] text-white rounded-xl transition-colors cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5" />
                            {isBios ? 'Ativar BIOS' : 'Jogar Agora'}
                          </button>
                          {!isBios && (
                            <button
                              type="button"
                              onClick={() => void handleSearchWithRom(rom)}
                              className="min-h-[44px] flex-1 px-3 text-xs font-medium bg-[#1C2028] hover:bg-[#252B36] text-white border border-white/15 rounded-xl transition-colors cursor-pointer"
                            >
                              Buscar partida
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => void handleRemoveSavedRom(rom)}
                            aria-label="Remover ROM"
                            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-[#9AA3B2] hover:text-[#FCA5A5] cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </section>

          {/* Tab 3 / Section: Multiplayer Servers & Invite Code */}
          <section id="servidores" className={`${activeServer ? 'block' : showSection('servers')} space-y-5`}>
            {activeServer && profile ? (
              <MultiplayerRoomPanel
                server={activeServer}
                profile={profile}
                activeRom={activeRom}
                activeRomBytes={activeRomBytes}
                neogeoBiosBytes={neogeoBiosBytes}
                arcadeBiosFiles={arcadeBiosFiles}
                onRomFileLoaded={(info, bytes) => void handleRomLoaded(info, bytes)}
                onRomFilesSelected={(files) => void processSelectedFiles(files)}
                savedRoms={userLocalRoms}
                onChooseSavedRom={handleSelectSavedRom}
                onLeaveOrClose={handleLeaveOrClose}
                onUpdateFrameDelay={async (delay) => {
                  await updateServerSettings(activeServer.serverId, { frameDelay: delay });
                }}
              />
            ) : (
              <div className="space-y-5">
                <div className="border border-[#EA580C]/30 bg-[#201711] rounded-2xl p-5 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className={`h-3 w-3 rounded-full ${autoMatchmaking ? 'bg-[#FB923C] animate-pulse' : 'bg-[#667085]'}`} />
                    <div>
                      <h2 className="text-base font-bold text-white">Buscar jogador automaticamente</h2>
                      <p className="text-xs text-[#B7A99C]">
                        {autoMatchmaking ? 'Buscando outro jogador com a mesma ROM…' : 'Os dois jogadores tocam para entrar juntos, sem código.'}
                      </p>
                    </div>
                  </div>
                  {autoMatchmaking && (
                    <div className="h-2 overflow-hidden rounded-full bg-[#0D0F12] border border-white/10" role="progressbar" aria-label="Buscando jogador">
                      <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-[#EA580C] via-[#FDBA74] to-[#EA580C] animate-[matchscan_1.4s_ease-in-out_infinite]" />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (autoMatchmaking) {
                        const queueRoom = autoMatchRoomId ? servers.find((srv) => srv.serverId === autoMatchRoomId) : null;
                        if (queueRoom && firebaseUser) void leaveOrCloseServer(queueRoom, firebaseUser.uid);
                        setAutoMatchRoomId(null);
                        setAutoMatchmaking(false);
                        return;
                      }
                      if (!activeRom && !userLocalRoms.length) {
                        setFeedbackMsg({ kind: 'err', text: 'Adicione a mesma ROM nos dois aparelhos antes de buscar a partida.' });
                        return;
                      }
                      if (!activeRom && userLocalRoms[0]) void handleSelectSavedRom(userLocalRoms[0]);
                      autoMatchTriedRef.current.clear();
                      setAutoMatchRoomId(null);
                      setAutoMatchmaking(true);
                    }}
                    className={`min-h-[46px] w-full rounded-xl text-sm font-bold text-white transition-colors ${autoMatchmaking ? 'bg-[#363B45] hover:bg-[#454B56]' : 'bg-[#EA580C] hover:bg-[#DC4E07]'}`}
                  >
                    {autoMatchmaking ? 'Cancelar busca' : 'Buscar partida automática'}
                  </button>
                </div>
                <p className="px-2 text-center text-xs text-[#9AA3B2]">
                  Os dois escolhem a mesma ROM e tocam em buscar. Ambos ficam nesta tela e só entram juntos quando P1 e P2 forem encontrados.
                </p>
              </div>
            )}
          </section>
        </main>
      )}

      {/* Mobile Bottom Navigation Bar (Fixed Thumb-Zone, 3 clean tabs) */}
      {firebaseUser && (
        <nav
          aria-label="Navegação Mobile"
          className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 pb-safe bg-[#0D0F12]/95 backdrop-blur-md border-t border-white/10 grid grid-cols-3 items-center"
        >
          <button
            type="button"
            onClick={() => setMobileTab('play')}
            className={`h-full flex flex-col items-center justify-center gap-1 cursor-pointer ${
              mobileTab === 'play' ? 'text-[#EA580C]' : 'text-[#9AA3B2]'
            }`}
          >
            <Gamepad2 className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight">Jogar</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileTab('roms')}
            className={`h-full flex flex-col items-center justify-center gap-1 cursor-pointer ${
              mobileTab === 'roms' ? 'text-[#EA580C]' : 'text-[#9AA3B2]'
            }`}
          >
            <FolderOpen className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight">ROMs</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileTab('servers')}
            className={`h-full flex flex-col items-center justify-center gap-1 cursor-pointer ${
              mobileTab === 'servers' ? 'text-[#EA580C]' : 'text-[#9AA3B2]'
            }`}
          >
            <Server className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight">Salas</span>
          </button>
        </nav>
      )}

      <footer className="hidden md:block border-t border-white/10 bg-[#0B0D10] mt-12">
        <div className="max-w-[1380px] mx-auto px-6 py-6 flex items-center justify-between gap-4 text-xs text-[#8E98A8]">
          <span>RetroLink Android &amp; Netplay · SNES, Mega Drive, NES, GBA/GBC, Neo Geo, CPS-2, Arcade</span>
          <span>Acesso exclusivo por e-mail · Sem PlayStation</span>
        </div>
      </footer>

      {showIOSInstallTip && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#15181E] border border-white/10 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Instalar na Tela Inicial</h3>
            <p className="text-xs text-[#A1AAB8] leading-relaxed">
              Para abrir em tela cheia sem barras do navegador: toque no ícone de Compartilhar e selecione{' '}
              <strong className="text-white">Adicionar à Tela de Início</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSInstallTip(false)}
              className="min-h-[44px] w-full text-xs font-semibold bg-[#EA580C] text-white rounded-xl cursor-pointer"
            >
              Entendi
            </button>
          </div>
        </div>
      )}

      {firebaseUser && (
        <AccountModal
          isOpen={accountModalOpen}
          email={firebaseUser.email || ''}
          profile={profile}
          onSave={handleSaveAccount}
          onSignOut={handleSignOut}
          onClose={() => setAccountModalOpen(false)}
        />
      )}


    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <RetroLinkApp />
    </ErrorBoundary>
  );
}
