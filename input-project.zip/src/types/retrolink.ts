export type SystemId =
  | 'arcade'
  | 'neogeo'
  | 'cps2'
  | 'snes'
  | 'megadrive'
  | 'nes'
  | 'gba'
  | 'n64';

export type RegionId = 'BR-SP' | 'SA-EAST' | 'NA-EAST' | 'EU-WEST' | 'JP-TOKYO';

export type RetroCoreName =
  | 'jsnes'
  | 'fceumm'
  | 'snes9x'
  | 'genesis_plus_gx'
  | 'picodrive'
  | 'mgba'
  | 'fbneo'
  | 'mame2003_plus'
  | 'mame2003'
  | 'mednafen_pce_fast'
  | 'mednafen_ngp'
  | 'mednafen_wswan'
  | 'mednafen_lynx'
  | 'mednafen_vb'
  | 'gearcoleco'
  | 'vecx'
  | 'unsupported';

export interface SystemCoreInfo {
  id: SystemId;
  name: string;
  shortName: string;
  nativeCore: string;
  libretroCore: RetroCoreName;
  extensions: string[];
  yearRange: string;
}

export interface ParsedRomInfo {
  romId: string;
  title: string;
  fileName: string;
  systemId: SystemId;
  coreName: RetroCoreName;
  fallbackCoreName?: RetroCoreName;
  fallbackCoreNames?: RetroCoreName[];
  crc32: string;
  sizeBytes: number;
  headerSummary: string;
  playableInBrowser: boolean;
  isBios?: boolean;
  effectiveFileName?: string;
  effectiveBytes?: Uint8Array;
}

export interface UserPublicProfile {
  uid: string;
  gamertag: string;
  region: RegionId;
  favoriteSystem: string;
  photoURL: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GameServer {
  serverId: string;
  inviteCode: string;
  name: string;
  hostUid: string;
  hostGamertag: string;
  romId: string;
  romTitle: string;
  systemId: SystemId;
  region: RegionId;
  visibility: 'public' | 'private';
  status: 'waiting' | 'playing' | 'closed';
  frameDelay: number;
  maxPlayers: number;
  guestUid: string;
  guestGamertag: string;
  runtimeMode: 'native_bridge' | 'web_engine';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserLocalRom {
  romId: string;
  ownerUid: string;
  title: string;
  fileName: string;
  systemId: SystemId;
  crc32: string;
  sizeBytes: number;
}

export interface LiveParticipant {
  uid: string;
  gamertag: string;
  slot: 'P1' | 'P2' | 'SPEC';
  ready: boolean;
  pingMs: number;
  connected?: boolean;
}

export interface LiveChatMessage {
  id: string;
  uid: string;
  gamertag: string;
  text: string;
  timestamp: number;
}

export interface LiveRoomState {
  serverId: string;
  romId: string;
  romTitle: string;
  systemId: string;
  frameDelay: number;
  matchRunning: boolean;
  hasSharedRom: boolean;
  sharedNesRomName: string | null;
  participants: LiveParticipant[];
  chat: LiveChatMessage[];
}

export const INPUT_BITS = {
  UP: 1 << 0,
  DOWN: 1 << 1,
  LEFT: 1 << 2,
  RIGHT: 1 << 3,
  A: 1 << 4,
  B: 1 << 5,
  START: 1 << 6,
  SELECT: 1 << 7,
  X: 1 << 8,
  Y: 1 << 9,
  L1: 1 << 10,
  R1: 1 << 11,
  L2: 1 << 12,
  R2: 1 << 13,
} as const;
