declare module 'jsnes' {
  export class NES {
    constructor(options: {
      onFrame: (frameBuffer: number[]) => void;
      onAudioSample?: (left: number, right: number) => void;
      onStatusUpdate?: (status: string) => void;
      emulateSound?: boolean;
      sampleRate?: number;
    });
    loadROM(data: string): void;
    frame(): void;
    reset(): void;
    buttonDown(controller: 1 | 2, button: number): void;
    buttonUp(controller: 1 | 2, button: number): void;
    toJSON(): Record<string, unknown>;
    fromJSON(state: Record<string, unknown>): void;
  }

  export const Controller: {
    BUTTON_A: number;
    BUTTON_B: number;
    BUTTON_SELECT: number;
    BUTTON_START: number;
    BUTTON_UP: number;
    BUTTON_DOWN: number;
    BUTTON_LEFT: number;
    BUTTON_RIGHT: number;
  };
}
