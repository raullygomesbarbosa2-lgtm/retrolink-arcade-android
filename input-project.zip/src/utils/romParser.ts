import { unzipSync } from 'fflate';
import { ParsedRomInfo, RetroCoreName, SystemId } from '../types/retrolink';
import { computeCrc32 } from './crc32';

const PLAYSTATION_EXTS = ['.iso', '.cue', '.pbp', '.chd', '.ecm', '.img', '.mdf'];

const NON_ROM_HELPER_EXTS = [
  '.txt',
  '.nfo',
  '.md', // careful: .md is Mega Drive! NEVER ignore .md!
];
void NON_ROM_HELPER_EXTS;

export const IGNORABLE_NON_ROM_EXTS = [
  '.txt',
  '.nfo',
  '.diz',
  '.jpg',
  '.jpeg',
  '.png',
  '.webp',
  '.gif',
  '.bmp',
  '.svg',
  '.pdf',
  '.doc',
  '.docx',
  '.srm',
  '.sav',
  '.state',
  '.oops',
  '.cfg',
  '.opt',
  '.xml',
  '.dat',
  '.ini',
  '.log',
  '.mp3',
  '.ogg',
  '.wav',
];

const ARCADE_BIOS_BASENAMES = new Set([
  'neogeo',
  'pgm',
  'skns',
  'isgsm',
  'qsound',
  'decocass',
  'playch10',
  'megatech',
  'neocdz',
]);

const KNOWN_ARCADE_SETS: Record<string, { title: string; systemId: SystemId }> = {
  // Neo Geo MVS / AES
  kof94: { title: "The King of Fighters '94", systemId: 'neogeo' },
  kof95: { title: "The King of Fighters '95", systemId: 'neogeo' },
  kof96: { title: "The King of Fighters '96", systemId: 'neogeo' },
  kof97: { title: "The King of Fighters '97", systemId: 'neogeo' },
  kof98: { title: "The King of Fighters '98", systemId: 'neogeo' },
  kof99: { title: "The King of Fighters '99", systemId: 'neogeo' },
  kof2000: { title: 'The King of Fighters 2000', systemId: 'neogeo' },
  kof2001: { title: 'The King of Fighters 2001', systemId: 'neogeo' },
  kof2002: { title: 'The King of Fighters 2002', systemId: 'neogeo' },
  kof2003: { title: 'The King of Fighters 2003', systemId: 'neogeo' },
  mslug: { title: 'Metal Slug - Super Vehicle-001', systemId: 'neogeo' },
  mslug2: { title: 'Metal Slug 2', systemId: 'neogeo' },
  mslugx: { title: 'Metal Slug X', systemId: 'neogeo' },
  mslug3: { title: 'Metal Slug 3', systemId: 'neogeo' },
  mslug4: { title: 'Metal Slug 4', systemId: 'neogeo' },
  mslug5: { title: 'Metal Slug 5', systemId: 'neogeo' },
  garou: { title: 'Garou: Mark of the Wolves', systemId: 'neogeo' },
  samsho: { title: 'Samurai Shodown', systemId: 'neogeo' },
  samsho2: { title: 'Samurai Shodown II', systemId: 'neogeo' },
  samsho3: { title: 'Samurai Shodown III', systemId: 'neogeo' },
  samsho4: { title: 'Samurai Shodown IV', systemId: 'neogeo' },
  samsho5: { title: 'Samurai Shodown V', systemId: 'neogeo' },
  samsh5sp: { title: 'Samurai Shodown V Special', systemId: 'neogeo' },
  rbff1: { title: 'Real Bout Fatal Fury', systemId: 'neogeo' },
  rbff2: { title: 'Real Bout Fatal Fury 2', systemId: 'neogeo' },
  rbffspec: { title: 'Real Bout Fatal Fury Special', systemId: 'neogeo' },
  fatfury1: { title: 'Fatal Fury', systemId: 'neogeo' },
  fatfury2: { title: 'Fatal Fury 2', systemId: 'neogeo' },
  fatfury3: { title: 'Fatal Fury 3', systemId: 'neogeo' },
  fatfursp: { title: 'Fatal Fury Special', systemId: 'neogeo' },
  aof: { title: 'Art of Fighting', systemId: 'neogeo' },
  aof2: { title: 'Art of Fighting 2', systemId: 'neogeo' },
  aof3: { title: 'Art of Fighting 3', systemId: 'neogeo' },
  lastblad: { title: 'The Last Blade', systemId: 'neogeo' },
  lastbld2: { title: 'The Last Blade 2', systemId: 'neogeo' },
  wjammers: { title: 'Windjammers', systemId: 'neogeo' },
  sengoku: { title: 'Sengoku', systemId: 'neogeo' },
  sengoku2: { title: 'Sengoku 2', systemId: 'neogeo' },
  sengoku3: { title: 'Sengoku 3', systemId: 'neogeo' },
  shocktro: { title: 'Shock Troopers', systemId: 'neogeo' },
  shocktr2: { title: 'Shock Troopers: 2nd Squad', systemId: 'neogeo' },
  blazstar: { title: 'Blazing Star', systemId: 'neogeo' },
  pulstar: { title: 'Pulstar', systemId: 'neogeo' },
  neobombe: { title: 'Neo Bomberman', systemId: 'neogeo' },
  turfmast: { title: 'Neo Turf Masters', systemId: 'neogeo' },
  superside: { title: 'Super Sidekicks', systemId: 'neogeo' },
  ssideki2: { title: 'Super Sidekicks 2', systemId: 'neogeo' },
  ssideki3: { title: 'Super Sidekicks 3', systemId: 'neogeo' },
  svc: { title: 'SNK vs. Capcom: SVC Chaos', systemId: 'neogeo' },
  rotd: { title: 'Rage of the Dragons', systemId: 'neogeo' },
  matrim: { title: 'Matrimelee', systemId: 'neogeo' },
  kizuna: { title: 'Kizuna Encounter', systemId: 'neogeo' },
  kabukikl: { title: 'Kabuki Klash', systemId: 'neogeo' },
  wakuwak7: { title: 'Waku Waku 7', systemId: 'neogeo' },
  twinspri: { title: 'Twinkle Star Sprites', systemId: 'neogeo' },
  pbobblen: { title: 'Puzzle Bobble', systemId: 'neogeo' },
  pbobbl2n: { title: 'Puzzle Bobble 2', systemId: 'neogeo' },
  maglord: { title: 'Magician Lord', systemId: 'neogeo' },
  cyberlip: { title: 'Cyber-Lip', systemId: 'neogeo' },
  roboarmy: { title: 'Robo Army', systemId: 'neogeo' },
  spinmast: { title: 'Spinmaster', systemId: 'neogeo' },
  tophuntr: { title: 'Top Hunter', systemId: 'neogeo' },
  neogeo: { title: 'Neo Geo BIOS (neogeo.zip)', systemId: 'neogeo' },

  // Capcom CPS-2 & CPS-1 & CPS-3
  ssf2: { title: 'Super Street Fighter II', systemId: 'cps2' },
  ssf2t: { title: 'Super Street Fighter II Turbo', systemId: 'cps2' },
  sfa: { title: 'Street Fighter Alpha', systemId: 'cps2' },
  sfa2: { title: 'Street Fighter Alpha 2', systemId: 'cps2' },
  sfa3: { title: 'Street Fighter Alpha 3', systemId: 'cps2' },
  mvsc: { title: 'Marvel vs. Capcom: Clash of Super Heroes', systemId: 'cps2' },
  msh: { title: 'Marvel Super Heroes', systemId: 'cps2' },
  xmcota: { title: 'X-Men: Children of the Atom', systemId: 'cps2' },
  xmvsf: { title: 'X-Men vs. Street Fighter', systemId: 'cps2' },
  mshvsf: { title: 'Marvel Super Heroes vs. Street Fighter', systemId: 'cps2' },
  dstlk: { title: 'Darkstalkers: The Night Warriors', systemId: 'cps2' },
  nwarr: { title: "Night Warriors: Darkstalkers' Revenge", systemId: 'cps2' },
  vsav: { title: 'Vampire Savior', systemId: 'cps2' },
  vsav2: { title: 'Vampire Savior 2', systemId: 'cps2' },
  avsp: { title: 'Alien vs. Predator', systemId: 'cps2' },
  ddtod: { title: 'Dungeons & Dragons: Tower of Doom', systemId: 'cps2' },
  ddsom: { title: 'Dungeons & Dragons: Shadow over Mystara', systemId: 'cps2' },
  '1944': { title: '1944: The Loop Master', systemId: 'cps2' },
  '19xx': { title: '19XX: The War Against Destiny', systemId: 'cps2' },
  progear: { title: 'Progear', systemId: 'cps2' },
  gigawing: { title: 'Giga Wing', systemId: 'cps2' },
  marsmtx: { title: 'Mars Matrix', systemId: 'cps2' },
  armwar: { title: 'Armored Warriors', systemId: 'cps2' },
  cybots: { title: 'Cyberbots: Fullmetal Madness', systemId: 'cps2' },
  ecofghtr: { title: 'Eco Fighters', systemId: 'cps2' },
  sfz3j: { title: 'Street Fighter Zero 3', systemId: 'cps2' },
  sfiii: { title: 'Street Fighter III: New Generation', systemId: 'cps2' },
  sfiii2: { title: 'Street Fighter III: 2nd Impact', systemId: 'cps2' },
  sfiii3: { title: 'Street Fighter III: 3rd Strike', systemId: 'cps2' },
  jojoba: { title: "JoJo's Bizarre Adventure", systemId: 'cps2' },
  dino: { title: 'Cadillacs and Dinosaurs', systemId: 'arcade' },
  punisher: { title: 'The Punisher', systemId: 'arcade' },
  captcomm: { title: 'Captain Commando', systemId: 'arcade' },
  ffight: { title: 'Final Fight', systemId: 'arcade' },
  kod: { title: 'The King of Dragons', systemId: 'arcade' },
  knights: { title: 'Knights of the Round', systemId: 'arcade' },
  wof: { title: 'Warriors of Fate', systemId: 'arcade' },
  sf2: { title: 'Street Fighter II: The World Warrior', systemId: 'arcade' },
  sf2ce: { title: "Street Fighter II': Champion Edition", systemId: 'arcade' },
  sf2hf: { title: "Street Fighter II': Hyper Fighting", systemId: 'arcade' },
  strider: { title: 'Strider', systemId: 'arcade' },
  willow: { title: 'Willow', systemId: 'arcade' },
  unsquad: { title: 'U.N. Squadron', systemId: 'arcade' },
  mercs: { title: 'Mercs', systemId: 'arcade' },
  '3wonders': { title: 'Three Wonders', systemId: 'arcade' },
  varth: { title: 'Varth: Operation Thunderstorm', systemId: 'arcade' },
  cawing: { title: 'Carrier Air Wing', systemId: 'arcade' },
  ghouls: { title: "Ghouls'n Ghosts", systemId: 'arcade' },
  gng: { title: "Ghosts'n Goblins", systemId: 'arcade' },

  // Classic Arcade (Midway / Konami / Sega / Namco / Cave / Taito / Irem)
  mk: { title: 'Mortal Kombat', systemId: 'arcade' },
  mk2: { title: 'Mortal Kombat II', systemId: 'arcade' },
  mk3: { title: 'Mortal Kombat 3', systemId: 'arcade' },
  umk3: { title: 'Ultimate Mortal Kombat 3', systemId: 'arcade' },
  nbajam: { title: 'NBA Jam', systemId: 'arcade' },
  tmnt: { title: 'Teenage Mutant Ninja Turtles', systemId: 'arcade' },
  tmnt2: { title: 'TMNT: Turtles in Time', systemId: 'arcade' },
  ssriders: { title: 'Sunset Riders', systemId: 'arcade' },
  simpsons: { title: 'The Simpsons', systemId: 'arcade' },
  xmen: { title: 'X-Men', systemId: 'arcade' },
  vendetta: { title: 'Vendetta', systemId: 'arcade' },
  metamorp: { title: 'Metamorphic Force', systemId: 'arcade' },
  bucky: { title: "Bucky O'Hare", systemId: 'arcade' },
  contra: { title: 'Contra', systemId: 'arcade' },
  scontra: { title: 'Super Contra', systemId: 'arcade' },
  aliens: { title: 'Aliens', systemId: 'arcade' },
  snowbros: { title: 'Snow Bros.', systemId: 'arcade' },
  bublbobl: { title: 'Bubble Bobble', systemId: 'arcade' },
  toki: { title: 'Toki', systemId: 'arcade' },
  outrun: { title: 'Out Run', systemId: 'arcade' },
  aburner2: { title: 'After Burner II', systemId: 'arcade' },
  goldnaxe: { title: 'Golden Axe', systemId: 'arcade' },
  altbeast: { title: 'Altered Beast', systemId: 'arcade' },
  shinobi: { title: 'Shinobi', systemId: 'arcade' },
  shadowd: { title: 'Shadow Dancer', systemId: 'arcade' },
  moonwalk: { title: "Michael Jackson's Moonwalker", systemId: 'arcade' },
  astorm: { title: 'Alien Storm', systemId: 'arcade' },
  ddp: { title: 'DoDonPachi', systemId: 'arcade' },
  donpachi: { title: 'DonPachi', systemId: 'arcade' },
  esprade: { title: 'ESP Ra.De.', systemId: 'arcade' },
  guwange: { title: 'Guwange', systemId: 'arcade' },
  feversos: { title: 'Fever SOS', systemId: 'arcade' },
  pacmania: { title: 'Pac-Mania', systemId: 'arcade' },
  pacman: { title: 'Pac-Man', systemId: 'arcade' },
  mspacman: { title: 'Ms. Pac-Man', systemId: 'arcade' },
  galaga: { title: 'Galaga', systemId: 'arcade' },
  dkong: { title: 'Donkey Kong', systemId: 'arcade' },
  dkongjr: { title: 'Donkey Kong Jr.', systemId: 'arcade' },
  mario: { title: 'Mario Bros.', systemId: 'arcade' },
  doubledr: { title: 'Double Dragon', systemId: 'arcade' },
  ddragon2: { title: 'Double Dragon II: The Revenge', systemId: 'arcade' },
  badudes: { title: 'Bad Dudes vs. DragonNinja', systemId: 'arcade' },
  robocop: { title: 'RoboCop', systemId: 'arcade' },
  pang: { title: 'Pang / Buster Bros.', systemId: 'arcade' },
  spang: { title: 'Super Pang', systemId: 'arcade' },
  raiden: { title: 'Raiden', systemId: 'arcade' },
  rtype: { title: 'R-Type', systemId: 'arcade' },
  rtype2: { title: 'R-Type II', systemId: 'arcade' },
  gauntlet: { title: 'Gauntlet', systemId: 'arcade' },
  rampage: { title: 'Rampage', systemId: 'arcade' },
  frogger: { title: 'Frogger', systemId: 'arcade' },
  joust: { title: 'Joust', systemId: 'arcade' },
};

const CONSOLE_ROM_EXTS = [
  '.nes',
  '.fds',
  '.unf',
  '.unif',
  '.sfc',
  '.smc',
  '.fig',
  '.swc',
  '.bs',
  '.st',
  '.dx2',
  '.gd3',
  '.gd7',
  '.ufo',
  '.mgd',
  '.md',
  '.gen',
  '.smd',
  '.32x',
  '.sms',
  '.gg',
  '.sg',
  '.bms',
  '.gba',
  '.agb',
  '.gb',
  '.gbc',
  '.cgb',
  '.dmg',
  '.sgb',
  '.pce',
  '.sgx',
  '.ngp',
  '.ngc',
  '.ngpc',
  '.ws',
  '.wsc',
  '.lnx',
  '.col',
  '.cv',
  '.vec',
  '.vb',
  '.vboy',
];

function readAscii(bytes: Uint8Array, start: number, length: number): string {
  let out = '';
  for (let i = start; i < start + length && i < bytes.length; i++) {
    const ch = bytes[i];
    if (ch >= 32 && ch <= 126) {
      out += String.fromCharCode(ch);
    }
  }
  return out.replace(/\s+/g, ' ').trim();
}

function sanitizeTitle(raw: string, fallback: string): string {
  const cleaned = raw.replace(/\s+/g, ' ').trim().slice(0, 80);
  if (cleaned.length >= 2) return cleaned;
  const fb = fallback.replace(/\s+/g, ' ').trim().slice(0, 80);
  return fb.length >= 2 ? fb : 'ROM Classica';
}

function sanitizeFileName(raw: string): string {
  const trimmed = raw.trim().slice(0, 120);
  return trimmed.length >= 1 ? trimmed : 'rom.bin';
}

export function hasPlayStationExtension(name: string): boolean {
  const lower = name.toLowerCase();
  return PLAYSTATION_EXTS.some((ext) => lower.endsWith(ext));
}

export function isIgnorableHelperFile(name: string): boolean {
  const lower = name.toLowerCase();
  const base = lower.split('/').pop() || lower;
  if (base.startsWith('._') || base === '.ds_store' || base === 'thumbs.db') {
    return true;
  }
  return IGNORABLE_NON_ROM_EXTS.some((ext) => lower.endsWith(ext));
}

function looksLikePlayStationDiscImage(bytes: Uint8Array): boolean {
  if (bytes.length < 0x9400) return false;
  const pvd = readAscii(bytes, 0x8000, 64) + readAscii(bytes, 0x9300, 64);
  if (pvd.includes('PLAYSTATION') && pvd.includes('CD001')) return true;
  const cd001 = readAscii(bytes, 0x8001, 24);
  if (cd001.startsWith('CD001') && readAscii(bytes, 0x8008, 32).includes('PLAYSTATION')) {
    return true;
  }
  return false;
}

function formatReadableName(base: string): string {
  return base
    .replace(/\([^)]*\)/g, '')
    .replace(/\[[^\]]*\]/g, '')
    .replace(/[_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isReadableHeaderTitle(title: string): boolean {
  if (title.length < 3) return false;
  const alnum = title.replace(/[^A-Za-z0-9]/g, '');
  return alnum.length >= 3;
}

function hasSnesChecksumMatch(bytes: Uint8Array, offset: number): boolean {
  if (bytes.length < offset + 0x10000) return false;
  const loComp = bytes[offset + 0x7fdc] | (bytes[offset + 0x7fdd] << 8);
  const loCheck = bytes[offset + 0x7fde] | (bytes[offset + 0x7fdf] << 8);
  if (loComp !== 0 && loCheck !== 0 && (loComp ^ loCheck) === 0xffff) return true;

  const hiComp = bytes[offset + 0xffdc] | (bytes[offset + 0xffdd] << 8);
  const hiCheck = bytes[offset + 0xffde] | (bytes[offset + 0xffdf] << 8);
  if (hiComp !== 0 && hiCheck !== 0 && (hiComp ^ hiCheck) === 0xffff) return true;

  return false;
}

function hasGameBoyLogo(bytes: Uint8Array): boolean {
  return (
    bytes.length > 0x150 &&
    bytes[0x104] === 0xce &&
    bytes[0x105] === 0xed &&
    bytes[0x106] === 0x66 &&
    bytes[0x107] === 0x66 &&
    bytes[0x108] === 0xcc &&
    bytes[0x109] === 0x0d
  );
}

function hasGbaLogo(bytes: Uint8Array): boolean {
  return (
    bytes.length > 0xc0 &&
    bytes[0x04] === 0x24 &&
    bytes[0x05] === 0xff &&
    bytes[0x06] === 0xae &&
    bytes[0x07] === 0x51 &&
    bytes[0x08] === 0x69 &&
    bytes[0x09] === 0x9a
  );
}

function buildSnesRomInfo(
  romId: string,
  fileName: string,
  finalFileName: string,
  cleanBase: string,
  bytes: Uint8Array,
  crc32: string
): ParsedRomInfo {
  const hasSmcHeader = bytes.length % 1024 === 512;
  const offset = hasSmcHeader ? 512 : 0;
  const loTitle = readAscii(bytes, offset + 0x7fc0, 21);
  const hiTitle = readAscii(bytes, offset + 0xffc0, 21);
  const internalTitle = isReadableHeaderTitle(loTitle)
    ? loTitle
    : isReadableHeaderTitle(hiTitle)
    ? hiTitle
    : '';
  const chosenTitle = cleanBase.length >= 3 ? cleanBase : internalTitle;
  const lower = fileName.toLowerCase();
  const effectiveFileName =
    lower.endsWith('.sfc') || lower.endsWith('.smc') || lower.endsWith('.fig') || lower.endsWith('.swc')
      ? fileName
      : `${fileName.replace(/\.[^.]+$/, '')}.sfc`;

  return {
    romId,
    title: sanitizeTitle(chosenTitle, fileName),
    fileName: finalFileName,
    systemId: 'snes',
    coreName: 'snes9x',
    crc32,
    sizeBytes: bytes.length,
    headerSummary: `SNES ${internalTitle ? `(${internalTitle})` : ''} · ${(bytes.length / 1024).toFixed(0)} KB`,
    playableInBrowser: true,
    effectiveFileName,
    effectiveBytes: bytes,
  };
}

function parseSingleRomBytes(
  fileName: string,
  bytes: Uint8Array,
  displayFileName?: string
): ParsedRomInfo {
  const lower = fileName.toLowerCase();
  if (hasPlayStationExtension(lower) || looksLikePlayStationDiscImage(bytes)) {
    throw new Error(
      'Arquivos de PlayStation (.iso/.cue/.pbp/.chd) não são suportados nesta plataforma.'
    );
  }

  const crc32 = computeCrc32(bytes);
  const cleanBase = formatReadableName(fileName.replace(/\.[^.]+$/, '')) || fileName;
  const romId = `rom_${crc32.toLowerCase()}`;
  const finalFileName = sanitizeFileName(displayFileName || fileName);

  // 1. NES iNES ("NES\x1A") & Famicom Disk System ("FDS\x1A") / UNIF
  if (
    lower.endsWith('.nes') ||
    (bytes.length >= 16 &&
      bytes[0] === 0x4e &&
      bytes[1] === 0x45 &&
      bytes[2] === 0x53 &&
      bytes[3] === 0x1a)
  ) {
    const prgBanks = bytes[4] || 0;
    const chrBanks = bytes[5] || 0;
    const mapper = ((bytes[6] || 0) >> 4) | ((bytes[7] || 0) & 0xf0);
    const effectiveFileName = lower.endsWith('.nes') ? fileName : `${fileName.replace(/\.[^.]+$/, '')}.nes`;
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'nes',
      coreName: 'jsnes',
      fallbackCoreName: 'fceumm',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Nintendo 8-Bit · Mapper ${mapper} · PRG ${prgBanks * 16}KB · CHR ${chrBanks * 8}KB`,
      playableInBrowser: true,
      effectiveFileName,
      effectiveBytes: bytes,
    };
  }

  if (
    lower.endsWith('.fds') ||
    lower.endsWith('.unf') ||
    lower.endsWith('.unif') ||
    (bytes.length >= 16 &&
      bytes[0] === 0x46 &&
      bytes[1] === 0x44 &&
      bytes[2] === 0x53 &&
      bytes[3] === 0x1a)
  ) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'nes',
      coreName: 'fceumm',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Famicom Disk / NES UNIF · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 2. Game Boy Advance (.gba / .agb) & Game Boy / Game Boy Color (.gb / .gbc / .dmg / .cgb)
  if (lower.endsWith('.gba') || lower.endsWith('.agb') || hasGbaLogo(bytes)) {
    const internalName = readAscii(bytes, 0xa0, 12);
    const gameCode = readAscii(bytes, 0xac, 4);
    const title = isReadableHeaderTitle(internalName)
      ? cleanBase.length >= 3
        ? cleanBase
        : internalName
      : cleanBase;
    const effectiveFileName =
      lower.endsWith('.gba') || lower.endsWith('.agb')
        ? fileName
        : `${fileName.replace(/\.[^.]+$/, '')}.gba`;
    return {
      romId,
      title: sanitizeTitle(title, fileName),
      fileName: finalFileName,
      systemId: 'gba',
      coreName: 'mgba',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Game Boy Advance · Código ${gameCode || 'GBA'} · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName,
      effectiveBytes: bytes,
    };
  }

  if (
    lower.endsWith('.gb') ||
    lower.endsWith('.gbc') ||
    lower.endsWith('.cgb') ||
    lower.endsWith('.dmg') ||
    lower.endsWith('.sgb') ||
    hasGameBoyLogo(bytes)
  ) {
    const gbTitle = readAscii(bytes, 0x134, 15);
    const isColor =
      lower.endsWith('.gbc') || lower.endsWith('.cgb') || bytes[0x143] === 0x80 || bytes[0x143] === 0xc0;
    const effectiveFileName =
      lower.endsWith('.gb') || lower.endsWith('.gbc')
        ? fileName
        : `${fileName.replace(/\.[^.]+$/, '')}.${isColor ? 'gbc' : 'gb'}`;
    return {
      romId,
      title: sanitizeTitle(cleanBase.length >= 3 ? cleanBase : gbTitle, fileName),
      fileName: finalFileName,
      systemId: 'gba',
      coreName: 'mgba',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `${isColor ? 'Game Boy Color' : 'Game Boy Clássico'} · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName,
      effectiveBytes: bytes,
    };
  }

  // 3. Super Nintendo (.sfc / .smc / .fig / .swc / .bs / .st / etc.)
  if (
    lower.endsWith('.sfc') ||
    lower.endsWith('.smc') ||
    lower.endsWith('.fig') ||
    lower.endsWith('.swc') ||
    lower.endsWith('.bs') ||
    lower.endsWith('.st') ||
    lower.endsWith('.dx2') ||
    lower.endsWith('.gd3') ||
    lower.endsWith('.gd7') ||
    lower.endsWith('.ufo') ||
    lower.endsWith('.mgd')
  ) {
    return buildSnesRomInfo(romId, fileName, finalFileName, cleanBase, bytes, crc32);
  }

  // 4. Sega 32X (.32x)
  if (lower.endsWith('.32x')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'megadrive',
      coreName: 'picodrive',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Sega 32X · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 5. Master System / Game Gear / SG-1000
  if (lower.endsWith('.sms') || lower.endsWith('.gg') || lower.endsWith('.sg') || lower.endsWith('.bms')) {
    const label = lower.endsWith('.gg')
      ? 'Sega Game Gear'
      : lower.endsWith('.sg')
      ? 'Sega SG-1000'
      : 'Sega Master System';
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'megadrive',
      coreName: 'genesis_plus_gx',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `${label} · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 6. Mega Drive / Genesis (.md / .gen / .smd)
  if (lower.endsWith('.md') || lower.endsWith('.gen') || lower.endsWith('.smd')) {
    const segaMagic = readAscii(bytes, 0x100, 16);
    const mdDomTitle = readAscii(bytes, 0x120, 48);
    const mdIntTitle = readAscii(bytes, 0x150, 48);
    const internalTitle = isReadableHeaderTitle(mdIntTitle)
      ? mdIntTitle
      : isReadableHeaderTitle(mdDomTitle)
      ? mdDomTitle
      : '';
    return {
      romId,
      title: sanitizeTitle(cleanBase.length >= 3 ? cleanBase : internalTitle, fileName),
      fileName: finalFileName,
      systemId: 'megadrive',
      coreName: 'genesis_plus_gx',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `${segaMagic.includes('SEGA') ? 'SEGA Mega Drive' : 'Mega Drive / Genesis'} ${
        internalTitle ? `· ${internalTitle}` : ''
      }`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 7. PC Engine / SuperGrafx (.pce / .sgx)
  if (lower.endsWith('.pce') || lower.endsWith('.sgx')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'arcade',
      coreName: 'mednafen_pce_fast',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `PC Engine / TurboGrafx-16 · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 8. Neo Geo Pocket / Color (.ngp / .ngc / .ngpc)
  if (lower.endsWith('.ngp') || lower.endsWith('.ngc') || lower.endsWith('.ngpc')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'neogeo',
      coreName: 'mednafen_ngp',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Neo Geo Pocket / Color · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 9. WonderSwan / Color (.ws / .wsc)
  if (lower.endsWith('.ws') || lower.endsWith('.wsc')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'gba',
      coreName: 'mednafen_wswan',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `WonderSwan / Color · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 10. Atari Lynx / ColecoVision / Vectrex / Virtual Boy
  if (lower.endsWith('.lnx')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'arcade',
      coreName: 'mednafen_lynx',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Atari Lynx · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  if (lower.endsWith('.col') || lower.endsWith('.cv')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'arcade',
      coreName: 'gearcoleco',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `ColecoVision · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  if (lower.endsWith('.vec')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'arcade',
      coreName: 'vecx',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Vectrex · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  if (lower.endsWith('.vb') || lower.endsWith('.vboy')) {
    return {
      romId,
      title: sanitizeTitle(cleanBase, fileName),
      fileName: finalFileName,
      systemId: 'gba',
      coreName: 'mednafen_vb',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Virtual Boy · ${(bytes.length / 1024).toFixed(0)} KB`,
      playableInBrowser: true,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 11. Arcade .fba package (FBNeo romset)
  if (lower.endsWith('.fba')) {
    const baseZipName = `${fileName.replace(/\.fba$/i, '')}.zip`;
    return parseArcadeZipRom(baseZipName, bytes, [baseZipName], finalFileName);
  }

  // 12. Nintendo 64 (.z64 / .n64 / .v64)
  if (lower.endsWith('.z64') || lower.endsWith('.n64') || lower.endsWith('.v64')) {
    const n64Title = readAscii(bytes, 0x20, 20);
    return {
      romId,
      title: sanitizeTitle(cleanBase.length >= 3 ? cleanBase : n64Title, fileName),
      fileName: finalFileName,
      systemId: 'n64',
      coreName: 'unsupported',
      crc32,
      sizeBytes: bytes.length,
      headerSummary: `Nintendo 64 (${n64Title || 'N64'}) · ${(bytes.length / (1024 * 1024)).toFixed(1)} MB`,
      playableInBrowser: false,
      effectiveFileName: fileName,
      effectiveBytes: bytes,
    };
  }

  // 13. Smart byte-header detection for .bin / .rom / extensionless ROMs
  if (lower.endsWith('.bin') || lower.endsWith('.rom') || !lower.includes('.')) {
    const segaMagic = readAscii(bytes, 0x100, 16);
    if (segaMagic.includes('SEGA 32X')) {
      return {
        romId,
        title: sanitizeTitle(cleanBase, fileName),
        fileName: finalFileName,
        systemId: 'megadrive',
        coreName: 'picodrive',
        crc32,
        sizeBytes: bytes.length,
        headerSummary: `SEGA 32X · ${(bytes.length / 1024).toFixed(0)} KB`,
        playableInBrowser: true,
        effectiveFileName: `${fileName.replace(/\.[^.]+$/, '')}.32x`,
        effectiveBytes: bytes,
      };
    }

    if (segaMagic.includes('SEGA')) {
      const mdIntTitle = readAscii(bytes, 0x150, 48);
      const mdDomTitle = readAscii(bytes, 0x120, 48);
      const internalTitle = isReadableHeaderTitle(mdIntTitle)
        ? mdIntTitle
        : isReadableHeaderTitle(mdDomTitle)
        ? mdDomTitle
        : '';
      return {
        romId,
        title: sanitizeTitle(cleanBase.length >= 3 ? cleanBase : internalTitle, fileName),
        fileName: finalFileName,
        systemId: 'megadrive',
        coreName: 'genesis_plus_gx',
        crc32,
        sizeBytes: bytes.length,
        headerSummary: `SEGA Mega Drive ${internalTitle ? `· ${internalTitle}` : ''}`,
        playableInBrowser: true,
        effectiveFileName: lower.endsWith('.bin') ? fileName : `${fileName}.bin`,
        effectiveBytes: bytes,
      };
    }

    const tmrSega =
      readAscii(bytes, 0x7ff0, 8) + readAscii(bytes, 0x3ff0, 8) + readAscii(bytes, 0x1ff0, 8);
    if (tmrSega.includes('TMR SEGA')) {
      return {
        romId,
        title: sanitizeTitle(cleanBase, fileName),
        fileName: finalFileName,
        systemId: 'megadrive',
        coreName: 'genesis_plus_gx',
        crc32,
        sizeBytes: bytes.length,
        headerSummary: `Sega Master System · ${(bytes.length / 1024).toFixed(0)} KB`,
        playableInBrowser: true,
        effectiveFileName: `${fileName.replace(/\.[^.]+$/, '')}.sms`,
        effectiveBytes: bytes,
      };
    }

    const snesOffset = bytes.length % 1024 === 512 ? 512 : 0;
    if (hasSnesChecksumMatch(bytes, snesOffset)) {
      return buildSnesRomInfo(romId, fileName, finalFileName, cleanBase, bytes, crc32);
    }

    if (lower.endsWith('.bin') && bytes.length >= 32768 && bytes.length <= 8 * 1024 * 1024) {
      return {
        romId,
        title: sanitizeTitle(cleanBase, fileName),
        fileName: finalFileName,
        systemId: 'megadrive',
        coreName: 'genesis_plus_gx',
        crc32,
        sizeBytes: bytes.length,
        headerSummary: `Mega Drive / Genesis (.bin) · ${(bytes.length / 1024).toFixed(0)} KB`,
        playableInBrowser: true,
        effectiveFileName: fileName,
        effectiveBytes: bytes,
      };
    }
  }

  throw new Error(
    `Formato "${fileName}" não reconhecido. Use ROMs em .zip, .sfc, .smc, .fig, .md, .bin, .gen, .32x, .sms, .gg, .nes, .fds, .gba, .gb, .gbc, .pce, .ngp, .ws ou .lnx.`
  );
}

function parseArcadeZipRom(
  fileName: string,
  bytes: Uint8Array,
  entryNames: string[],
  displayFileName?: string
): ParsedRomInfo {
  const crc32 = computeCrc32(bytes);
  const romId = `rom_${crc32.toLowerCase()}`;
  const shortKey = fileName.replace(/\.(zip|fba)$/i, '').toLowerCase().trim();
  const baseShortKey = shortKey.split(/[\s(]/)[0];
  const known = KNOWN_ARCADE_SETS[shortKey] || KNOWN_ARCADE_SETS[baseShortKey];

  const isBiosArchive =
    ARCADE_BIOS_BASENAMES.has(shortKey) ||
    ARCADE_BIOS_BASENAMES.has(baseShortKey) ||
    entryNames.some((n) => n.toLowerCase().includes('uni-bios'));

  let systemId: SystemId = known?.systemId || 'arcade';
  if (!known) {
    const joined = entryNames.join(' ').toLowerCase();
    if (
      shortKey.includes('kof') ||
      shortKey.includes('mslug') ||
      shortKey.includes('garou') ||
      shortKey.includes('samsho') ||
      shortKey.includes('fatfury') ||
      shortKey.includes('rbff') ||
      shortKey.includes('lastbl') ||
      shortKey.includes('neogeo') ||
      joined.includes('-p1.') ||
      joined.includes('-c1.') ||
      joined.includes('-m1.') ||
      joined.includes('-v1.')
    ) {
      systemId = 'neogeo';
    } else if (
      shortKey.includes('ssf2') ||
      shortKey.includes('mvsc') ||
      shortKey.includes('xmvsf') ||
      shortKey.includes('msh') ||
      shortKey.includes('xmcota') ||
      shortKey.includes('sfa') ||
      shortKey.includes('sfz') ||
      shortKey.includes('sfiii') ||
      shortKey.includes('1944') ||
      shortKey.includes('vsav') ||
      shortKey.includes('dstlk') ||
      shortKey.includes('ddsom') ||
      shortKey.includes('avsp')
    ) {
      systemId = 'cps2';
    }
  }

  const coreName: RetroCoreName = 'fbneo';
  const title = known?.title || formatReadableName(fileName.replace(/\.(zip|fba)$/i, '')) || fileName;

  return {
    romId,
    title: sanitizeTitle(title, fileName),
    fileName: sanitizeFileName(displayFileName || fileName),
    systemId,
    coreName,
    fallbackCoreName: isBiosArchive ? undefined : 'mame2003_plus',
    crc32,
    sizeBytes: bytes.length,
    headerSummary: isBiosArchive
      ? `BIOS Arcade (${shortKey}) · ${entryNames.length} arquivos`
      : `${
          systemId === 'neogeo' ? 'Neo Geo MVS' : systemId === 'cps2' ? 'Capcom CPS' : 'Arcade FBNeo/MAME'
        } · ${entryNames.length} ROMs no ZIP · ${(bytes.length / 1024).toFixed(0)} KB`,
    playableInBrowser: !isBiosArchive,
    isBios: isBiosArchive,
    effectiveFileName: fileName,
    effectiveBytes: bytes,
  };
}

export function parseRomFiles(fileName: string, bytes: Uint8Array): ParsedRomInfo[] {
  const lower = fileName.toLowerCase();
  if (hasPlayStationExtension(lower)) {
    throw new Error(
      'Arquivos de PlayStation (.iso/.cue/.pbp/.chd) não são suportados nesta plataforma.'
    );
  }

  if (lower.endsWith('.zip')) {
    let entries: Record<string, Uint8Array>;
    try {
      entries = unzipSync(bytes);
    } catch {
      throw new Error(`Não foi possível ler o arquivo ZIP "${fileName}".`);
    }

    const entryNames = Object.keys(entries).filter((k) => !k.endsWith('/') && entries[k].length > 0);
    if (entryNames.length === 0) {
      throw new Error(`O arquivo ZIP "${fileName}" está vazio.`);
    }

    if (entryNames.some((n) => hasPlayStationExtension(n))) {
      throw new Error(
        'Arquivos de PlayStation (.iso/.cue/.pbp/.chd) dentro do ZIP não são suportados.'
      );
    }

    // Extract ALL console ROMs inside the ZIP (supports both 1-ROM zips and multi-ROM packs)
    const consoleEntries = entryNames.filter((name) => {
      const n = name.toLowerCase();
      return CONSOLE_ROM_EXTS.some((ext) => n.endsWith(ext));
    });

    if (consoleEntries.length > 0) {
      const results: ParsedRomInfo[] = [];
      for (const entryName of consoleEntries) {
        const innerName = entryName.split('/').pop() || entryName;
        results.push(parseSingleRomBytes(innerName, entries[entryName]));
      }
      return results;
    }

    // Check if zip contains a single .bin / .rom console ROM (Mega Drive, SNES, NES, GBA, GB)
    if (entryNames.length === 1 && /\.(bin|rom)$/i.test(entryNames[0])) {
      const innerName = entryNames[0].split('/').pop() || entryNames[0];
      const innerBytes = entries[entryNames[0]];
      const magic = readAscii(innerBytes, 0x100, 16);
      const isNes =
        innerBytes.length >= 16 &&
        innerBytes[0] === 0x4e &&
        innerBytes[1] === 0x45 &&
        innerBytes[2] === 0x53 &&
        innerBytes[3] === 0x1a;
      const isSnes = hasSnesChecksumMatch(innerBytes, innerBytes.length % 1024 === 512 ? 512 : 0);
      if (magic.includes('SEGA') || isNes || isSnes || hasGbaLogo(innerBytes) || hasGameBoyLogo(innerBytes)) {
        return [parseSingleRomBytes(innerName, innerBytes)];
      }
    }

    // Otherwise treat as Arcade / Neo Geo / CPS romset (.zip passed straight to FBNeo / MAME 2003+)
    return [parseArcadeZipRom(fileName, bytes, entryNames)];
  }

  return [parseSingleRomBytes(fileName, bytes)];
}

export function parseRomFile(fileName: string, bytes: Uint8Array): ParsedRomInfo {
  const list = parseRomFiles(fileName, bytes);
  return list[0];
}
