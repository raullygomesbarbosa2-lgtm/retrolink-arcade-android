const PENDING_JOIN_KEY = 'retrolink_pending_join_code';

export function getPublicAppOrigin(): string {
  if (typeof window === 'undefined') return '';
  const { protocol, host, hostname } = window.location;
  // Convert private AI Studio dev preview URL (ais-dev-*) to the shareable public URL (ais-pre-*)
  if (hostname.startsWith('ais-dev-')) {
    const publicHost = host.replace(/^ais-dev-/, 'ais-pre-');
    return `${protocol}//${publicHost}`;
  }
  return window.location.origin;
}

export function buildAppShareUrl(inviteCode?: string): string {
  const base = getPublicAppOrigin();
  if (!inviteCode) return `${base}/`;
  return `${base}/?join=${encodeURIComponent(inviteCode.trim().toUpperCase())}`;
}

export function savePendingInviteCode(code: string): void {
  const clean = code.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (clean.length >= 6) {
    try {
      localStorage.setItem(PENDING_JOIN_KEY, clean);
    } catch {
      // ignore storage errors
    }
  }
}

export function loadPendingInviteCode(): string {
  try {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = (params.get('join') || '').trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
    if (fromUrl.length >= 6) {
      savePendingInviteCode(fromUrl);
      return fromUrl;
    }
    return (localStorage.getItem(PENDING_JOIN_KEY) || '').trim().toUpperCase();
  } catch {
    return '';
  }
}

export function clearPendingInviteCode(): void {
  try {
    localStorage.removeItem(PENDING_JOIN_KEY);
    const url = new URL(window.location.href);
    if (url.searchParams.has('join')) {
      url.searchParams.delete('join');
      window.history.replaceState({}, '', url.pathname + url.search + url.hash);
    }
  } catch {
    // ignore
  }
}

export async function shareAccessWithFriend(opts: {
  title: string;
  text: string;
  url: string;
}): Promise<'shared' | 'copied'> {
  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title: opts.title,
        text: opts.text,
        url: opts.url,
      });
      return 'shared';
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw err;
      }
      // Fall through to clipboard copy if share API is blocked in iframe/desktop
    }
  }

  await navigator.clipboard.writeText(`${opts.text}\n${opts.url}`);
  return 'copied';
}
