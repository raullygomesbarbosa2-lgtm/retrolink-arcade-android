import {
  RoomSignalDoc,
  sendRoomSignal,
  subscribeToIncomingSignals,
} from './firestoreService';
import { uint8ToBase64 } from '../utils/crc32';

export type RtcStatus = 'waiting_peer' | 'connecting' | 'connected' | 'reconnecting';

export type MatchControlAction = 'start' | 'pause' | 'resume' | 'reset' | 'menu';

export interface RtcStateSyncPayload {
  frame: number;
  engine: 'nes' | 'retro';
  bytes: Uint8Array;
}

interface RtcNetplayOptions {
  serverId: string;
  myUid: string;
  peerUid: string;
  hostUid: string;
  guestUid: string;
  isHost: boolean;
  onStatusChange: (status: RtcStatus) => void;
  onRemoteInput: (frame: number, mask: number, hist?: [number, number][]) => void;
  onPingMeasured: (rttMs: number) => void;
  onPeerReady: (ready: boolean) => void;
  onPeerCharacter?: (slot: 'P1' | 'P2', character: string) => void;
  onMatchControl?: (action: MatchControlAction, frame: number) => void;
  onStateReceived?: (payload: RtcStateSyncPayload) => void;
  onRomTransferProgress: (info: { direction: 'send' | 'receive'; percent: number; fileName: string }) => void;
  onRomReceived: (fileName: string, bytes: Uint8Array) => void;
}

const ICE_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun.cloudflare.com:3478' },
];

const CHUNK_BYTES = 16384;

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

export class RtcNetplaySession {
  private opts: RtcNetplayOptions;
  private pc: RTCPeerConnection | null = null;
  private inputChannel: RTCDataChannel | null = null;
  private controlChannel: RTCDataChannel | null = null;
  private unsubSignals: (() => void) | null = null;
  private pendingIce: RTCIceCandidateInit[] = [];
  private pingTimer: number | null = null;
  private disposed = false;

  private incomingRomMeta: {
    fileName: string;
    totalChunks: number;
    totalBytes: number;
    chunks: (Uint8Array | null)[];
    receivedCount: number;
  } | null = null;

  private incomingStateMeta: {
    frame: number;
    engine: 'nes' | 'retro';
    totalChunks: number;
    chunks: (Uint8Array | null)[];
    receivedCount: number;
  } | null = null;

  constructor(opts: RtcNetplayOptions) {
    this.opts = opts;
    this.start();
  }

  private start() {
    this.opts.onStatusChange('connecting');
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    this.pc = pc;

    pc.onicecandidate = (event) => {
      if (event.candidate && !this.disposed) {
        void sendRoomSignal({
          serverId: this.opts.serverId,
          senderUid: this.opts.myUid,
          targetUid: this.opts.peerUid,
          hostUid: this.opts.hostUid,
          guestUid: this.opts.guestUid,
          kind: 'ice',
          payload: JSON.stringify(event.candidate.toJSON()),
        });
      }
    };

    pc.onconnectionstatechange = () => {
      if (this.disposed) return;
      if (pc.connectionState === 'connected') {
        this.opts.onStatusChange('connected');
      } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        this.opts.onStatusChange('reconnecting');
      }
    };

    if (this.opts.isHost) {
      const inputs = pc.createDataChannel('netplay-inputs', {
        ordered: false,
        maxRetransmits: 0,
      });
      const control = pc.createDataChannel('netplay-control', {
        ordered: true,
      });
      this.attachInputChannel(inputs);
      this.attachControlChannel(control);
    } else {
      pc.ondatachannel = (event) => {
        if (event.channel.label === 'netplay-inputs') {
          this.attachInputChannel(event.channel);
        } else if (event.channel.label === 'netplay-control') {
          this.attachControlChannel(event.channel);
        }
      };
    }

    this.unsubSignals = subscribeToIncomingSignals(
      this.opts.serverId,
      this.opts.myUid,
      (sig) => void this.handleSignal(sig)
    );

    if (this.opts.isHost) {
      void this.createAndSendOffer();
    }

    this.pingTimer = window.setInterval(() => {
      if (this.inputChannel && this.inputChannel.readyState === 'open') {
        this.inputChannel.send(JSON.stringify({ t: 'ping', ts: performance.now() }));
      }
    }, 2000);
  }

  private async createAndSendOffer() {
    if (!this.pc || this.disposed) return;
    try {
      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);
      await sendRoomSignal({
        serverId: this.opts.serverId,
        senderUid: this.opts.myUid,
        targetUid: this.opts.peerUid,
        hostUid: this.opts.hostUid,
        guestUid: this.opts.guestUid,
        kind: 'offer',
        payload: JSON.stringify(offer),
      });
    } catch {
      // ignore setup race
    }
  }

  private async handleSignal(sig: RoomSignalDoc) {
    if (this.disposed || !this.pc) return;
    try {
      if (sig.kind === 'ready') {
        this.opts.onPeerReady(sig.payload === '1');
        return;
      }

      if (sig.kind === 'command') {
        const parsed = JSON.parse(sig.payload) as {
          action?: MatchControlAction;
          frame?: number;
          character?: string;
          slot?: 'P1' | 'P2';
        };
        if (parsed.action && !this.opts.isHost && sig.senderUid === this.opts.hostUid) {
          this.opts.onMatchControl?.(parsed.action, parsed.frame ?? 0);
        } else if (parsed.character && parsed.slot) {
          this.opts.onPeerCharacter?.(parsed.slot, parsed.character);
        }
        return;
      }

      if (sig.kind === 'offer' && !this.opts.isHost) {
        const offer = JSON.parse(sig.payload) as RTCSessionDescriptionInit;
        await this.pc.setRemoteDescription(offer);
        for (const cand of this.pendingIce) {
          await this.pc.addIceCandidate(cand).catch(() => {});
        }
        this.pendingIce = [];
        const answer = await this.pc.createAnswer();
        await this.pc.setLocalDescription(answer);
        await sendRoomSignal({
          serverId: this.opts.serverId,
          senderUid: this.opts.myUid,
          targetUid: this.opts.peerUid,
          hostUid: this.opts.hostUid,
          guestUid: this.opts.guestUid,
          kind: 'answer',
          payload: JSON.stringify(answer),
        });
        return;
      }

      if (sig.kind === 'answer' && this.opts.isHost) {
        const answer = JSON.parse(sig.payload) as RTCSessionDescriptionInit;
        if (!this.pc.currentRemoteDescription) {
          await this.pc.setRemoteDescription(answer);
          for (const cand of this.pendingIce) {
            await this.pc.addIceCandidate(cand).catch(() => {});
          }
          this.pendingIce = [];
        }
        return;
      }

      if (sig.kind === 'ice') {
        const cand = JSON.parse(sig.payload) as RTCIceCandidateInit;
        if (this.pc.remoteDescription) {
          await this.pc.addIceCandidate(cand).catch(() => {});
        } else {
          this.pendingIce.push(cand);
        }
      }
    } catch {
      // ignore malformed/stale signal
    }
  }

  private attachInputChannel(ch: RTCDataChannel) {
    this.inputChannel = ch;
    ch.onopen = () => {
      if (!this.disposed) this.opts.onStatusChange('connected');
    };
    ch.onmessage = (event) => {
      try {
        const msg = JSON.parse(String(event.data)) as {
          t?: string;
          f?: number;
          m?: number;
          hist?: [number, number][];
          ts?: number;
        };
        if (msg.t === 'in' && typeof msg.m === 'number') {
          this.opts.onRemoteInput(msg.f ?? 0, msg.m, msg.hist);
        } else if (msg.t === 'ping' && typeof msg.ts === 'number') {
          if (ch.readyState === 'open') {
            ch.send(JSON.stringify({ t: 'pong', ts: msg.ts }));
          }
        } else if (msg.t === 'pong' && typeof msg.ts === 'number') {
          const rtt = Math.max(1, Math.round(performance.now() - msg.ts));
          this.opts.onPingMeasured(rtt);
        }
      } catch {
        // ignore invalid packet
      }
    };
  }

  private attachControlChannel(ch: RTCDataChannel) {
    this.controlChannel = ch;
    ch.onopen = () => {
      if (!this.disposed) this.opts.onStatusChange('connected');
    };
    ch.onmessage = (event) => {
      try {
        const msg = JSON.parse(String(event.data)) as {
          t?: string;
          ready?: boolean;
          slot?: 'P1' | 'P2';
          character?: string;
          action?: MatchControlAction;
          frame?: number;
          engine?: 'nes' | 'retro';
          fileName?: string;
          totalChunks?: number;
          totalBytes?: number;
          idx?: number;
          b64?: string;
        };
        if (msg.t === 'ready') {
          this.opts.onPeerReady(Boolean(msg.ready));
          return;
        }
        if (msg.t === 'char_select' && msg.slot && typeof msg.character === 'string') {
          this.opts.onPeerCharacter?.(msg.slot, msg.character);
          return;
        }
        if (msg.t === 'match_ctrl' && msg.action && !this.opts.isHost) {
          this.opts.onMatchControl?.(msg.action, msg.frame ?? 0);
          return;
        }
        if (
          msg.t === 'state_meta' &&
          !this.opts.isHost &&
          typeof msg.totalChunks === 'number' &&
          typeof msg.frame === 'number'
        ) {
          this.incomingStateMeta = {
            frame: msg.frame,
            engine: msg.engine === 'nes' ? 'nes' : 'retro',
            totalChunks: msg.totalChunks,
            chunks: new Array<Uint8Array | null>(msg.totalChunks).fill(null),
            receivedCount: 0,
          };
          return;
        }
        if (
          msg.t === 'state_chunk' &&
          !this.opts.isHost &&
          this.incomingStateMeta &&
          typeof msg.idx === 'number' &&
          typeof msg.b64 === 'string'
        ) {
          const meta = this.incomingStateMeta;
          if (msg.idx >= 0 && msg.idx < meta.totalChunks && !meta.chunks[msg.idx]) {
            meta.chunks[msg.idx] = base64ToBytes(msg.b64);
            meta.receivedCount += 1;
            if (meta.receivedCount === meta.totalChunks) {
              const totalLen = meta.chunks.reduce((acc, c) => acc + (c ? c.length : 0), 0);
              const merged = new Uint8Array(totalLen);
              let offset = 0;
              for (const chunk of meta.chunks) {
                if (chunk) {
                  merged.set(chunk, offset);
                  offset += chunk.length;
                }
              }
              const done = { frame: meta.frame, engine: meta.engine, bytes: merged };
              this.incomingStateMeta = null;
              this.opts.onStateReceived?.(done);
            }
          }
          return;
        }
        if (msg.t === 'rom_meta' && msg.fileName && typeof msg.totalChunks === 'number') {
          this.incomingRomMeta = {
            fileName: msg.fileName,
            totalChunks: msg.totalChunks,
            totalBytes: msg.totalBytes || 0,
            chunks: new Array<Uint8Array | null>(msg.totalChunks).fill(null),
            receivedCount: 0,
          };
          this.opts.onRomTransferProgress({
            direction: 'receive',
            percent: 0,
            fileName: msg.fileName,
          });
          return;
        }
        if (
          msg.t === 'rom_chunk' &&
          this.incomingRomMeta &&
          typeof msg.idx === 'number' &&
          typeof msg.b64 === 'string'
        ) {
          const meta = this.incomingRomMeta;
          if (msg.idx >= 0 && msg.idx < meta.totalChunks && !meta.chunks[msg.idx]) {
            meta.chunks[msg.idx] = base64ToBytes(msg.b64);
            meta.receivedCount += 1;
            const percent = Math.round((meta.receivedCount / Math.max(1, meta.totalChunks)) * 100);
            this.opts.onRomTransferProgress({
              direction: 'receive',
              percent,
              fileName: meta.fileName,
            });
            if (meta.receivedCount === meta.totalChunks) {
              const totalLen = meta.chunks.reduce((acc, c) => acc + (c ? c.length : 0), 0);
              const merged = new Uint8Array(totalLen);
              let offset = 0;
              for (const chunk of meta.chunks) {
                if (chunk) {
                  merged.set(chunk, offset);
                  offset += chunk.length;
                }
              }
              const doneName = meta.fileName;
              this.incomingRomMeta = null;
              this.opts.onRomReceived(doneName, merged);
            }
          }
        }
      } catch {
        // ignore invalid control message
      }
    };
  }

  public isP2PReady(): boolean {
    return (
      this.inputChannel?.readyState === 'open' || this.controlChannel?.readyState === 'open'
    );
  }

  public sendInput(frame: number, mask: number, hist?: [number, number][]): boolean {
    if (this.inputChannel && this.inputChannel.readyState === 'open') {
      this.inputChannel.send(JSON.stringify({ t: 'in', f: frame, m: mask, hist }));
      return true;
    }
    return false;
  }

  public sendCharacterChoice(slot: 'P1' | 'P2', character: string): void {
    if (this.controlChannel && this.controlChannel.readyState === 'open') {
      this.controlChannel.send(JSON.stringify({ t: 'char_select', slot, character }));
    }
  }

  public async sendMatchControl(action: MatchControlAction, frame = 0): Promise<void> {
    if (!this.opts.isHost) return;
    if (this.controlChannel && this.controlChannel.readyState === 'open') {
      this.controlChannel.send(JSON.stringify({ t: 'match_ctrl', action, frame }));
    }
    await sendRoomSignal({
      serverId: this.opts.serverId,
      senderUid: this.opts.myUid,
      targetUid: this.opts.peerUid,
      hostUid: this.opts.hostUid,
      guestUid: this.opts.guestUid,
      kind: 'command',
      payload: JSON.stringify({ action, frame }),
    });
  }

  public async sendStateBytes(frame: number, engine: 'nes' | 'retro', bytes: Uint8Array): Promise<boolean> {
    if (!this.opts.isHost) return false;
    const ch = this.controlChannel;
    if (!ch || ch.readyState !== 'open') return false;

    const totalChunks = Math.ceil(bytes.length / CHUNK_BYTES);
    ch.send(
      JSON.stringify({
        t: 'state_meta',
        frame,
        engine,
        totalChunks,
      })
    );

    for (let i = 0; i < totalChunks; i++) {
      if (this.disposed || ch.readyState !== 'open') return false;
      const start = i * CHUNK_BYTES;
      const end = Math.min(bytes.length, start + CHUNK_BYTES);
      const slice = bytes.subarray(start, end);
      ch.send(
        JSON.stringify({
          t: 'state_chunk',
          idx: i,
          b64: uint8ToBase64(slice),
        })
      );
      if (ch.bufferedAmount > 256 * 1024) {
        await new Promise((r) => window.setTimeout(r, 20));
      }
    }
    return true;
  }

  public async sendReady(ready: boolean): Promise<void> {
    if (this.controlChannel && this.controlChannel.readyState === 'open') {
      this.controlChannel.send(JSON.stringify({ t: 'ready', ready }));
    }
    await sendRoomSignal({
      serverId: this.opts.serverId,
      senderUid: this.opts.myUid,
      targetUid: this.opts.peerUid,
      hostUid: this.opts.hostUid,
      guestUid: this.opts.guestUid,
      kind: 'ready',
      payload: ready ? '1' : '0',
    });
  }

  public async sendRomBytes(fileName: string, bytes: Uint8Array): Promise<boolean> {
    const ch = this.controlChannel;
    if (!ch || ch.readyState !== 'open') return false;

    const totalChunks = Math.ceil(bytes.length / CHUNK_BYTES);
    ch.send(
      JSON.stringify({
        t: 'rom_meta',
        fileName,
        totalChunks,
        totalBytes: bytes.length,
      })
    );

    for (let i = 0; i < totalChunks; i++) {
      if (this.disposed || ch.readyState !== 'open') return false;
      const start = i * CHUNK_BYTES;
      const end = Math.min(bytes.length, start + CHUNK_BYTES);
      const slice = bytes.subarray(start, end);
      ch.send(
        JSON.stringify({
          t: 'rom_chunk',
          idx: i,
          b64: uint8ToBase64(slice),
        })
      );

      if (ch.bufferedAmount > 256 * 1024) {
        await new Promise((r) => window.setTimeout(r, 25));
      }
      if (i % 10 === 0 || i === totalChunks - 1) {
        this.opts.onRomTransferProgress({
          direction: 'send',
          percent: Math.round(((i + 1) / Math.max(1, totalChunks)) * 100),
          fileName,
        });
      }
    }
    return true;
  }

  public async restartOffer(): Promise<void> {
    if (this.opts.isHost) {
      await this.createAndSendOffer();
    }
  }

  public dispose() {
    this.disposed = true;
    if (this.pingTimer !== null) {
      window.clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this.unsubSignals?.();
    this.unsubSignals = null;
    try {
      this.inputChannel?.close();
      this.controlChannel?.close();
      this.pc?.close();
    } catch {
      // ignore close errors
    }
    this.inputChannel = null;
    this.controlChannel = null;
    this.pc = null;
  }
}
