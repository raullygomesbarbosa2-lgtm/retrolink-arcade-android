import { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  GameServer,
  RegionId,
  SystemId,
  UserLocalRom,
  UserPublicProfile,
} from '../types/retrolink';

const GAMERTAG_REGEX = /^[a-zA-Z0-9_\- ]+$/;
const accountInitInFlight = new Map<string, Promise<UserPublicProfile>>();

export function sanitizeGamertag(raw: string, fallback = 'Player'): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_\- ]/g, '').trim().slice(0, 24);
  return cleaned.length >= 2 ? cleaned : fallback;
}

export function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 6; i++) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `RL-${suffix}`;
}

async function runLoadOrCreateUserAccount(
  user: User,
  overrides?: { gamertag?: string; region?: RegionId; favoriteSystem?: string }
): Promise<UserPublicProfile> {
  const publicPath = `users_public/${user.uid}`;
  const privatePath = `users/${user.uid}/private/info`;

  let existingPublic: UserPublicProfile | null = null;
  try {
    const snap = await getDoc(doc(db, 'users_public', user.uid));
    if (snap.exists()) {
      existingPublic = snap.data() as UserPublicProfile;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, publicPath);
  }

  let privExists = false;
  try {
    const privSnap = await getDoc(doc(db, 'users', user.uid, 'private', 'info'));
    privExists = privSnap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, privatePath);
  }

  if (!privExists) {
    try {
      await setDoc(doc(db, 'users', user.uid, 'private', 'info'), {
        uid: user.uid,
        email: (user.email || 'user@retrolink.app').slice(0, 160),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, privatePath);
    }
  }

  if (existingPublic) {
    return existingPublic;
  }

  const defaultTag = sanitizeGamertag(
    overrides?.gamertag || user.displayName || user.email?.split('@')[0] || 'RetroPlayer',
    'RetroPlayer'
  );
  const profile: UserPublicProfile = {
    uid: user.uid,
    gamertag: defaultTag,
    region: overrides?.region || 'BR-SP',
    favoriteSystem: overrides?.favoriteSystem || 'nes',
    photoURL: (user.photoURL || '').slice(0, 500),
  };

  try {
    await setDoc(doc(db, 'users_public', user.uid), {
      ...profile,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, publicPath);
  }

  return profile;
}

export async function loadOrCreateUserAccount(
  user: User,
  overrides?: { gamertag?: string; region?: RegionId; favoriteSystem?: string }
): Promise<UserPublicProfile> {
  const existingPromise = accountInitInFlight.get(user.uid);
  if (existingPromise) {
    return existingPromise;
  }

  const promise = runLoadOrCreateUserAccount(user, overrides).finally(() => {
    accountInitInFlight.delete(user.uid);
  });
  accountInitInFlight.set(user.uid, promise);
  return promise;
}

export async function updateUserPublicProfile(
  uid: string,
  updates: { gamertag: string; region: RegionId; favoriteSystem: string; photoURL: string }
): Promise<void> {
  const safeTag = sanitizeGamertag(updates.gamertag);
  if (!GAMERTAG_REGEX.test(safeTag)) {
    throw new Error('Gamertag inválida. Use apenas letras, números, espaços, _ ou -.');
  }
  const path = `users_public/${uid}`;
  try {
    await updateDoc(doc(db, 'users_public', uid), {
      gamertag: safeTag,
      region: updates.region,
      favoriteSystem: updates.favoriteSystem.slice(0, 32),
      photoURL: updates.photoURL.slice(0, 500),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export interface CreateServerInput {
  name: string;
  hostUid: string;
  hostGamertag: string;
  romId: string;
  romTitle: string;
  systemId: SystemId;
  region: RegionId;
  visibility: 'public' | 'private';
  frameDelay: number;
  maxPlayers: number;
  runtimeMode: 'native_bridge' | 'web_engine';
}

export async function createGameServer(input: CreateServerInput): Promise<GameServer> {
  const serverId = `srv_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  const inviteCode = generateInviteCode();
  const safeName = input.name.trim().slice(0, 60) || `Sala de ${input.hostGamertag}`;
  const safeTag = sanitizeGamertag(input.hostGamertag);

  const serverDoc: GameServer = {
    serverId,
    inviteCode,
    name: safeName.length >= 3 ? safeName : `${safeName} Arcade`,
    hostUid: input.hostUid,
    hostGamertag: safeTag,
    romId: input.romId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64) || 'custom_rom',
    romTitle: input.romTitle.trim().slice(0, 80),
    systemId: input.systemId,
    region: input.region,
    visibility: input.visibility,
    status: 'waiting',
    frameDelay: Math.max(0, Math.min(6, Math.round(input.frameDelay))),
    maxPlayers: Math.max(2, Math.min(4, Math.round(input.maxPlayers))),
    guestUid: '',
    guestGamertag: '',
    runtimeMode: input.runtimeMode,
  };

  const batch = writeBatch(db);
  batch.set(doc(db, 'servers', serverId), {
    ...serverDoc,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'server_invites', inviteCode), {
    inviteCode,
    serverId,
    hostUid: input.hostUid,
    romTitle: serverDoc.romTitle,
    systemId: serverDoc.systemId,
    createdAt: serverTimestamp(),
  });

  try {
    await batch.commit();
    return serverDoc;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `servers/${serverId}`);
  }
}

export async function joinServerByInviteCode(
  rawCode: string,
  guestUid: string,
  guestGamertag: string
): Promise<GameServer> {
  const inviteCode = rawCode.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (inviteCode.length < 6) {
    throw new Error('Código de servidor inválido. Formato esperado: RL-XXXXXX.');
  }

  const invitePath = `server_invites/${inviteCode}`;
  let inviteData: { serverId: string } | null = null;
  try {
    const inviteSnap = await getDoc(doc(db, 'server_invites', inviteCode));
    if (!inviteSnap.exists()) {
      throw new Error('Código de servidor não encontrado ou expirado.');
    }
    inviteData = inviteSnap.data() as { serverId: string };
  } catch (error) {
    if (error instanceof Error && error.message.includes('não encontrado')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.GET, invitePath);
  }

  return joinServerById(inviteData.serverId, guestUid, guestGamertag);
}

export async function joinServerById(
  serverId: string,
  guestUid: string,
  guestGamertag: string
): Promise<GameServer> {
  const serverPath = `servers/${serverId}`;
  let server: GameServer | null = null;
  try {
    const snap = await getDoc(doc(db, 'servers', serverId));
    if (!snap.exists()) {
      throw new Error('Servidor não encontrado.');
    }
    server = snap.data() as GameServer;
  } catch (error) {
    if (error instanceof Error && error.message.includes('não encontrado')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.GET, serverPath);
  }

  if (server.status === 'closed') {
    throw new Error('Este servidor já foi encerrado pelo host.');
  }

  if (server.hostUid === guestUid || server.guestUid === guestUid) {
    return server;
  }

  if (server.guestUid && server.guestUid !== guestUid) {
    throw new Error('Este servidor já está com os 2 jogadores ativos.');
  }

  const safeTag = sanitizeGamertag(guestGamertag);
  try {
    await updateDoc(doc(db, 'servers', serverId), {
      guestUid,
      guestGamertag: safeTag,
      status: 'playing',
      updatedAt: serverTimestamp(),
    });
    return {
      ...server,
      guestUid,
      guestGamertag: safeTag,
      status: 'playing',
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, serverPath);
  }
}

export async function leaveOrCloseServer(server: GameServer, uid: string): Promise<void> {
  const serverPath = `servers/${server.serverId}`;
  if (server.hostUid === uid) {
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'servers', server.serverId));
      batch.delete(doc(db, 'server_invites', server.inviteCode));
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, serverPath);
    }
    return;
  }

  if (server.guestUid === uid) {
    try {
      await updateDoc(doc(db, 'servers', server.serverId), {
        guestUid: '',
        guestGamertag: '',
        status: 'waiting',
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, serverPath);
    }
  }
}

export async function touchServerQueue(serverId: string): Promise<void> {
  const path = `servers/${serverId}`;
  try {
    await updateDoc(doc(db, 'servers', serverId), {
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateServerSettings(
  serverId: string,
  updates: Partial<Pick<GameServer, 'frameDelay' | 'runtimeMode' | 'status'>>
): Promise<void> {
  const path = `servers/${serverId}`;
  try {
    await updateDoc(doc(db, 'servers', serverId), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeToAccessibleServers(
  uid: string,
  onData: (servers: GameServer[]) => void
): () => void {
  const buckets = {
    publicList: new Map<string, GameServer>(),
    hostList: new Map<string, GameServer>(),
    guestList: new Map<string, GameServer>(),
  };

  const emitMerged = () => {
    const merged = new Map<string, GameServer>();
    for (const m of [buckets.publicList, buckets.hostList, buckets.guestList]) {
      for (const [id, srv] of m.entries()) {
        if (srv.status !== 'closed') {
          merged.set(id, srv);
        }
      }
    }
    onData(Array.from(merged.values()));
  };

  const unsubPublic = onSnapshot(
    query(collection(db, 'servers'), where('visibility', '==', 'public')),
    (snap) => {
      buckets.publicList.clear();
      snap.forEach((d) => buckets.publicList.set(d.id, d.data() as GameServer));
      emitMerged();
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'servers')
  );

  const unsubHost = onSnapshot(
    query(collection(db, 'servers'), where('hostUid', '==', uid)),
    (snap) => {
      buckets.hostList.clear();
      snap.forEach((d) => buckets.hostList.set(d.id, d.data() as GameServer));
      emitMerged();
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'servers')
  );

  const unsubGuest = onSnapshot(
    query(collection(db, 'servers'), where('guestUid', '==', uid)),
    (snap) => {
      buckets.guestList.clear();
      snap.forEach((d) => buckets.guestList.set(d.id, d.data() as GameServer));
      emitMerged();
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'servers')
  );

  return () => {
    unsubPublic();
    unsubHost();
    unsubGuest();
  };
}

export function subscribeToServerDoc(
  serverId: string,
  onData: (server: GameServer | null) => void
): () => void {
  return onSnapshot(
    doc(db, 'servers', serverId),
    (snapshot) => {
      if (!snapshot.exists()) {
        onData(null);
        return;
      }
      onData(snapshot.data() as GameServer);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, `servers/${serverId}`);
    }
  );
}

export async function saveUserLocalRomMetadata(
  uid: string,
  rom: Omit<UserLocalRom, 'ownerUid'>
): Promise<void> {
  const path = `users/${uid}/roms/${rom.romId}`;
  const docRef = doc(db, 'users', uid, 'roms', rom.romId);
  try {
    const existing = await getDoc(docRef);
    if (existing.exists()) {
      return;
    }
    await setDoc(docRef, {
      ...rom,
      ownerUid: uid,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteUserLocalRomMetadata(uid: string, romId: string): Promise<void> {
  const path = `users/${uid}/roms/${romId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'roms', romId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeToUserLocalRoms(
  uid: string,
  onData: (roms: UserLocalRom[]) => void
): () => void {
  const romsQuery = query(collection(db, 'users', uid, 'roms'), where('ownerUid', '==', uid));
  return onSnapshot(
    romsQuery,
    (snapshot) => {
      const items: UserLocalRom[] = [];
      snapshot.forEach((d) => items.push(d.data() as UserLocalRom));
      onData(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${uid}/roms`);
    }
  );
}
