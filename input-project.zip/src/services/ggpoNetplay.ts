export type NetplaySlot = 'P1' | 'P2' | 'SPEC' | 'SOLO';

export interface GgpoInputPacket {
  t: 'in';
  f: number;
  m: number;
  hist?: [number, number][];
}

export interface GgpoStats {
  currentFrame: number;
  lastConfirmedRemoteFrame: number;
  rollbackCount: number;
  frameAdvantage: number;
}

const MAX_HISTORY_FRAMES = 180;
const MAX_ROLLBACK_WINDOW = 10;
const MAX_DRIFT_WAIT_FRAMES = 5;

export class GgpoCoordinator {
  public localSlot: NetplaySlot;
  public frameDelay: number;
  public currentFrame = 0;
  public lastConfirmedRemoteFrame = -1;
  public rollbackCount = 0;

  private localInputs = new Map<number, number>();
  private remoteConfirmed = new Map<number, number>();
  private remoteUsedMask = new Map<number, number>();
  private stateSnapshots = new Map<number, Record<string, unknown>>();
  private lastRemoteMask = 0;
  private pendingRollbackFrame: number | null = null;

  constructor(localSlot: NetplaySlot, frameDelay = 2) {
    this.localSlot = localSlot;
    this.frameDelay = Math.max(0, Math.min(6, Math.round(frameDelay)));
  }

  public reset(frame = 0): void {
    this.currentFrame = frame;
    this.lastConfirmedRemoteFrame = frame - 1;
    this.localInputs.clear();
    this.remoteConfirmed.clear();
    this.remoteUsedMask.clear();
    this.stateSnapshots.clear();
    this.lastRemoteMask = 0;
    this.pendingRollbackFrame = null;
  }

  public setSlotAndDelay(slot: NetplaySlot, frameDelay: number): void {
    this.localSlot = slot;
    this.frameDelay = Math.max(0, Math.min(6, Math.round(frameDelay)));
  }

  public recordLocalInput(rawMask: number): { targetFrame: number; packet: GgpoInputPacket } {
    const targetFrame = this.currentFrame + this.frameDelay;
    this.localInputs.set(targetFrame, rawMask);

    // Include the last 3 previous frames for GGPO-style packet-loss resilience
    const hist: [number, number][] = [];
    for (let offset = 1; offset <= 3; offset++) {
      const f = targetFrame - offset;
      if (f >= 0 && this.localInputs.has(f)) {
        hist.push([f, this.localInputs.get(f)!]);
      }
    }

    return {
      targetFrame,
      packet: {
        t: 'in',
        f: targetFrame,
        m: rawMask,
        hist: hist.length > 0 ? hist : undefined,
      },
    };
  }

  public ingestRemotePacket(frame: number, mask: number, history?: [number, number][]): void {
    const pairs: [number, number][] = [];
    if (Array.isArray(history)) {
      for (const entry of history) {
        if (Array.isArray(entry) && typeof entry[0] === 'number' && typeof entry[1] === 'number') {
          pairs.push([entry[0], entry[1]]);
        }
      }
    }
    pairs.push([frame, mask]);

    for (const [f, m] of pairs) {
      if (f < 0) continue;
      const alreadyConfirmed = this.remoteConfirmed.get(f);
      if (alreadyConfirmed === m) continue;

      this.remoteConfirmed.set(f, m);
      if (f > this.lastConfirmedRemoteFrame) {
        this.lastConfirmedRemoteFrame = f;
        this.lastRemoteMask = m;
      }

      // Check if we already simulated this frame with a wrong prediction
      if (f <= this.currentFrame && this.remoteUsedMask.has(f)) {
        const predicted = this.remoteUsedMask.get(f)!;
        if (predicted !== m) {
          if (this.pendingRollbackFrame === null || f < this.pendingRollbackFrame) {
            this.pendingRollbackFrame = f;
          }
        }
      }
    }
  }

  public consumeRollbackTarget(): number | null {
    const target = this.pendingRollbackFrame;
    this.pendingRollbackFrame = null;
    if (target === null) return null;
    if (this.currentFrame - target > MAX_ROLLBACK_WINDOW) {
      return null;
    }
    return target;
  }

  public shouldWaitForRemote(peerConnected: boolean): boolean {
    if (!peerConnected) return false;
    if (this.localSlot !== 'P1' && this.localSlot !== 'P2') return false;
    if (this.lastConfirmedRemoteFrame < 0) return false;
    return this.currentFrame - this.lastConfirmedRemoteFrame > MAX_DRIFT_WAIT_FRAMES;
  }

  public getRemoteMaskForFrame(frame: number): number {
    if (this.remoteConfirmed.has(frame)) {
      const confirmed = this.remoteConfirmed.get(frame)!;
      this.remoteUsedMask.set(frame, confirmed);
      return confirmed;
    }
    // Predict remote holds the most recent confirmed input (classic GGPO prediction)
    const predicted = this.lastRemoteMask;
    this.remoteUsedMask.set(frame, predicted);
    return predicted;
  }

  public getLocalMaskForFrame(frame: number): number {
    if (this.localInputs.has(frame)) {
      return this.localInputs.get(frame)!;
    }
    // Fall back to most recent local input if frameDelay was reduced mid-stream
    for (let f = frame; f >= Math.max(0, frame - 6); f--) {
      if (this.localInputs.has(f)) {
        return this.localInputs.get(f)!;
      }
    }
    return 0;
  }

  /**
   * Returns strictly isolated P1 and P2 masks for the requested frame.
   * Local commands NEVER bleed into the remote player's slot.
   */
  public getFrameMasks(frame: number, peerMaskOverride?: { p1: number; p2: number }): {
    p1Mask: number;
    p2Mask: number;
  } {
    if (this.localSlot === 'SOLO') {
      return { p1Mask: this.getLocalMaskForFrame(frame), p2Mask: 0 };
    }
    if (this.localSlot === 'P1') {
      const p1Mask = this.getLocalMaskForFrame(frame);
      const p2Mask =
        this.remoteConfirmed.size > 0 || this.lastConfirmedRemoteFrame >= 0
          ? this.getRemoteMaskForFrame(frame)
          : (() => {
              const fallback = peerMaskOverride?.p2 ?? 0;
              this.remoteUsedMask.set(frame, fallback);
              return fallback;
            })();
      return { p1Mask, p2Mask };
    }
    if (this.localSlot === 'P2') {
      const p2Mask = this.getLocalMaskForFrame(frame);
      const p1Mask =
        this.remoteConfirmed.size > 0 || this.lastConfirmedRemoteFrame >= 0
          ? this.getRemoteMaskForFrame(frame)
          : (() => {
              const fallback = peerMaskOverride?.p1 ?? 0;
              this.remoteUsedMask.set(frame, fallback);
              return fallback;
            })();
      return { p1Mask, p2Mask };
    }
    return {
      p1Mask: peerMaskOverride?.p1 ?? 0,
      p2Mask: peerMaskOverride?.p2 ?? 0,
    };
  }

  public saveFrameSnapshot(frame: number, snapshot: Record<string, unknown>): void {
    this.stateSnapshots.set(frame, snapshot);
    this.pruneOldFrames(frame);
  }

  public getFrameSnapshot(frame: number): Record<string, unknown> | undefined {
    return this.stateSnapshots.get(frame);
  }

  public incrementRollbackCount(): void {
    this.rollbackCount += 1;
  }

  public pruneOldFrames(latestFrame: number): void {
    const cutoff = latestFrame - MAX_HISTORY_FRAMES;
    if (cutoff <= 0) return;
    for (const k of this.localInputs.keys()) {
      if (k < cutoff) this.localInputs.delete(k);
    }
    for (const k of this.remoteConfirmed.keys()) {
      if (k < cutoff) this.remoteConfirmed.delete(k);
    }
    for (const k of this.remoteUsedMask.keys()) {
      if (k < cutoff) this.remoteUsedMask.delete(k);
    }
    const snapCutoff = latestFrame - (MAX_ROLLBACK_WINDOW + 4);
    for (const k of this.stateSnapshots.keys()) {
      if (k < snapCutoff) this.stateSnapshots.delete(k);
    }
  }

  public getStats(): GgpoStats {
    return {
      currentFrame: this.currentFrame,
      lastConfirmedRemoteFrame: this.lastConfirmedRemoteFrame,
      rollbackCount: this.rollbackCount,
      frameAdvantage:
        this.lastConfirmedRemoteFrame >= 0
          ? this.currentFrame - this.lastConfirmedRemoteFrame
          : 0,
    };
  }
}
