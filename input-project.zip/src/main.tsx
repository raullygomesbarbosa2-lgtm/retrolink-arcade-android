import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function createNoopWakeLockSentinel(type: WakeLockType = 'screen'): WakeLockSentinel {
  const target = new EventTarget();
  const sentinel: WakeLockSentinel = {
    released: false,
    type,
    onrelease: null,
    release: async () => {
      Object.defineProperty(sentinel, 'released', { value: true, configurable: true });
    },
    addEventListener: target.addEventListener.bind(target),
    removeEventListener: target.removeEventListener.bind(target),
    dispatchEvent: target.dispatchEvent.bind(target),
  };
  return sentinel;
}

if (typeof window !== 'undefined' && 'wakeLock' in navigator && navigator.wakeLock) {
  const wakeLockObj = navigator.wakeLock;
  const wakeLockProto = Object.getPrototypeOf(wakeLockObj) as {
    request?: (type?: WakeLockType) => Promise<WakeLockSentinel>;
  } | null;
  const originalRequest = wakeLockProto?.request ?? wakeLockObj.request;

  if (typeof originalRequest === 'function') {
    const safeRequest = function (
      this: WakeLock,
      type: WakeLockType = 'screen'
    ): Promise<WakeLockSentinel> {
      try {
        return originalRequest.call(this || wakeLockObj, type).catch((err: unknown) => {
          const name = (err as { name?: string } | null)?.name;
          if (name === 'NotAllowedError' || name === 'SecurityError') {
            return createNoopWakeLockSentinel(type);
          }
          throw err;
        });
      } catch (err: unknown) {
        const name = (err as { name?: string } | null)?.name;
        if (name === 'NotAllowedError' || name === 'SecurityError') {
          return Promise.resolve(createNoopWakeLockSentinel(type));
        }
        throw err;
      }
    };

    try {
      if (wakeLockProto && wakeLockProto !== Object.prototype) {
        wakeLockProto.request = safeRequest;
      } else {
        Object.defineProperty(wakeLockObj, 'request', {
          value: safeRequest,
          configurable: true,
          writable: true,
        });
      }
    } catch {
      try {
        Object.defineProperty(wakeLockObj, 'request', {
          value: safeRequest,
          configurable: true,
          writable: true,
        });
      } catch {
        // Ignore if environment prevents overriding wakeLock.request
      }
    }
  }
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // ignore if service worker registration unsupported
    });
  });
}

createRoot(document.getElementById('root')!).render(<App />);

