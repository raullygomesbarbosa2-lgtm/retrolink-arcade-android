import { SystemCoreInfo } from '../types/retrolink';

export const CLASSIC_SYSTEMS: SystemCoreInfo[] = [
  {
    id: 'snes',
    name: 'Super Nintendo (SNES)',
    shortName: 'SNES',
    nativeCore: 'Snes9x',
    libretroCore: 'snes9x',
    extensions: ['.sfc', '.smc', '.fig', '.swc', '.bs', '.st', '.zip'],
    yearRange: '1990–1998',
  },
  {
    id: 'megadrive',
    name: 'Mega Drive / 32X / Master System',
    shortName: 'Mega Drive',
    nativeCore: 'Genesis Plus GX / PicoDrive',
    libretroCore: 'genesis_plus_gx',
    extensions: ['.md', '.bin', '.gen', '.smd', '.32x', '.sms', '.gg', '.sg', '.zip'],
    yearRange: '1986–1997',
  },
  {
    id: 'nes',
    name: 'Nintendo 8-Bit (NES / FDS)',
    shortName: 'NES',
    nativeCore: 'JSNES / FCEUmm',
    libretroCore: 'jsnes',
    extensions: ['.nes', '.fds', '.unf', '.unif', '.zip'],
    yearRange: '1983–1994',
  },
  {
    id: 'gba',
    name: 'Game Boy Advance / GB / GBC / WonderSwan',
    shortName: 'GBA / GBC',
    nativeCore: 'mGBA / Beetle WSwan',
    libretroCore: 'mgba',
    extensions: ['.gba', '.gb', '.gbc', '.ws', '.wsc', '.vb', '.zip'],
    yearRange: '1989–2007',
  },
  {
    id: 'neogeo',
    name: 'Neo Geo MVS / AES / Pocket',
    shortName: 'Neo Geo',
    nativeCore: 'FinalBurn Neo / MAME',
    libretroCore: 'fbneo',
    extensions: ['.zip', '.fba', '.ngp', '.ngc', '.ngpc'],
    yearRange: '1990–2004',
  },
  {
    id: 'cps2',
    name: 'Capcom CPS-1 / CPS-2 / CPS-3',
    shortName: 'CPS-1/2',
    nativeCore: 'FinalBurn Neo',
    libretroCore: 'fbneo',
    extensions: ['.zip', '.fba'],
    yearRange: '1988–2003',
  },
  {
    id: 'arcade',
    name: 'Arcade MAME / PC Engine / Clássicos',
    shortName: 'Arcade',
    nativeCore: 'FBNeo / MAME 2003+',
    libretroCore: 'fbneo',
    extensions: ['.zip', '.fba', '.pce', '.sgx', '.lnx', '.col', '.vec'],
    yearRange: '1980–2003',
  },
];

export function getSystemById(id: string): SystemCoreInfo | undefined {
  return CLASSIC_SYSTEMS.find((s) => s.id === id);
}
