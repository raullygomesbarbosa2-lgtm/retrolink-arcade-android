# Security Specification: RetroLink Arcade & Netplay

## 1. Data Invariants
1. **PII Isolation**: User email addresses are stored exclusively in `/users/{userId}/private/info`, accessible only to `request.auth.uid == userId`. Public profiles in `/users_public/{userId}` contain zero PII.
2. **Identity Integrity**: Every write requires `request.auth != null` (authenticated Email/Password Firebase user). All `uid`, `hostUid`, and `ownerUid` fields must strictly equal `request.auth.uid` on creation and remain immutable on update.
3. **System Exclusion**: `systemId` is strictly constrained to `['arcade', 'neogeo', 'cps2', 'snes', 'megadrive', 'nes', 'gba', 'n64']` (PlayStation excluded at schema and rule levels).
4. **Atomic Invite Creation**: A `/server_invites/{inviteCode}` document must correspond to an existing or batched `/servers/{serverId}` document (`existsAfter`) owned by the same `hostUid`.
5. **Terminal State Locking**: Once a `/servers/{serverId}` document reaches `status == 'closed'`, no subsequent updates are permitted.
6. **Private Server Isolation**: `allow list` on `/servers` never returns private rooms to non-participants (`visibility == 'public' || hostUid == uid || guestUid == uid`). `allow list` on `/server_invites` is permanently denied (`if false`) to prevent invite enumeration.
7. **Master Gate on Signaling & Chat**: `/servers/{serverId}/signals/{signalId}` and `/servers/{serverId}/messages/{messageId}` validate parent `/servers/{serverId}` membership (`hostUid` or `guestUid`) via `get()` on `create`, and filter `list` queries on `resource.data` without nested `get()` calls.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Shadow Field Injection on Public Profile**: `{ uid, gamertag, ..., isAdmin: true }` -> Rejected by `hasOnly(...)`.
2. **Unauthenticated Write**: Write with `request.auth == null` -> Rejected by `isSignedIn()`.
3. **Cross-User PII Read**: User B attempting `get /users/userA/private/info` -> Rejected by `request.auth.uid == userId`.
4. **UID Spoofing on Server Create**: User A creating `/servers/s1` with `hostUid: "userB"` -> Rejected by `incoming().hostUid == request.auth.uid`.
5. **Orphan Invite Code**: User A creating `/server_invites/FAKE12` pointing to a non-existent `serverId` without batching the server doc -> Rejected by `existsAfter(...)`.
6. **Private Server List Scrape**: User B listing `/servers` without filtering `visibility == 'public'` -> Rejected by `allow list` rule evaluating `resource.data`.
7. **Invite Code Enumeration**: User B attempting `list /server_invites` -> Rejected (`allow list: if false`).
8. **Client Timestamp Forgery**: Creating a server with `createdAt` in the past or future -> Rejected by `incoming().createdAt == request.time`.
9. **Terminal State Mutation**: Host attempting to reopen or modify `/servers/s1` after `status == 'closed'` -> Rejected by `existing().status != 'closed'`.
10. **Host Hijack via Update**: Guest updating `/servers/s1` to change `hostUid` or `frameDelay` -> Rejected by action-specific `affectedKeys().hasOnly(...)` and `existing().hostUid == request.auth.uid` checks.
11. **Oversized ID Poisoning**: Document ID `{serverId}` exceeding 128 chars or containing `/` / `$` -> Rejected by `isValidId(serverId)`.
12. **Disallowed System Injection**: Creating a server with `systemId: "playstation"` -> Rejected by `incoming().systemId in [...]`.
