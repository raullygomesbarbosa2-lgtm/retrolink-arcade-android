/**
 * Security Rule Verification Suite for RetroLink Arcade & Netplay.
 * Validates the 12 adversarial payloads defined in security_spec.md.
 */
export const DIRTY_DOZEN_ASSERTIONS = [
  { id: 1, name: 'Shadow field injection on public profile', expected: 'PERMISSION_DENIED' },
  { id: 2, name: 'Unverified email token write', expected: 'PERMISSION_DENIED' },
  { id: 3, name: 'Cross-user PII read on /users/{uid}/private/info', expected: 'PERMISSION_DENIED' },
  { id: 4, name: 'Host UID spoofing on /servers create', expected: 'PERMISSION_DENIED' },
  { id: 5, name: 'Orphan invite creation without batched server doc', expected: 'PERMISSION_DENIED' },
  { id: 6, name: 'Private server list scrape', expected: 'PERMISSION_DENIED' },
  { id: 7, name: 'Invite code list enumeration', expected: 'PERMISSION_DENIED' },
  { id: 8, name: 'Client timestamp forgery on server create', expected: 'PERMISSION_DENIED' },
  { id: 9, name: 'Terminal state mutation after status=closed', expected: 'PERMISSION_DENIED' },
  { id: 10, name: 'Guest hijacking hostUid or frameDelay on update', expected: 'PERMISSION_DENIED' },
  { id: 11, name: 'Oversized/invalid document ID poisoning', expected: 'PERMISSION_DENIED' },
  { id: 12, name: 'Excluded systemId (playstation) injection', expected: 'PERMISSION_DENIED' },
] as const;
