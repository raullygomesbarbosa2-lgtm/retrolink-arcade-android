import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RoomParticipant {
  uid: string;
  gamertag: string;
  role: 'host' | 'guest' | 'spectator';
  slot: 'P1' | 'P2' | 'SPEC';
  ready: boolean;
  pingMs: number;
  lastInputSequence: number;
  ws: WebSocket;
}

interface ChatMessage {
  id: string;
  uid: string;
  gamertag: string;
  text: string;
  timestamp: number;
}

interface LiveRoom {
  serverId: string;
  romId: string;
  romTitle: string;
  systemId: string;
  frameDelay: number;
  matchRunning: boolean;
  participants: Map<string, RoomParticipant>;
  chat: ChatMessage[];
  sharedNesRomBase64: string | null;
  sharedNesRomName: string | null;
}

const rooms = new Map<string, LiveRoom>();

function getOrCreateRoom(
  serverId: string,
  romId = 'custom_rom',
  romTitle = 'ROM do Usuario',
  systemId = 'nes',
  frameDelay = 2
): LiveRoom {
  let room = rooms.get(serverId);
  if (!room) {
    room = {
      serverId,
      romId,
      romTitle,
      systemId,
      frameDelay,
      matchRunning: false,
      participants: new Map(),
      chat: [],
      sharedNesRomBase64: null,
      sharedNesRomName: null,
    };
    rooms.set(serverId, room);
  }
  return room;
}

function serializeRoom(room: LiveRoom) {
  return {
    serverId: room.serverId,
    romId: room.romId,
    romTitle: room.romTitle,
    systemId: room.systemId,
    frameDelay: room.frameDelay,
    matchRunning: room.matchRunning,
    hasSharedRom: Boolean(room.sharedNesRomBase64),
    sharedNesRomName: room.sharedNesRomName,
    participants: Array.from(room.participants.values()).map((p) => ({
      uid: p.uid,
      gamertag: p.gamertag,
      slot: p.slot,
      ready: p.ready,
      pingMs: p.pingMs,
    })),
    chat: room.chat.slice(-40),
  };
}

function broadcastRoom(room: LiveRoom, payload: Record<string, unknown>, excludeUid?: string) {
  const encoded = JSON.stringify(payload);
  for (const participant of room.participants.values()) {
    if (excludeUid && participant.uid === excludeUid) continue;
    if (participant.ws.readyState === WebSocket.OPEN) {
      participant.ws.send(encoded);
    }
  }
}

function sanitizeText(input: unknown, maxLen: number): string {
  if (typeof input !== 'string') return '';
  return input.replace(/[<>]/g, '').trim().slice(0, maxLen);
}

const ALLOWED_CORES = new Set([
  'fceumm',
  'snes9x',
  'genesis_plus_gx',
  'picodrive',
  'mgba',
  'fbneo',
  'mame2003_plus',
  'mame2000',
  'mednafen_pce_fast',
  'mednafen_ngp',
  'mednafen_wswan',
  'mednafen_lynx',
  'mednafen_vb',
  'gearcoleco',
  'vecx',
]);

const coreZipCache = new Map<string, Buffer>();

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeRooms: rooms.size });
  });

  app.get('/api/cores/:core', async (req, res) => {
    const core = sanitizeText(req.params.core, 32).replace(/[^a-z0-9_]/gi, '');
    if (!ALLOWED_CORES.has(core)) {
      res.status(404).json({ error: 'Núcleo não permitido.' });
      return;
    }

    try {
      let cached = coreZipCache.get(core);
      if (!cached) {
        const upstream = `https://cdn.jsdelivr.net/gh/arianrhodsandlot/retroarch-emscripten-build@v1.22.2/retroarch/${core}_libretro.zip`;
        const response = await fetch(upstream);
        if (!response.ok) {
          res.status(502).json({ error: `Falha ao obter núcleo ${core}` });
          return;
        }
        const arrayBuf = await response.arrayBuffer();
        cached = Buffer.from(arrayBuf);
        coreZipCache.set(core, cached);
      }

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(cached);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Erro interno ao carregar núcleo.',
      });
    }
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    let currentRoomId: string | null = null;
    let currentUid: string | null = null;

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      const type = msg.type;
      if (typeof type !== 'string') return;

      if (type === 'netplay:ping') {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'netplay:pong', ts: msg.ts }));
        }
        if (currentRoomId && currentUid && typeof msg.lastRtt === 'number') {
          const room = rooms.get(currentRoomId);
          const participant = room?.participants.get(currentUid);
          if (participant) {
            participant.pingMs = Math.max(1, Math.min(999, Math.round(msg.lastRtt)));
          }
        }
        return;
      }

      if (type === 'room:join') {
        const serverId = sanitizeText(msg.serverId, 128);
        const uid = sanitizeText(msg.uid, 128);
        const gamertag = sanitizeText(msg.gamertag, 24) || 'Jogador';
        const role = msg.role === 'host' ? 'host' : msg.role === 'guest' ? 'guest' : 'spectator';
        const romId = sanitizeText(msg.romId, 64) || 'custom_rom';
        const romTitle = sanitizeText(msg.romTitle, 80) || 'ROM do Usuario';
        const systemId = sanitizeText(msg.systemId, 24) || 'nes';
        const frameDelay = typeof msg.frameDelay === 'number' ? Math.max(0, Math.min(6, msg.frameDelay)) : 2;

        if (!serverId || !uid) return;

        if (currentRoomId && currentUid) {
          const prev = rooms.get(currentRoomId);
          if (prev) {
            prev.participants.delete(currentUid);
            broadcastRoom(prev, { type: 'room:state', room: serializeRoom(prev) });
          }
        }

        const room = getOrCreateRoom(serverId, romId, romTitle, systemId, frameDelay);
        currentRoomId = serverId;
        currentUid = uid;

        const existingParticipants = Array.from(room.participants.values()).filter((p) => p.uid !== uid);
        const hasP1 = existingParticipants.some((p) => p.slot === 'P1');
        const hasP2 = existingParticipants.some((p) => p.slot === 'P2');

        // Never infer a player's slot from arrival order. A guest arriving
        // before the host waits as a spectator instead of taking P1 controls.
        let slot: 'P1' | 'P2' | 'SPEC' = 'SPEC';
        if (role === 'host' && !hasP1) slot = 'P1';
        else if (role === 'guest' && hasP1 && !hasP2) slot = 'P2';

        room.participants.set(uid, {
          uid,
          gamertag,
          role,
          slot,
          ready: false,
          pingMs: 12,
          lastInputSequence: 0,
          ws,
        });

        // If the guest connected before the host, promote that waiting guest
        // only after P1 has actually claimed the host slot.
        if (slot === 'P1' && !hasP2) {
          const waitingGuest = Array.from(room.participants.values()).find(
            (p) => p.uid !== uid && p.role === 'guest' && p.slot === 'SPEC'
          );
          if (waitingGuest) waitingGuest.slot = 'P2';
        }

        broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
        if (room.sharedNesRomBase64 && ws.readyState === WebSocket.OPEN) {
          ws.send(
            JSON.stringify({
              type: 'rom:shared',
              fileName: room.sharedNesRomName,
              base64: room.sharedNesRomBase64,
            })
          );
        }
        return;
      }

      if (!currentRoomId || !currentUid) return;
      const room = rooms.get(currentRoomId);
      if (!room) return;
      const sender = room.participants.get(currentUid);
      if (!sender) return;

      if (type === 'room:ready') {
        sender.ready = Boolean(msg.ready);
        broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
        return;
      }

      if (type === 'room:chat') {
        const text = sanitizeText(msg.text, 240);
        if (!text) return;
        const entry: ChatMessage = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          uid: sender.uid,
          gamertag: sender.gamertag,
          text,
          timestamp: Date.now(),
        };
        room.chat.push(entry);
        if (room.chat.length > 50) room.chat.shift();
        broadcastRoom(room, { type: 'room:chat_msg', message: entry });
        return;
      }

      if (type === 'room:config') {
        if (sender.slot === 'P1') {
          if (typeof msg.frameDelay === 'number') {
            room.frameDelay = Math.max(0, Math.min(6, Math.round(msg.frameDelay)));
          }
          if (typeof msg.romId === 'string') room.romId = sanitizeText(msg.romId, 64);
          if (typeof msg.romTitle === 'string') room.romTitle = sanitizeText(msg.romTitle, 80);
          if (typeof msg.systemId === 'string') room.systemId = sanitizeText(msg.systemId, 24);
          broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
        }
        return;
      }

      if (type === 'netplay:start' || type === 'netplay:reset' || type === 'netplay:pause') {
        if (sender.slot === 'P1') {
          room.matchRunning = type === 'netplay:start' || type === 'netplay:reset';
          broadcastRoom(room, {
            type,
            by: sender.gamertag,
            romId: room.romId,
            systemId: room.systemId,
            frameDelay: room.frameDelay,
          });
          broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
        }
        return;
      }

      if (type === 'netplay:input') {
        const sequence = msg.seq;
        const mask = msg.mask;
        if (
          (sender.slot === 'P1' || sender.slot === 'P2') &&
          typeof sequence === 'number' && Number.isSafeInteger(sequence) &&
          sequence > sender.lastInputSequence &&
          typeof mask === 'number' && Number.isSafeInteger(mask) && mask >= 0 && mask <= 65535
        ) {
          sender.lastInputSequence = sequence;
          broadcastRoom(
            room,
            {
              type: 'netplay:remote_input',
              slot: sender.slot,
              frame: typeof msg.frame === 'number' ? msg.frame : 0,
              seq: sequence,
              mask,
            },
            currentUid
          );
        }
        return;
      }

      if (type === 'netplay:sync_state') {
        if (sender.slot === 'P1' && typeof msg.stateJson === 'string' && msg.stateJson.length < 1_500_000) {
          broadcastRoom(
            room,
            {
              type: 'netplay:state_snapshot',
              frame: typeof msg.frame === 'number' ? msg.frame : 0,
              stateJson: msg.stateJson,
            },
            currentUid
          );
        }
        return;
      }

      if (type === 'rom:share') {
        if (
          sender.slot === 'P1' &&
          typeof msg.base64 === 'string' &&
          msg.base64.length <= 11_000_000
        ) {
          room.sharedNesRomBase64 = msg.base64;
          room.sharedNesRomName = sanitizeText(msg.fileName, 100) || 'custom.rom';
          broadcastRoom(
            room,
            {
              type: 'rom:shared',
              fileName: room.sharedNesRomName,
              base64: room.sharedNesRomBase64,
            },
            currentUid
          );
          broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
        }
      }
    });

    ws.on('close', () => {
      if (currentRoomId && currentUid) {
        const room = rooms.get(currentRoomId);
        if (room) {
          room.participants.delete(currentUid);
          if (room.participants.size === 0) {
            rooms.delete(currentRoomId);
          } else {
            broadcastRoom(room, { type: 'room:state', room: serializeRoom(room) });
          }
        }
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`RetroLink server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
